#!/bin/bash
# Removes Yoshi C's DJ Master from this Mac: the app, its private Python and its data (DJ name/password,
# crate list, settings). WAVs you've downloaded (Music/DJ Master) are left alone.

APP_NAME="Yoshi C's DJ Master"
DEST="$HOME/Library/Application Support/Yoshi C DJ Master"
BUNDLE="$HOME/Applications/$APP_NAME.app"

printf "\n  This removes %s, its settings and your DJ name and password.\n" "$APP_NAME"
printf "  WAVs you've downloaded in Music/DJ Master are kept.\n\n"
read -r -p "  Remove it? [y/N] " answer
case "$answer" in
    [yY]*)
        pkill -f "$DEST/app.pyc" 2>/dev/null
        rm -rf "$BUNDLE" "$HOME/Applications/Yoshi C DJ Master.app" "$DEST" "$HOME/Music/DJ Master for rekordbox.xml"
        printf "\n  Removed.\n\n"
        ;;
    *)
        printf "\n  Nothing was removed.\n\n"
        ;;
esac
