"""Delete what an older version left behind, and nothing else.

Both installers copy this version's files over whatever is already there. Neither of them removes
anything: Inno Setup overwrites but does not tidy, and `ditto` merges. So a file that shipped in an
older version and was then dropped stays on the machine for good.

That is not only untidy. Python will happily import a `.pyc` that no longer has a `.py` behind it,
so a module deleted from the source can go on being loaded from an old install. Worse, DJ Master's
phone server hands out files from `ui/` **by basename**, so a stale page or stylesheet left in that
folder is a stale page it will serve to a phone.

How it decides what to delete
-----------------------------
The build writes `manifest.txt` - every file this version installs, one relative path per line. This
walks only the folders the app owns (MANAGED below) and deletes any file in them that the manifest
does not list. Everything else is left completely alone, and on top of that KEEP names anything that
must survive even if it somehow appears inside a managed folder.

What it will never touch
------------------------
Your settings, account, crate, requests, queue, licence and logs; the Python environment in `.venv`;
the downloaded programs in `bin/`; the separation models in `models/`, which are gigabytes and take
an age to fetch again. None of those are in a managed folder, and all of them are in KEEP as well,
because a mistake here costs somebody their library or a 1.6 GB download.

Run with --dry-run to be told what would go without anything going.
"""

import argparse

import sys
from pathlib import Path

MANIFEST = "manifest.txt"

# Folders the app owns outright. A file inside one of these that isn't in the manifest is left over
# from an older version. "" means the install folder itself, top level only - never recursively,
# because that is where settings.json and the crate live.
MANAGED = ("", "ui", "installer")

# Belt as well as braces. Anything named here survives whatever else happens.
KEEP = {
    MANIFEST, "settings.json", "account.json", "licence.json", "machine.json", "crate.json",
    "requests.json", "queue.json", "changes.json", "splits.json", "log.txt", "install-log.txt", "tunnel.pid", "cloudflared.yml",
    "icon.ico", "AppIcon.icns",
    # The Mac installer copies this in beside the app after the build's manifest is written, so it's
    # never listed - and was deleted by the very install that put it there, every time.
    "Uninstall.command",
}
KEEP_PREFIX = (".venv", "bin", "models", ".webview", "__pycache__", "unins", "backups")
KEEP_SUFFIX = (".tmp", ".part", ".lnk", ".exe", ".dat")
# Folders inside a managed one that hold this computer's data rather than the app: the crate's covers.
KEEP_DIRS = ("ui/art/",)


def protected(rel):
    """Is this path one we must not delete, whatever the manifest says?"""
    parts = rel.split("/")
    if parts[0].startswith(KEEP_PREFIX) or parts[0].startswith("."):
        return True
    if rel.startswith(KEEP_DIRS):
        return True
    return rel in KEEP or parts[-1] in KEEP or rel.endswith(KEEP_SUFFIX)


def listed(app_dir):
    """The files this version installs, as the build recorded them."""
    try:
        # utf-8-sig, not utf-8: Windows PowerShell writes UTF-8 *with* a byte order mark, and
        # reading that as plain utf-8 leaves it glued to the first filename - which would then
        # not match the manifest and would be deleted. Caught by the first real build.
        text = (Path(app_dir) / MANIFEST).read_text(encoding="utf-8-sig")
    except OSError:
        return None                       # no manifest: an older installer, or a broken copy
    return {line.strip().replace("\\", "/") for line in text.splitlines() if line.strip()}


def stale(app_dir, keep):
    """Every file in a managed folder that this version doesn't install."""
    app_dir = Path(app_dir)
    found = []
    for folder in MANAGED:
        root = app_dir / folder if folder else app_dir
        if not root.is_dir():
            continue
        # The install folder itself is checked at the top level only; the named folders go all the way
        # down, because that is where a renamed page or stylesheet would hide.
        walk = sorted(root.iterdir()) if folder == "" else sorted(root.rglob("*"))
        for path in walk:
            if not path.is_file():
                continue
            rel = path.relative_to(app_dir).as_posix()
            if rel in keep or protected(rel):
                continue
            found.append(path)
    return found


def empty_dirs(app_dir):
    """Folders left with nothing in them once the stale files are gone."""
    app_dir = Path(app_dir)
    out = []
    for folder in MANAGED:
        if not folder:
            continue
        root = app_dir / folder
        if not root.is_dir():
            continue
        for path in sorted(root.rglob("*"), key=lambda p: len(p.parts), reverse=True):
            if path.is_dir() and not any(path.iterdir()):
                out.append(path)
    return out


def main(argv=None):
    parser = argparse.ArgumentParser(description="Remove files left behind by an older version.")
    parser.add_argument("app_dir")
    parser.add_argument("--dry-run", action="store_true", help="say what would go, delete nothing")
    args = parser.parse_args(argv)

    keep = listed(args.app_dir)
    if keep is None:
        print("        no manifest, so nothing is assumed stale")
        return 0
    if not keep:
        print("        the manifest is empty - refusing to delete anything on that basis")
        return 0

    victims = stale(args.app_dir, keep)
    if not victims:
        print("        nothing left over from an older version")
        return 0

    app_dir = Path(args.app_dir)
    gone = 0
    for path in victims:
        rel = path.relative_to(app_dir).as_posix()
        if args.dry_run:
            print("        would remove %s" % rel)
            continue
        try:
            path.unlink()
            gone += 1
            print("        removed %s (left by an older version)" % rel)
        except OSError as exc:
            print("        couldn't remove %s: %s" % (rel, exc))
    if not args.dry_run:
        for folder in empty_dirs(args.app_dir):
            try:
                folder.rmdir()
            except OSError:
                pass
        print("        %d old file%s removed" % (gone, "" if gone == 1 else "s"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
