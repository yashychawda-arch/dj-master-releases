/* The small moments inside the app (M1-M6, picked 7 Oct 2026 from the motion previews). This file is the same in
   DJ Master and Stem Splitter, and in the shop and private editions; app.js calls it through window.YCM?. so the
   app still runs without it, and u.css carries its looks (Settings opening and dropping files are CSS only).
     M1  a row arrives: it makes room, slides in from just above, and a line in your colour glows at its edge; the
         side menu puts a dot on that section if you're somewhere else
     M2  a job finishes: the bar fills the rest of the way, a tick draws in, and what it made settles in one by one
     M3  a row leaves: it slides away to the left as it fades, then the rows below close the gap (Undo brings it
         back through M1)
     M5  the side menu has one lit pill that glides to the section you're on, instead of the highlight jumping
     G1  the giant padlock when the app locks and unlocks, and on a wrong password (YCM.padlock)
     and a word or number in the top bar that changes rolls over rather than switching.
   Timings are transitions.dev's scale: 150-250ms, its smooth ease-out for things arriving, a firm ease-in for things
   leaving, 80ms between rows that land together. Reduced motion gets every end state at once. */
(() => {
  const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const SMOOTH = "cubic-bezier(0.22, 1, 0.36, 1)", IN = "cubic-bezier(0.7, 0, 0.84, 0)";
  const booting = () => document.documentElement.classList.contains("booting");

  // Rows that land in the same moment (a dropped folder, a playlist) take turns: 0, 80, 160ms ... up to 480ms.
  let batch = 0, batchRaf = 0;
  function slot() {
    if (!batchRaf) batchRaf = requestAnimationFrame(() => { batch = 0; batchRaf = 0; });
    return Math.min(batch++, 6);
  }

  // M1 ─ arriving
  function arrive(node) {
    if (REDUCED || booting() || !node.isConnected) return;
    const i = slot(), h = node.offsetHeight, row = node.firstElementChild;
    if (!h) return;
    node.style.overflow = "hidden";
    const grow = node.animate([{ height: "0px" }, { height: `${h}px` }], { duration: 250, delay: i * 80, easing: SMOOTH, fill: "backwards" });
    grow.onfinish = grow.oncancel = () => { node.style.overflow = ""; };
    if (row) row.animate([{ opacity: 0, transform: "translateY(-6px)" }, { opacity: 1, transform: "none" }],
                         { duration: 250, delay: 60 + i * 80, easing: SMOOTH, fill: "backwards" });
    const edge = document.createElement("span");
    edge.className = "u-edge";
    edge.setAttribute("aria-hidden", "true");
    edge.style.animationDelay = `${100 + i * 80}ms`;
    node.append(edge);
    setTimeout(() => edge.remove(), 2000 + i * 80);
    ping(node.closest("section[id]"));
  }

  // M3 ─ leaving. The id goes at once, so if the same row comes straight back (Undo) it's built fresh, not found
  // half-gone; `done` runs when the gap has closed.
  function leave(node, done) {
    node.dataset.leaving = "1";
    node.removeAttribute("id");
    if (REDUCED || !node.offsetHeight) { done(); return; }
    node.style.overflow = "hidden";
    node.style.pointerEvents = "none";
    node.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: "translateX(-12px)" }], { duration: 150, easing: IN, fill: "forwards" });
    const shut = node.animate([{ height: `${node.offsetHeight}px` }, { height: "0px" }], { duration: 200, delay: 120, easing: SMOOTH, fill: "forwards" });
    shut.onfinish = done;
  }

  // M2 ─ finished. `from` is how full the bar was a moment ago.
  function finish(node, from = 0) {
    if (REDUCED || !node.isConnected) return;
    const rule = node.querySelector(".job-rule i");
    if (rule && from < 1) rule.animate([{ transform: `scaleX(${from})` }, { transform: "scaleX(1)" }], { duration: 450, easing: SMOOTH });
    const tick = node.querySelector(".u-tick path");
    if (tick) tick.animate([{ strokeDashoffset: 1 }, { strokeDashoffset: 0 }], { duration: 250, delay: 380, easing: SMOOTH, fill: "backwards" });
    const made = [...node.querySelectorAll(".job-analysis .an-cell, .job-out .stem, .job-out .out-tool, .job-out > button, .job-out > a")];
    made.forEach((m, i) => m.animate([{ opacity: 0, transform: "translateY(6px) scale(0.96)" }, { opacity: 1, transform: "none" }],
                                    { duration: 200, delay: 420 + Math.min(i, 10) * 60, easing: SMOOTH, fill: "backwards" }));
  }
  // The tick that sits before "Done" (u.css shows it only on finished rows).
  function decorate(node) {
    const stage = node.querySelector(".job-stage");
    if (!stage || stage.querySelector(".u-tick")) return;
    stage.insertAdjacentHTML("afterbegin", '<svg class="u-tick" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" pathLength="1" stroke-dasharray="1"/></svg>');
  }

  // A word or number in the top bar rolls over: the old one up and out, the new one up and in.
  function roll(node, text) {
    if (!node) return;
    const now = node._rollTo ?? node.textContent;
    if (now === text) return;
    if (REDUCED || booting() || !node.offsetParent) { node._rollTo = undefined; node.classList.remove("u-rolling"); node.textContent = text; return; }
    const old = document.createElement("span"), next = document.createElement("span");
    old.textContent = now;
    next.textContent = text;
    node._rollTo = text;
    node.classList.add("u-rolling");
    node.replaceChildren(old, next);
    old.animate([{ transform: "none", opacity: 1 }, { transform: "translateY(-100%)", opacity: 0 }], { duration: 250, easing: SMOOTH, fill: "forwards" });
    next.animate([{ transform: "translateY(100%)", opacity: 0 }, { transform: "none", opacity: 1 }], { duration: 250, easing: SMOOTH })
      .onfinish = () => { if (node._rollTo === text) { node._rollTo = undefined; node.classList.remove("u-rolling"); node.textContent = text; } };
  }

  // M1 ─ a dot on the side menu's item for a section something just landed in, while you're elsewhere. It goes
  // when that item lights (rail(), below).
  function ping(section) {
    const item = section && document.querySelector(`.rail-item[data-target="${section.id}"]`);
    if (!item || item.classList.contains("active")) return;
    let dot = item.querySelector(".u-dot");
    if (!dot) { dot = document.createElement("span"); dot.className = "u-dot"; dot.setAttribute("aria-hidden", "true"); item.append(dot); }
  }

  // M5 ─ the gliding pill. Placed from the lit item whenever any item's class changes (the scroll spy, a click,
  // Settings opening), so app.js doesn't need to tell it anything.
  function rail() {
    const nav = document.querySelector(".rail");
    if (!nav || nav.querySelector(".u-pill")) return;
    const pill = document.createElement("span");
    pill.className = "u-pill";
    pill.setAttribute("aria-hidden", "true");
    nav.prepend(pill);
    nav.classList.add("u-glide");
    let placed = false;
    const place = () => {
      const on = nav.querySelector(".rail-item.active");
      if (!on || !on.offsetParent) { pill.style.opacity = "0"; placed = false; return; }
      on.querySelector(".u-dot")?.remove();
      // Layout offsets (the items sit straight in the rail, which the pill is placed in), not screen boxes: these
      // stay right under any zoom - the website's 2x captures zoom the page, and screen boxes came out doubled.
      if (!placed || REDUCED) pill.style.transition = "none";
      pill.style.width = `${on.offsetWidth}px`;
      pill.style.height = `${on.offsetHeight}px`;
      pill.style.transform = `translate(${on.offsetLeft}px, ${on.offsetTop}px)`;
      pill.style.opacity = "1";
      if (!placed) { void pill.offsetWidth; pill.style.transition = ""; placed = true; }
    };
    new MutationObserver(place).observe(nav, { subtree: true, attributes: true, attributeFilter: ["class"] });
    addEventListener("resize", place);
    // the rail settles in after the intro: placed again once it has its final size
    new ResizeObserver(place).observe(nav);
    place();
  }

  // G1 (picked 7 Oct) ─ the giant padlock. Locking: the app steps back, a giant open padlock rises in the middle, its
  // shackle slams shut with a pulse of the accent, then it shrinks into the sign-in card's own lock icon as the card
  // arrives. Unlocking runs it back: out of the icon, the shackle springs open, and it drops away as the app comes
  // forward. A wrong password: out of the icon, two tugs against the lock, the keyhole amber, back in. One padlock,
  // made once, fixed over everything; the card's small lock is hidden while the big one stands in for it.
  const IN_MS = 820, OUT_MS = 640;
  let giant = null, padTimers = [];
  function giantEl() {
    if (giant) return giant;
    giant = document.createElement("div");
    giant.className = "u-giant";
    giant.setAttribute("aria-hidden", "true");
    giant.innerHTML = '<span class="u-giant-ring"></span><svg viewBox="0 0 100 120" fill="none">'
      + '<defs><linearGradient id="u-giant-body" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a2326"/><stop offset="1" stop-color="#151112"/></linearGradient></defs>'
      + '<path class="shackle" d="M30 52V34a20 20 0 0 1 40 0v18" stroke="currentColor" stroke-width="8" stroke-linecap="round"/>'
      + '<rect x="12" y="50" width="76" height="62" rx="13" fill="url(#u-giant-body)" stroke="currentColor" stroke-opacity=".55" stroke-width="2"/>'
      + '<path d="M20 58h60" stroke="#fff" stroke-opacity=".08" stroke-width="2" stroke-linecap="round"/>'
      + '<g class="keyhole"><circle cx="50" cy="76" r="7" fill="currentColor"/><rect x="46.5" y="78" width="7" height="16" rx="3.5" fill="currentColor"/></g></svg>';
    document.body.append(giant);
    return giant;
  }
  const OPEN = "translateY(-15px) rotate(-14deg)";
  function padReset() {
    padTimers.forEach(clearTimeout); padTimers = [];
    const g = giantEl();
    g.getAnimations({ subtree: true }).forEach((a) => a.cancel());
    return g;
  }
  const after = (ms, fn) => padTimers.push(setTimeout(fn, ms));
  // Where the giant padlock sits to become the card's small one: the drawn lock (shackle top to body bottom) laid
  // over the icon's. Measured with nothing moving.
  function onIcon(g, icon) {
    const gr = g.getBoundingClientRect(), ir = icon.getBoundingClientRect();
    const s = (ir.height * 17 / 24) / (gr.height * 98 / 120);
    const dx = ir.left + ir.width / 2 - (gr.left + gr.width / 2);
    const dy = ir.top + ir.height / 2 - (gr.top + gr.height / 2) - gr.height * 0.025 * s;
    return `translate(${dx}px, ${dy}px) scale(${s})`;
  }
  const glyph = (gate, off) => gate && gate.classList.toggle("u-glyph-off", off);
  function slam(g, at) {
    const sh = g.querySelector(".shackle"), svg = g.querySelector("svg");
    sh.animate([{ transform: OPEN }, { transform: "none" }], { duration: 130, delay: at, easing: IN, fill: "both" });
    svg.animate([{ transform: "none" }, { transform: "scale(1.04, .95)", offset: 0.35 }, { transform: "none" }], { duration: 200, delay: at + 120, easing: "ease-out" });
    g.querySelector(".u-giant-ring").animate([{ opacity: 0.9, transform: "scale(.55)" }, { opacity: 0, transform: "scale(1.5)" }], { duration: 520, delay: at + 120, easing: SMOOTH, fill: "forwards" });
    g.querySelector(".keyhole").animate([{ opacity: 1 }, { opacity: 0.35, offset: 0.4 }, { opacity: 1 }], { duration: 300, delay: at + 120 });
  }
  const padlock = {
    // o: { back: [elements that step back], gate, icon: () => the card's lock icon, show: () => puts the card up }
    lock(o) {
      if (REDUCED) { o.show(); return; }
      const g = padReset(), sh = g.querySelector(".shackle");
      const back = (o.back || []).filter(Boolean).map((el) => el.animate([{ filter: "none", transform: "none" }, { filter: "blur(6px) brightness(.45)", transform: "scale(.97)" }],
        { duration: 380, easing: SMOOTH, fill: "forwards" }));
      sh.animate([{ transform: OPEN }, { transform: OPEN }], { duration: 1, fill: "both" });
      g.animate([{ opacity: 0, transform: "translateY(40px) scale(.85)" }, { opacity: 1, transform: "none" }], { duration: 360, delay: 80, easing: SMOOTH, fill: "both" });
      slam(g, 470);
      after(IN_MS, () => {
        o.gate?.classList.add("u-giant-in");
        glyph(o.gate, true);
        o.show();                                    // the card is laid out now, with no entrance transform of its own
        const icon = o.icon && o.icon();
        g.getAnimations().forEach((a) => a.finish());
        const to = icon ? onIcon(g, icon) : "scale(.2)";
        g.animate([{ transform: "none", opacity: 1 }, { transform: to, opacity: 1, offset: 0.9 }, { transform: to, opacity: 0 }], { duration: 480, easing: SMOOTH, fill: "forwards" });
        after(470, () => { glyph(o.gate, false); });
        after(700, () => { back.forEach((a) => a.cancel()); o.gate?.classList.remove("u-giant-in"); padReset(); });
      });
    },
    // o: { gate, icon: the card's lock icon, appear: () => the app comes forward (at the drop) }
    unlock(o) {
      if (REDUCED || !o.icon) { o.appear?.(); return; }
      const g = padReset(), sh = g.querySelector(".shackle");
      const from = onIcon(g, o.icon);
      glyph(o.gate, true);
      g.animate([{ transform: from, opacity: 1 }, { transform: "none", opacity: 1 }], { duration: 380, easing: SMOOTH, fill: "both" });
      sh.animate([{ transform: "none" }, { transform: OPEN }], { duration: 220, delay: 400, easing: SMOOTH, fill: "both" });
      g.querySelector(".u-giant-ring").animate([{ opacity: 0.8, transform: "scale(.6)" }, { opacity: 0, transform: "scale(1.4)" }], { duration: 480, delay: 400, easing: SMOOTH, fill: "forwards" });
      after(OUT_MS, () => {
        g.getAnimations().forEach((a) => a.finish());
        g.animate([{ transform: "none", opacity: 1 }, { transform: "translateY(14vmin) rotate(8deg) scale(.9)", opacity: 0 }], { duration: 420, easing: IN, fill: "forwards" });
        o.appear?.();
      });
      after(OUT_MS + 460, () => { glyph(o.gate, false); padReset(); });
    },
    // o: { gate, icon, card }
    wrong(o) {
      if (REDUCED || !o.icon) return;
      const g = padReset(), sh = g.querySelector(".shackle"), svg = g.querySelector("svg"), key = g.querySelector(".keyhole");
      const home = onIcon(g, o.icon);
      glyph(o.gate, true);
      o.card?.animate([{ opacity: 1 }, { opacity: 0.35, offset: 0.2 }, { opacity: 0.35, offset: 0.75 }, { opacity: 1 }], { duration: 1100, easing: "ease-in-out" });
      g.animate([{ transform: home, opacity: 1 }, { transform: "none", opacity: 1 }], { duration: 300, easing: SMOOTH, fill: "both" });
      sh.animate([{ transform: "none" }, { transform: "translateY(-5px)", offset: 0.2 }, { transform: "none", offset: 0.4 }, { transform: "translateY(-4px)", offset: 0.6 }, { transform: "none", offset: 0.8 }, { transform: "none" }],
        { duration: 420, delay: 300, easing: "ease-in-out" });
      svg.animate([{ transform: "none" }, { transform: "translateX(-2.5%)", offset: 0.25 }, { transform: "translateX(2.5%)", offset: 0.5 }, { transform: "translateX(-1.5%)", offset: 0.75 }, { transform: "none" }],
        { duration: 360, delay: 340, easing: "ease-in-out" });
      key.animate([{ color: "currentColor" }, { color: "#ffb54a", offset: 0.2 }, { color: "#ffb54a", offset: 0.7 }, { color: "currentColor" }], { duration: 700, delay: 300 });
      after(760, () => {
        g.getAnimations().forEach((a) => a.finish());
        g.animate([{ transform: "none", opacity: 1 }, { transform: home, opacity: 1, offset: 0.9 }, { transform: home, opacity: 0 }], { duration: 380, easing: SMOOTH, fill: "forwards" });
      });
      after(1150, () => { glyph(o.gate, false); padReset(); });
    },
  };

  window.YCM = { slot, arrive, leave, finish, decorate, roll, ping, rail, padlock };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", rail); else rail();
})();
