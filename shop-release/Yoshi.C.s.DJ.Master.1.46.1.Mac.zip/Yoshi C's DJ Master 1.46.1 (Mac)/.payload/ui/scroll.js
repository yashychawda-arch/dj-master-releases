// How the window scrolls. Shared by both apps; loaded after ui/vendor (GSAP, Lenis, Lenis Snap), before app.js.
//
//   1. The page itself never scrolls - only #main does. `overflow: hidden` is not a lock: scrollIntoView, a focus
//      jump or a #link can still push a box that "can't scroll", and that is what slid the top bar (the window's
//      own title bar, with its buttons) off the top of the window on Windows and the Mac. Nothing slid it back.
//      style.css pins the page (body fixed, overflow clip); this is the belt to those braces, for older web views:
//      anything that isn't a real scroller and finds itself scrolled is put straight back.
//   2. #main scrolls smoothly (Lenis) and settles on a section when you stop near its top (lenis/snap).
//   3. GSAP's ticker drives Lenis, so whatever GSAP animates stays in step with the scroll.
//   4. With pro.css, #main shows one section at a time; to() and into() switch to the target's section first.
//
// window.YCS
//   to(target, opts)   scroll #main to a section, an element or a number of pixels
//   into(el, block)    bring an element into view moving only #main - "start", "center" or "nearest"
//   show(target)       (pro.css) show the section holding target; true if it changed
//   refresh()          after the page's height changes
//   lenis, snap        the instances, or null with less motion or in a web view too old for them
//   view               (pro.css) the section showing, or null when the page is one long scroll
(function () {
  "use strict";
  const main = document.getElementById("main");
  const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ── 1. the page never scrolls ──
  const real = new WeakMap();                       // element -> is it meant to scroll?
  function scrolls(el) {
    if (!real.has(el)) {
      const cs = getComputedStyle(el);
      real.set(el, /(auto|scroll)/.test(cs.overflowY) || /(auto|scroll)/.test(cs.overflowX));
    }
    return real.get(el);
  }
  function pinPage() {
    const html = document.documentElement, body = document.body;
    if (html.scrollTop || html.scrollLeft) { html.scrollTop = 0; html.scrollLeft = 0; }
    if (body && (body.scrollTop || body.scrollLeft)) { body.scrollTop = 0; body.scrollLeft = 0; }
    if (window.scrollY || window.scrollX) window.scrollTo(0, 0);
  }
  addEventListener("scroll", e => {                  // capture: scroll events don't bubble
    const t = e.target;
    if (t === document || t === document.documentElement || t === document.body) return pinPage();
    if (t instanceof Element && (t.scrollTop || t.scrollLeft) && !scrolls(t)) { t.scrollTop = 0; t.scrollLeft = 0; }
  }, true);
  ["resize", "focus", "pageshow"].forEach(name => addEventListener(name, pinPage));
  document.addEventListener("focusin", pinPage);
  document.addEventListener("visibilitychange", pinPage);
  pinPage();

  // ── 2 and 3. #main: smooth, snapping, on GSAP's clock ──
  if (!Array.prototype.findLastIndex) {              // lenis/snap needs it; older Safari web views don't have it
    Object.defineProperty(Array.prototype, "findLastIndex", { configurable: true, writable: true, value(fn, self) {
      for (let i = this.length - 1; i >= 0; i--) if (fn.call(self, this[i], i, this)) return i;
      return -1;
    } });
  }
  let lenis = null, snap = null;
  const topIn = el => el.getBoundingClientRect().top - main.getBoundingClientRect().top + main.scrollTop;

  if (main && window.Lenis && !REDUCED) {
    try {
      lenis = new window.Lenis({ wrapper: main, content: main, eventsTarget: main, lerp: 0.14, smoothWheel: true,
        syncTouch: false, allowNestedScroll: true, autoRaf: false });
      main.style.scrollBehavior = "auto";            // Lenis does the easing; CSS smooth scrolling would fight it
      if (window.gsap) {
        window.gsap.ticker.add(time => lenis.raf(time * 1000));
        window.gsap.ticker.lagSmoothing(0);
      } else {
        const frame = time => { lenis.raf(time); requestAnimationFrame(frame); };
        requestAnimationFrame(frame);
      }
    } catch (err) {
      console.warn("smooth scrolling is off:", err);
      lenis = null;
    }
  }

  // Sections you settle on: stop within a short way of a section's top and it eases onto it. Never forced -
  // anywhere else on the page stays exactly where you left it.
  const sections = main ? [...main.querySelectorAll(":scope > section[id]")] : [];
  let unsnap = [];
  function setSnaps() {
    if (!snap) return;
    unsnap.forEach(off => off());
    unsnap = sections.filter(s => s.offsetParent !== null).map(s => snap.add(Math.max(0, Math.round(topIn(s)))));
  }
  if (lenis && window.Snap && sections.length) {
    try {
      snap = new window.Snap(lenis, { type: "proximity", distanceThreshold: 64, debounce: 160, lerp: 0.1 });
      setSnaps();
    } catch (err) {
      console.warn("section snapping is off:", err);
      snap = null;
    }
  }
  let soon = 0;
  function refresh() {
    clearTimeout(soon);
    soon = setTimeout(() => { if (lenis) lenis.resize(); setSnaps(); }, 120);
  }
  if (main && "ResizeObserver" in window) {
    const watch = new ResizeObserver(refresh);
    watch.observe(main);
    for (const child of main.children) watch.observe(child);
  }

  // ── 4. one section at a time (pro.css sets --pro-views: 1) ──
  // The side menu and every "go to" in the apps come through to() and into(), so they switch to the section that
  // holds the target first, then scroll within it. Without pro.css nothing here runs and the page is one long scroll.
  const VIEWS = !!main && getComputedStyle(document.documentElement).getPropertyValue("--pro-views").trim() === "1";
  let view = null;
  function sectionOf(el) {
    while (el && el.parentElement !== main) el = el.parentElement;
    return el && el.matches("section[id]") ? el : null;
  }
  function show(target) {
    if (!VIEWS) return false;
    const el = typeof target === "string" ? document.getElementById(target.replace(/^#/, "")) : target;
    const s = el && el.nodeType === 1 ? sectionOf(el) : null;
    if (!s || s === view) return false;
    if (view) view.classList.remove("is-view");
    view = s;
    s.classList.add("is-view");
    if (lenis) { lenis.resize(); lenis.scrollTo(0, { immediate: true, force: true }); }
    main.scrollTop = 0;
    refresh();
    if (!REDUCED && s.animate) {
      const frames = [{ opacity: 0, transform: "translateY(8px)" }, { opacity: 1, transform: "none" }];
      const spring = getComputedStyle(document.documentElement).getPropertyValue("--spring").trim();
      try { s.animate(frames, { duration: 420, easing: spring || "cubic-bezier(0.4, 0, 0.2, 1)" }); }
      catch (err) { s.animate(frames, { duration: 420, easing: "cubic-bezier(0.4, 0, 0.2, 1)" }); }
    }
    main.dispatchEvent(new Event("scroll"));         // the side menu lights the section now showing
    return true;
  }
  if (VIEWS && sections.length) {
    document.documentElement.classList.add("pro-views");
    // The status cells leave the top bar for a bar along the window's foot. They move in the page, not only in CSS:
    // the top bar's blur and entrance make it the frame a fixed child is placed in, so they'd stay at the top.
    const cells = document.getElementById("console");
    if (cells) document.body.append(cells);
    show(sections.find(s => !s.hidden) || sections[0]);
  }

  function to(target, opts = {}) {
    if (!main) return;
    const el = typeof target === "string" ? document.getElementById(target.replace(/^#/, "")) : target;
    if (VIEWS && el && el.nodeType === 1) {
      show(el);
      if (el === view) return to(0, opts);           // the section itself: its top
    }
    const top = typeof el === "number" ? el : el ? topIn(el) - (opts.offset || 0) : null;
    if (top == null) return;
    const y = Math.max(0, Math.min(top, main.scrollHeight - main.clientHeight));
    if (lenis) lenis.scrollTo(y, { immediate: !!opts.immediate, lerp: opts.immediate ? undefined : 0.11 });
    else main.scrollTo({ top: y, behavior: opts.immediate || REDUCED ? "auto" : "smooth" });
  }
  function into(el, block = "nearest", opts = {}) {
    if (!main || !el || !main.contains(el)) return;
    show(el);
    const box = main.getBoundingClientRect(), r = el.getBoundingClientRect();
    const top = topIn(el);
    if (block === "start") return to(top, opts);
    if (block === "center") return to(top - (box.height - r.height) / 2, opts);
    const pad = 24;
    if (r.top < box.top + pad) to(top - pad, opts);
    else if (r.bottom > box.bottom - pad) to(top - box.height + r.height + pad, opts);
  }

  window.YCS = { to, into, show, refresh, pinPage, get lenis() { return lenis; }, get snap() { return snap; }, get view() { return view; } };
})();
