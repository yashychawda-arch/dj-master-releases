// Phone remote: talks to remote.py in the desktop app. The pairing key arrives in the URL's #fragment
// (from the QR code) and stays there, so "Add to Home Screen" keeps it - iOS gives home-screen apps
// their own storage, which would otherwise start empty.
(() => {
  const $ = s => document.querySelector(s);
  const SOURCE = { youtube: "YouTube", spotify: "Spotify", applemusic: "Apple Music", soundcloud: "SoundCloud" };
  // Requests sent from a phone come down as 320 kbps MP3s; what the DJ downloads on the computer is
  // still WAV. The phone shows both, so it says which is which.
  // The shop edition downloads nothing - a request is the song's name - so there's no format to give.
  let fetchOn = true;
  const what = j => (!fetchOn ? "" : j.from_phone ? "MP3 · from a phone" : "WAV");

  const hash = new URLSearchParams(location.hash.slice(1));
  let key = hash.get("k") || "";
  try {
    if (key) localStorage.setItem("djMasterKey", key);
    else key = localStorage.getItem("djMasterKey") || "";
  } catch (err) { /* private browsing */ }
  const sharedText = hash.get("url") || "";
  if (key) history.replaceState(null, "", `${location.pathname}#k=${encodeURIComponent(key)}`);

  const state = { preview: null, lookupId: null, picks: null, jobs: [], busyLookup: false, lastOk: 0, timer: 0, search: null };

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function toast(text, bad) {
    const t = el("div", "toast" + (bad ? " bad" : ""), text);
    $("#toasts").append(t);
    setTimeout(() => t.remove(), bad ? 6000 : 2800);
  }

  // A random token this phone keeps for itself, so the booth link can show a guest the requests
  // they sent and nobody else's. It identifies nothing but this browser.
  let guest = "";
  try { guest = localStorage.getItem("djMasterGuest") || ""; } catch (e) {}
  if (!/^[0-9a-f]{32}$/.test(guest)) {
    guest = [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, "0")).join("");
    try { localStorage.setItem("djMasterGuest", guest); } catch (e) {}
  }
  // The booth link is in a stranger's hand: no stop buttons, no set-up help, no copy of the key.
  let booth = location.pathname.startsWith("/booth");
  let closed = false;
  const markBooth = () => {
    document.querySelectorAll(".owner-only").forEach(n => (n.hidden = booth));
    document.body.classList.toggle("booth", booth);
    $("#link").placeholder = booth ? "Song or artist" : "Search a song, or paste a link";
    $("#jobs-h").textContent = booth ? "Your requests" : "Requests";
    $("#hint").hidden = !booth || closed;
  };
  markBooth();

  async function call(path, body) {
    const res = await fetch(path, {
      method: body ? "POST" : "GET",
      headers: { "X-Stem-Key": key, "X-Guest": guest, ...(body ? { "Content-Type": "application/json" } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      cache: "no-store",
    });
    if (res.status === 401) { showUnpaired(); throw new Error("unpaired"); }
    if (!res.ok && res.status !== 200) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  function showUnpaired() {
    $("#unpaired").hidden = false;
    $("#main").hidden = true;
    setConn("off", "Not linked");
  }

  // The phone follows the theme chosen on the computer.
  let accentNow = "";
  function setAccent(hex) {
    if (!/^#[0-9a-f]{6}$/i.test(hex || "") || hex === accentNow) return;
    accentNow = hex;
    const rgb = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16)).join(" ");
    document.documentElement.style.setProperty("--signal-rgb", rgb);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = hex;
  }

  function setConn(kind, text) {
    $("#conn").dataset.state = kind;
    $("#conn-text").textContent = text;
  }

  // ── polling ──────────────────────────────────────────────────────────
  async function poll() {
    clearTimeout(state.timer);
    if (!key) { showUnpaired(); return; }
    let busy = false;
    try {
      const s = await call("/api/state");
      state.lastOk = Date.now();
      $("#unpaired").hidden = true;
      $("#main").hidden = false;
      const d = s.device;
      setAccent(s.accent);
      if (!!s.booth !== booth) { booth = !!s.booth; markBooth(); }
      if (booth) setConn(s.event && s.event.closed ? "closed" : "ok", s.event && s.event.closed ? "Requests closed" : "Requests open");
      else setConn("ok", d ? `${d.name}${d.backend ? " · " + d.backend : ""}` : s.pc || "Connected");
      if ((s.fetch !== false) !== fetchOn) {
        fetchOn = s.fetch !== false;
        $("#lede").textContent = fetchOn
          ? "Search for a song, or paste a link. It downloads to the DJ's computer as a 320 kbps MP3, ready to play."
          : "Search for a song, or paste a link to it, and it goes straight to the DJ.";
      }
      renderJobs(s.jobs);
      renderEvent(s.event, s.board);
      $("#foot").textContent = booth
        ? `Requests for ${s.dj || "the DJ"} · DJ Master ${s.version}`
        : `Linked to ${s.dj ? s.dj + " on " : ""}${s.pc} · DJ Master ${s.version}`;
      busy = s.jobs.some(j => j.status === "running" || j.status === "waiting");
    } catch (err) {
      if (err.message === "unpaired") return;
      setConn("off", booth ? "Can't reach the DJ" : "Can't reach your computer");
    }
    document.body.classList.toggle("busy", busy);
    if (!document.hidden) state.timer = setTimeout(poll, busy ? 1500 : 4000);
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) poll(); });
  window.addEventListener("pageshow", () => poll());

  // The list is rebuilt on every poll; reusing each thumbnail's <img> keeps it from reloading and flickering.
  const thumbs = new Map();
  function thumb(url) {
    if (!url) return el("div", "th");
    if (!thumbs.has(url)) {
      const img = el("img", "th");
      img.alt = "";
      img.onerror = () => (img.style.visibility = "hidden");
      img.src = url;
      thumbs.set(url, img);
    }
    return thumbs.get(url);
  }

  function renderJobs(jobs) {
    const list = $("#jobs");
    const live = s => s === "running" || s === "waiting" || s === "held" || s === "wanted";
    const active = jobs.filter(j => j.status === "running")
      .concat(jobs.filter(j => j.status === "waiting"), jobs.filter(j => j.status === "wanted"), jobs.filter(j => j.status === "held"));
    const done = jobs.filter(j => !live(j.status) && j.status !== "declined").concat(jobs.filter(j => j.status === "declined"));
    const rows = [];
    let n = 0;
    active.forEach(j => rows.push(jobRow(j, ++n)));
    if (done.length) {
      rows.push(el("li", "group-label", booth ? "Earlier" : "Finished"));
      done.forEach(j => rows.push(jobRow(j)));
    }
    list.replaceChildren(...rows);
    $("#jobs-empty").hidden = jobs.length > 0;
  }

  // ── the booth link's own things: the night's name, whether it's open, and the votes ──
  // (closed is declared up top: markBooth reads it)
  let eventKey = "";
  const DEFAULT_LEDE = () => $("#lede").dataset.base || $("#lede").textContent;
  function renderEvent(ev, board) {
    const wrap = $("#board-wrap");
    if (!booth || !ev) { $("#event-k").hidden = true; $("#allow").hidden = true; wrap.hidden = true; return; }
    if (!$("#lede").dataset.base) $("#lede").dataset.base = $("#lede").textContent;
    // The night's name is what a guest scanned the code for, so it is the headline. Rebuilt only when it changes.
    const k = [ev.title, ev.note, ev.closed].join("\u0001");
    if (k !== eventKey) {
      eventKey = k;
      closed = !!ev.closed;
      const h = $("#headline");
      if (ev.title) {
        h.classList.add("named");
        h.textContent = ev.title;
        $("#event-k").hidden = false;
        $("#event-k").textContent = closed ? "Requests closed" : "Song requests";
      } else {
        $("#event-k").hidden = true;
        h.classList.remove("named");
        h.innerHTML = closed ? "Requests are <em>closed.</em>" : "Request <em>a track.</em>";
      }
      $("#lede").textContent = closed ? (ev.note || "The DJ has what they need for now. Thanks for asking.") : (ev.note || DEFAULT_LEDE());
      $("#link-form").hidden = closed;
      $("#hint").hidden = closed;
      if (closed) closePreview();
    }
    renderAllowance(ev);
    board = board || [];
    wrap.hidden = !ev.votes || !board.length;
    $("#board-tip").hidden = closed;
    renderBoard(board);
  }

  // ●●●○○ 3 requests left - only when the DJ has set a limit.
  function renderAllowance(ev) {
    const box = $("#allow");
    if (!ev.limit || ev.left == null || closed) { box.hidden = true; return; }
    box.hidden = false;
    const dots = $("#allow-dots");
    if (dots.childElementCount !== ev.limit) dots.replaceChildren(...Array.from({ length: ev.limit }, () => el("i")));
    [...dots.children].forEach((d, i) => d.classList.toggle("on", i < ev.left));
    $("#allow-text").textContent = ev.left ? `${ev.left} request${ev.left === 1 ? "" : "s"} left tonight` : "That's all your requests for tonight";
    box.classList.toggle("spent", !ev.left);
  }

  // Most wanted first, numbered. Rows are kept by id and slid to their new place when the order changes,
  // so a guest sees their vote move a song up rather than the list just redrawing.
  const boardRows = new Map();
  function renderBoard(board) {
    const list = $("#board");
    const before = new Map([...boardRows].map(([id, li]) => [id, li.getBoundingClientRect().top]));
    const keep = new Set();
    const rows = board.map((b, i) => {
      keep.add(b.id);
      let li = boardRows.get(b.id);
      if (!li) {
        li = el("li", "ask");
        li.append(el("span", "rank"), el("div", "body"), el("button", "vote"));
        li.children[1].append(el("span", "title"), el("span", "sub"));
        li.lastChild.type = "button";
        boardRows.set(b.id, li);
      }
      li.className = "ask" + (b.yes ? " yes" : "") + (b.mine ? " mine" : "");
      li.children[0].textContent = String(i + 1);
      li.children[1].children[0].textContent = b.title || "Untitled";
      li.children[1].children[1].textContent = [b.subtitle, b.yes ? "Coming up" : ""].filter(Boolean).join(" · ");
      const vote = li.lastChild;
      vote.className = "vote" + (b.mine ? " mine" : "");
      vote.textContent = b.mine ? `✓ ${b.votes}` : `+ ${b.votes}`;
      vote.disabled = b.mine || closed;
      vote.setAttribute("aria-label", b.mine ? `${b.votes} want this, you included` : `${b.votes} want this - add your vote`);
      vote.onclick = async () => {
        vote.disabled = true;
        try {
          const r = await call("/api/vote", { job: b.id });
          if (!r.ok) toast(r.error || "Couldn't add your vote", true);
          else { vote.textContent = `✓ ${r.votes}`; vote.classList.add("mine"); }
        } catch (err) { toast("Couldn't reach the DJ", true); }
        poll();
      };
      return li;
    });
    for (const id of [...boardRows.keys()]) if (!keep.has(id)) boardRows.delete(id);
    list.replaceChildren(...rows);
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    rows.forEach(li => {
      const id = [...boardRows].find(([, v]) => v === li)[0];
      if (!before.has(id)) return;
      const dy = before.get(id) - li.getBoundingClientRect().top;
      if (Math.abs(dy) < 2) return;
      li.animate([{ transform: `translateY(${dy}px)` }, { transform: "none" }], { duration: 420, easing: "cubic-bezier(0.16, 1, 0.3, 1)" });
    });
  }

  // What a guest's own request is doing, as a coloured chip they can read across a dark room.
  function chip(text, kind) { return el("span", "chip " + kind, text); }

  function jobRow(j, n) {
    const li = el("li", `job ${j.status}`);
    const th = thumb(j.thumbnail);
    const body = el("div", "body");
    body.append(el("span", "title", j.title || "Untitled"));
    const side = el("div", "side");
    let sub;
    if (booth && (j.status === "running" || j.status === "waiting")) {
      sub = chip("Coming up", "yes");
    } else if (j.status === "running") {
      sub = el("span", "sub", `${j.stage || "Working"} · ${what(j)}`);
      side.append(el("span", "pct", `${Math.round((j.progress || 0) * 100)}%`));
      if (!booth) side.append(cancelButton(j));
      const bar = el("i", "bar");
      bar.style.transform = `scaleX(${Math.max(0.02, j.progress || 0)})`;
      li.append(bar);
    } else if (j.status === "waiting") {
      sub = el("span", "sub", [String(n).padStart(2, "0"), j.subtitle, what(j)].filter(Boolean).join(" · "));
      if (!booth) side.append(cancelButton(j));
    } else if (j.status === "held") {
      sub = booth ? chip("Waiting for the DJ", "wait") : el("span", "sub", "Sent · waiting for the DJ to say yes");
    } else if (j.status === "declined") {
      sub = chip("Not tonight", "no");
    } else if (booth && (j.status === "wanted" || j.status === "done")) {
      sub = chip("Coming up", "yes");
    } else if (j.status === "wanted") {
      sub = el("span", "sub", booth ? "The DJ said yes" : [j.subtitle, "to buy, in DJ Master"].filter(Boolean).join(" · "));
    } else if (j.status === "done") {
      const a = j.analysis || {};
      const facts = [a.bpm ? `${a.bpm} BPM` : "", a.key || "", a.camelot || ""].filter(Boolean).join(" · ");
      sub = el("span", "sub ok", `✓ ${j.from_phone ? "Sent to the DJ" : "In the crate"}${facts ? " · " + facts : ""}`);
    } else if (j.status === "error") {
      sub = booth ? chip("Couldn't be found", "no") : el("span", "sub bad", j.error || "Failed");
      const retry = el("button", "retry", "Retry");
      retry.type = "button";
      retry.onclick = async () => {
        retry.disabled = true;
        try { await call("/api/retry", { job: j.id }); toast("Trying again"); } catch (err) { toast("Couldn't reach your computer", true); }
        poll();
      };
      if (!booth) side.append(retry);                  // retrying is the DJ's call
    } else {
      sub = el("span", "sub", "Cancelled");
    }
    body.append(sub);
    li.append(th, body, side);
    return li;
  }

  function cancelButton(j) {
    const x = el("button", "x", "×");
    x.type = "button";
    x.setAttribute("aria-label", `Cancel ${j.title}`);
    x.onclick = async () => {
      const running = j.status === "running";
      if (!confirm(running ? `Stop downloading "${j.title}"?` : `Take "${j.title}" out of the queue?`)) return;
      try { await call("/api/cancel", { job: j.id }); } catch (err) { toast("Couldn't reach your computer", true); }
      poll();
    };
    return x;
  }

  // ── link lookup ──────────────────────────────────────────────────────
  const input = $("#link");
  const form = $("#link-form");
  const firstUrl = text => (String(text).match(/https?:\/\/[^\s<>"']+/i) || [""])[0];

  input.addEventListener("input", () => { $("#clear").hidden = !input.value; });
  $("#clear").onclick = () => { input.value = ""; $("#clear").hidden = true; closePreview(); input.focus(); };
  input.addEventListener("paste", () => setTimeout(() => { if (firstUrl(input.value)) lookup(); }, 30));
  form.addEventListener("submit", e => { e.preventDefault(); submit(); });

  // Anything that isn't a link is treated as a song to search for.
  async function submit() {
    const url = firstUrl(input.value);
    if (url) return lookup();
    const query = input.value.trim();
    if (query.length < 2) { toast("Type a song name, or paste a link", true); return; }
    return search(query);
  }

  async function search(query) {
    if (state.busyLookup) return;
    input.blur();
    state.busyLookup = true;
    form.classList.add("loading");
    const box = $("#preview");
    const loading = el("div", "loading-card");
    loading.append(el("span", "spinner"), el("span", null, `Searching for “${query}”…`));
    box.replaceChildren(loading);
    box.hidden = false;
    try {
      const r = await call("/api/search", { query });
      if (!r.ok) { closePreview(); toast(r.error || "Nothing found", true); return; }
      state.preview = null;
      state.picks = null;
      state.lookupId = r.id;
      state.search = r;
      renderResults();
    } catch (err) {
      if (err.message !== "unpaired") { closePreview(); toast("Couldn't reach your computer", true); }
    } finally {
      state.busyLookup = false;
      form.classList.remove("loading");
    }
  }

  function renderResults() {
    const r = state.search;
    const box = $("#preview");
    const head = el("div", "search-head");
    head.append(el("span", "label", "Results"), el("span", null, `for “${r.query}” — tap one to send it`));
    const list = el("ul", "results");
    r.results.forEach((hit, i) => {
      const li = el("li");
      const b = el("button");
      b.type = "button";
      if (hit.thumbnail) {
        const img = el("img");
        img.src = hit.thumbnail;
        img.alt = "";
        img.onerror = () => img.replaceWith(el("div", "ph"));
        b.append(img);
      } else b.append(el("div", "ph"));
      const t = el("div", "rt");
      t.append(el("b", null, hit.title || "Untitled"), el("span", null, hit.by || ""));
      b.append(t, el("span", "rlen" + (hit.mix ? " mix" : ""), hit.mix ? `Mix · ${hit.length}` : hit.length || ""));   // a mix's tempo and key mean nothing
      b.onclick = () => {
        list.querySelectorAll("button").forEach(x => (x.disabled = true));
        b.replaceChildren(el("span", "spinner"), el("div", "rt", "Sending…"));
        queue({ index: i });
      };
      li.append(b);
      list.append(li);
    });
    const actions = el("div", "pv-actions");
    const dismiss = el("button", "pv-dismiss", "Dismiss");
    dismiss.type = "button";
    dismiss.onclick = () => { input.value = ""; $("#clear").hidden = true; closePreview(); };
    actions.append(dismiss);
    box.replaceChildren(head, list, actions);
    box.hidden = false;
    box.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  async function lookup() {
    const url = firstUrl(input.value);
    if (!url) { toast("Paste a song, album or playlist link", true); return; }
    if (state.busyLookup) return;
    input.value = url;
    $("#clear").hidden = false;
    input.blur();
    state.busyLookup = true;
    form.classList.add("loading");
    const box = $("#preview");
    const loading = el("div", "loading-card");
    loading.append(el("span", "spinner"), el("span", null, !fetchOn ? "Reading the song's name…"
      : /spotify|apple/i.test(url) ? "Looking it up and finding it on YouTube…" : "Looking it up…"));
    box.replaceChildren(loading);
    box.hidden = false;
    try {
      const r = await call("/api/resolve", { url });
      if (!r.ok) { closePreview(); toast(r.error || "Couldn't read that link", true); return; }
      state.preview = r.info;
      state.lookupId = r.id;
      state.picks = r.info.collection ? new Set(r.info.tracks.map((_, i) => i)) : null;
      renderPreview();
    } catch (err) {
      if (err.message !== "unpaired") { closePreview(); toast("Couldn't reach your computer", true); }
    } finally {
      state.busyLookup = false;
      form.classList.remove("loading");
    }
  }

  function closePreview() {
    state.preview = state.lookupId = state.picks = state.search = null;
    $("#preview").hidden = true;
    $("#preview").replaceChildren();
  }

  function renderPreview() {
    const info = state.preview;
    const box = $("#preview");
    const main = el("div", "pv-main");
    if (info.thumbnail) {
      const img = el("img");
      img.src = info.thumbnail;
      img.alt = "";
      img.onerror = () => img.replaceWith(el("div", "ph"));
      main.append(img);
    } else {
      main.append(el("div", "ph"));
    }
    const meta = el("div");
    meta.style.minWidth = "0";
    const kind = SOURCE[info.kind] || "Link";
    const label = info.link ? `From ${info.link} · just the song's name`
      : info.collection ? `${kind} ${info.collection_type || "playlist"} · ${info.tracks.length} songs` : `From ${kind}`;
    meta.append(el("span", "label", label), el("h3", "pv-title", info.title || "Untitled"));
    if (info.artist) meta.append(el("span", "pv-artist", info.artist));
    main.append(meta);
    const parts = [main];

    const facts = el("div", "pv-facts");
    if (!info.collection) {
      if (info.length) facts.append(el("span", null, `Length ${info.length}${info.bitrate ? ` · source ~${info.bitrate} kbps` : ""}`));
      if (info.match) {
        const diff = info.duration && info.match.duration ? Math.abs(info.duration - info.match.duration) : 0;
        facts.append(el("span", diff > 12 ? "warn" : "good",
          `Found on YouTube: ${info.match.channel || info.match.title || "a match"}${info.match.length ? " · " + info.match.length : ""}${diff > 12 ? " (different length, check it)" : ""}`));
      }
    }
    if (info.note) facts.append(el("span", "warn", info.note));
    if (facts.childElementCount) parts.push(facts);

    if (info.collection) {
      const all = el("div", "allrow");
      const lab = el("label");
      const allBox = el("input", "check");
      allBox.type = "checkbox";
      lab.append(allBox, el("span", null, "All songs"));
      const count = el("span");
      all.append(lab, count);
      const ul = el("ul", "tracks");
      const boxes = info.tracks.map((t, i) => {
        const li = el("li");
        const l = el("label");
        const cb = el("input", "check");
        cb.type = "checkbox";
        cb.checked = true;
        cb.onchange = () => { cb.checked ? state.picks.add(i) : state.picks.delete(i); sync(); };
        const txt = el("span");
        txt.style.minWidth = "0";
        txt.append(el("span", "t-title", t.title || "Untitled"), el("span", "t-artist", t.artist || ""));
        l.append(cb, txt, el("span", "t-len", t.length || ""));
        li.append(l);
        ul.append(li);
        return cb;
      });
      allBox.onchange = () => {
        boxes.forEach((cb, i) => { cb.checked = allBox.checked; allBox.checked ? state.picks.add(i) : state.picks.delete(i); });
        sync();
      };
      function sync() {
        allBox.checked = state.picks.size === info.tracks.length;
        count.textContent = `${state.picks.size} of ${info.tracks.length}`;
        box.querySelectorAll(".pv-actions .btn").forEach(b => (b.disabled = state.picks.size === 0));
      }
      parts.push(all, ul);
      setTimeout(sync);
    }

    // Requests from the phone are plain MP3s only: one button, no options. (The DJ's own downloads
    // on the computer are still WAV - a request is for the floor, so it comes down as a 320 kbps MP3.)
    const actions = el("div", "pv-actions");
    const button = (cls, text, fn) => { const b = el("button", cls, text); b.type = "button"; b.onclick = fn; return b; };
    actions.append(
      button("btn primary wide", !fetchOn ? "Request it" : info.collection ? "Get the songs" : "Get the song", () => queue()),
      button("pv-dismiss", "Dismiss", () => { input.value = ""; $("#clear").hidden = true; closePreview(); }));
    parts.push(actions);
    box.replaceChildren(...parts);
    box.hidden = false;
    box.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  async function queue(extra) {
    if (!state.lookupId) return;
    const buttons = $("#preview").querySelectorAll(".btn");
    buttons.forEach(b => (b.disabled = true));
    const body = { id: state.lookupId, ...(extra || {}) };
    if (state.picks) body.indices = [...state.picks];
    try {
      const r = await call("/api/queue", body);
      if (!r.ok) {
        toast(r.error || "Couldn't queue that", true);
        buttons.forEach(b => (b.disabled = false));
        if (state.search) renderResults();
        return;
      }
      toast(r.voted ? "Someone asked for that already - your vote is added" : !fetchOn ? "Sent to the DJ" : r.added > 1 ? `${r.added} songs on their way` : "On its way to your computer");
      input.value = "";
      $("#clear").hidden = true;
      closePreview();
      poll();
      $("#jobs").scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (err) {
      if (err.message !== "unpaired") toast("Couldn't reach your computer", true);
      buttons.forEach(b => (b.disabled = false));
      if (state.search) renderResults();
    }
  }

  // ── share shortcut address ───────────────────────────────────────────
  const shareUrl = `${location.origin}/#k=${encodeURIComponent(key)}&url=`;
  if (!booth) $("#share-url").value = shareUrl;          // never hand a guest a copy of the key
  $("#share-copy").onclick = async () => {
    const field = $("#share-url");
    let ok = false;
    try { await navigator.clipboard.writeText(shareUrl); ok = true; } catch (err) { /* needs https; fall back */ }
    if (!ok) {
      field.focus();
      field.setSelectionRange(0, shareUrl.length);
      try { ok = document.execCommand("copy"); } catch (err) { ok = false; }
    }
    toast(ok ? "Copied" : "Select the address and copy it", !ok);
  };

  poll();
  if (sharedText && firstUrl(sharedText)) {
    input.value = firstUrl(sharedText);
    $("#clear").hidden = false;
    lookup();
  }
})();
