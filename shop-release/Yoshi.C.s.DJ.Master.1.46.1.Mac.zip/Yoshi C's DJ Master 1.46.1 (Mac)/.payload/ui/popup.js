// The request pop-up. It asks DJ Master what's waiting (window.pywebview.api.state) and answers through
// the same approve and turn-down the app uses. Song titles came from strangers: text only, never markup.
(() => {
  const $ = (id) => document.getElementById(id);
  const api = () => window.pywebview && window.pywebview.api;
  let current = null, busy = false;

  function ago(seconds) {
    if (!seconds) return "";
    const m = Math.round((Date.now() / 1000 - seconds) / 60);
    return m < 1 ? "just now" : m < 60 ? `${m} min ago` : `${Math.floor(m / 60)} h ago`;
  }

  function cover(r) {
    if (!/^https:\/\//.test(r.art || "")) {
      const s = document.createElement("span");
      s.className = "cover";
      return s;
    }
    const img = document.createElement("img");
    img.className = "cover";
    img.alt = "";
    img.referrerPolicy = "no-referrer";
    img.onerror = () => img.replaceWith(Object.assign(cover({}), { id: img.id }));
    img.src = r.art;
    return img;
  }

  // A notice rather than a request ("12 tracks ready"): no Play it or No, and the whole card opens the app.
  function drawNote(n) {
    const card = $("card");
    if (!card.classList.contains("note") || current) {
      card.classList.remove("in");
      void card.offsetWidth;
      card.classList.add("in");
    }
    card.classList.add("note");
    current = null;
    $("kicker").textContent = n.title || "DJ Master";
    $("count").textContent = "";
    $("title").textContent = n.text || "";
    $("title").title = "";
    $("sub").textContent = n.sub || "";
    const old = $("cover");
    if (old) old.replaceWith(Object.assign(cover({}), { id: "cover" }));
    $("acts").hidden = false;
    $("done").hidden = true;
    for (const b of $("acts").querySelectorAll("button")) b.disabled = false;
  }

  function draw(s) {
    if (/^#[0-9a-f]{6}$/i.test(s.accent || "")) document.documentElement.style.setProperty("--signal", s.accent);
    const list = s.requests || [];
    const r = list[list.length - 1];                   // the one that just came in
    if (!r && s.note) return drawNote(s.note);
    $("card").classList.remove("note");
    $("kicker").textContent = "New request";
    $("count").textContent = list.length > 1 ? `${list.length} waiting` : "";
    if (!r) return;
    if (!current || current.id !== r.id) {
      const card = $("card");
      card.classList.remove("in");
      void card.offsetWidth;
      card.classList.add("in");
      const old = $("cover");
      if (old) old.replaceWith(Object.assign(cover(r), { id: "cover" }));
    }
    current = r;
    $("title").textContent = r.title || "A song";
    $("title").title = r.title || "";
    $("sub").textContent = [r.sub, ago(r.added)].filter(Boolean).join(" · ");
    $("acts").hidden = false;
    $("done").hidden = true;
    for (const b of $("acts").querySelectorAll("button")) b.disabled = false;
  }

  async function refresh() {
    const a = api();
    if (busy || !a) return;
    try { draw(await a.state()); } catch (e) { /* the app is busy; the next refresh catches up */ }
  }

  async function answer(action) {
    const a = api();
    if (!current || busy || !a) return;
    busy = true;
    for (const b of $("acts").querySelectorAll("button")) b.disabled = true;
    let r;
    try { r = await a.answer(current.id, action); } catch (e) { r = { ok: false }; }
    if (!r || !r.ok) {
      busy = false;
      $("sub").textContent = (r && r.error) || "That didn't go through.";
      for (const b of $("acts").querySelectorAll("button")) b.disabled = false;
      return;
    }
    $("acts").hidden = true;
    const done = $("done");
    done.className = "done" + (action === "no" ? " no-go" : "");
    done.textContent = action === "play" ? "Playing it · downloading now" : "Turned down";
    done.hidden = false;
    setTimeout(async () => {
      busy = false;
      try { await a.settle(); } catch (e) {}
      refresh();
    }, 1100);
  }

  $("play").onclick = () => answer("play");
  $("no").onclick = () => answer("no");
  $("open").onclick = () => { const a = api(); if (a) a.open(); };
  $("dismiss").onclick = (e) => { e.stopPropagation(); const a = api(); if (a) a.dismiss(); };
  // A notice opens DJ Master wherever it's clicked, the way a notification does.
  $("card").addEventListener("click", (e) => {
    if ($("card").classList.contains("note") && !e.target.closest("button")) { const a = api(); if (a) a.open(); }
  });
  // The card goes by itself after a few seconds - but not from under the pointer.
  $("card").addEventListener("mouseenter", () => { const a = api(); if (a && a.hold) a.hold(true); });
  $("card").addEventListener("mouseleave", () => { const a = api(); if (a && a.hold) a.hold(false); });
  document.addEventListener("contextmenu", (e) => e.preventDefault());
  window.popup = { refresh };
  window.addEventListener("pywebviewready", refresh);
  setInterval(refresh, 30000);                          // "2 min ago" keeps up
  if (api()) refresh();
})();
