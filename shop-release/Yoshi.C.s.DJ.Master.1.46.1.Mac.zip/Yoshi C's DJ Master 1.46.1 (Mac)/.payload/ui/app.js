(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };

  const state = { settings: {}, jobs: new Map(), crate: new Map(), requests: new Map(), store: "crate",
                  requestsDir: "", preview: null, pick: 0, selected: null, resolving: false,
                  active: null, platform: "windows", dj: "" };
  const store = () => (state.store === "requests" ? state.requests : state.crate);
  const trackById = id => state.crate.get(id) || state.requests.get(id);
  let rbInfo = null, rbTimer = 0;
  const ago = t => {
    const s = Math.max(0, Date.now() / 1000 - t);
    return s < 20 ? "just now" : s < 90 ? `${Math.round(s)} s ago` : s < 5400 ? `${Math.round(s / 60)} min ago` : `${Math.round(s / 3600)} h ago`;
  };
  let api = null;
  const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const EASE = "cubic-bezier(0.16, 1, 0.3, 1)";

  // ── intro ──────────────────────────────────────────────────────────────
  // Same count-up as the Stem Splitter: honest steps, eased, never faster than ~40%/s. Order on screen:
  // intro (with the DJ name, once there is one) → the intro parts and clears → password screen → depth
  // transition into the app. Nothing behind the lock shows before the password.
  const intro = $("#intro");
  const introStart = performance.now();
  // Long enough to be seen, short enough that nobody waits for it. Everything here is time the
  // app spends waiting for itself, so it is kept to the minimum that still reads as deliberate.
  const MIN_INTRO = 1200;
  const INTRO_EXIT = 800;           // seam + both halves fully off screen (style.css .intro-slice / .intro-seam)
  let introHoldUntil = introStart + MIN_INTRO;
  let introDone = false;
  document.documentElement.classList.add("booting", "locked");
  const nameEl = $("#intro-name");
  const letters = nameEl.textContent;
  nameEl.textContent = "";
  [...letters].forEach((ch, i) => {
    const s = el("span", null, ch);
    s.style.animationDelay = `${0.45 + i * 0.07}s`;
    nameEl.append(s);
  });

  function finishIntro() {
    if (introDone) return;
    introDone = true;
    if (REDUCED) {
      intro.classList.add("gone");
      document.documentElement.classList.remove("booting");
      openGate();
      return;
    }
    $("#intro-fill").style.transform = "scaleX(1)";
    intro.classList.add("settled");
    // The way in. The splash used to split in two and the sign-in faded in behind it: three scenes.
    // Now everything on the splash fades except its red line, which travels down to become the edge of
    // the first field on the sign-in card, and the card assembles around it. One continuous move.
    const ruleEl = $(".intro-rule");
    const rule = ruleEl.getBoundingClientRect();
    const line = el("div", "handoff-line");
    Object.assign(line.style, { left: `${rule.left}px`, top: `${rule.top}px`, width: `${rule.width}px` });
    document.body.append(line);
    ruleEl.style.visibility = "hidden";
    gate.classList.add("handoff");
    openGate();                                          // lays the card out; its parts start hidden
    void gate.offsetWidth;
    const field = [...gate.querySelectorAll("form:not([hidden]) input")].find(i => i.offsetParent);
    intro.classList.add("fading");
    if (field) {
      const to = field.getBoundingClientRect();
      line.animate([{ transform: "none" }, { transform: `translate(${to.left - rule.left}px, ${to.bottom - 1 - rule.top}px) scaleX(${to.width / Math.max(1, rule.width)})` }],
        { duration: 1100, easing: "cubic-bezier(0.16, 1, 0.3, 1)", fill: "forwards" });
    }
    setTimeout(() => gate.classList.add("assemble"), 560);
    setTimeout(() => {
      intro.classList.add("gone");
      line.remove();
      gate.classList.remove("handoff", "assemble");
      document.documentElement.classList.remove("booting");
    }, 1350);
  }

  // The DJ name, wherever it appears (startup, sign-in, homepage): every letter arrives out of focus,
  // low and a shade too big, and sharpens a beat after the one before it. Words stay whole so a long
  // name wraps between words, never mid-word. Plays once, then holds still.
  function spellName(box, name, startDelay = 0.1) {
    if (!box) return 0;
    let i = 0;
    box.replaceChildren(...String(name).split(" ").filter(Boolean).map((word, w) => {
      const wrap = el("span", "word" + (w === 0 && /^dj$/i.test(word) ? " dj" : ""));
      [...word].forEach(ch => {
        const c = el("span", "ch", ch);
        c.style.setProperty("--d", `${startDelay + i++ * 0.045}s`);
        wrap.append(c);
      });
      i++;
      return wrap;
    }));
    box.classList.remove("go");
    requestAnimationFrame(() => requestAnimationFrame(() => box.classList.add("go")));
    return REDUCED ? 0 : (startDelay + i * 0.045) * 1000 + 900;
  }

  // On the loading screen the name is simply there once the backend says who it is - the row opens and
  // the "DJ" tag lands, and that's all. (The letter animation still plays on the sign-in card and the
  // homepage, where it isn't competing with the rest of the intro.)
  function showIntroName(name) {
    if (!name) return;
    $("#intro-dj-name").textContent = name.toUpperCase();
    requestAnimationFrame(() => requestAnimationFrame(() => $("#intro-dj").classList.add("show")));
    introHoldUntil = Math.max(introHoldUntil, performance.now() + (REDUCED ? 0 : 420));
  }

  const loading = { target: 0, shown: 0 };
  const STEPS = { page: [25, "Loading interface"], fonts: [45, "Setting type"], bridge: [75, "Connecting"], boot: [100, "Ready"] };
  function step(name, statusOverride) {
    const [value, status] = STEPS[name];
    if (value <= loading.target) return;
    loading.target = value;
    $("#intro-status").textContent = statusOverride || status;
  }
  // The counter may not outrun the steps it is counting, but it needn't crawl either: at 40%/s
  // it could not reach 100 in under two and a half seconds however quickly the app was ready.
  const COUNT_DELAY = 180, MAX_RATE = 135;
  let countStart = null, lastTick = null;
  function tickLoading(now) {
    if (introDone) return;
    if (document.visibilityState !== "visible") { requestAnimationFrame(tickLoading); return; }
    if (countStart === null) countStart = now;
    if (now - countStart < COUNT_DELAY) { lastTick = now; requestAnimationFrame(tickLoading); return; }
    const dt = Math.min(64, now - (lastTick || now)) / 1000;
    lastTick = now;
    const gap = loading.target - loading.shown;
    const eased = Math.max(gap * 3.2 * dt, gap > 0 ? 6 * dt : 0);
    loading.shown = Math.min(loading.target, loading.shown + Math.min(eased, MAX_RATE * dt));
    const n = Math.floor(loading.shown);
    const digits = String(n).padStart(3, "0");
    const lead = digits.match(/^0*/)[0].slice(0, n === 0 ? 2 : undefined);
    $("#intro-count").innerHTML = `<span class="lead">${lead}</span>${digits.slice(lead.length)}`;
    $("#intro-fill").style.transform = `scaleX(${loading.shown / 100})`;
    if (loading.shown >= 100) {
      setTimeout(finishIntro, Math.max(180, introHoldUntil - performance.now()));
      return;
    }
    requestAnimationFrame(tickLoading);
  }
  requestAnimationFrame(tickLoading);
  step("page");
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(() => step("fonts"));
  intro.addEventListener("click", () => { if (boot) finishIntro(); });

  // ── helpers ────────────────────────────────────────────────────────────
  // A toast you can act on. Used by Delete: the file is already in the Recycle Bin, so putting it
  // back is a thing the app can offer rather than something you leave the app to do.
  function toastWithAction(msg, label, action, ms = 10000, keys = "") {
    const box = $("#toasts");
    const t = el("div", "toast has-action");
    t.setAttribute("role", "status");
    const doIt = el("button", "toast-action", label);
    doIt.type = "button";
    const close = el("button", "toast-x", "\u00d7");
    close.type = "button";
    close.setAttribute("aria-label", "Close message");
    t.append(el("span", null, msg), doIt);
    if (keys) t.append(el("kbd", null, keys));            // the shortcut that does the same (Ctrl Z for Undo)
    t.append(close);
    const timer = el("span", "toast-timer");               // the line along the bottom runs down its time
    timer.style.animationDuration = `${ms}ms`;
    t.append(timer);
    const leave = () => leaveToast(t);
    close.onclick = leave;
    doIt.onclick = async () => {
      doIt.disabled = true;
      clearTimeout(t._timer); t._left = null;
      try { await action(); } finally { leave(); }
    };
    enterToast(t, ms);
    return t;
  }

  function toast(msg, isError = false, ms = 4200) {
    const box = $("#toasts");
    const t = el("div", "toast" + (isError ? " error" : ""));
    t.setAttribute("role", isError ? "alert" : "status");
    const close = el("button", "toast-x", "×");
    close.type = "button";
    close.setAttribute("aria-label", "Close message");
    t.append(el("span", null, msg), close);
    close.onclick = () => leaveToast(t);
    if (!isError) {
      const timer = el("span", "toast-timer");
      timer.style.animationDuration = `${ms}ms`;
      t.append(timer);
    }
    enterToast(t, isError ? null : ms);             // an error stays until you close it
  }

  // ── toasts that stack ─────────────────────────────────────────────────
  // A run of approvals used to pile full-size boxes up the corner. Now the newest sits in front and the
  // older ones tuck in behind it, each 5% smaller, only their top edges showing. Hover and they fan out
  // to be read, and every timer holds until you move away - nothing vanishes mid-sentence.
  let toastsOpen = false;
  function liveToasts() { return [...$("#toasts").children].filter(t => !t.classList.contains("gone")); }
  function stackToasts() {
    const box = $("#toasts");
    const list = liveToasts().reverse();                  // newest first
    const front = list[0];
    let y = 0;
    list.forEach((t, i) => {
      t.style.zIndex = String(50 - i);
      if (toastsOpen) {
        t.style.transform = `translateY(${-y}px)`;
        t.style.opacity = "1";
        t.style.height = `${t._h}px`;
        t.classList.remove("behind");
        y += t._h + 8;
      } else {
        t.style.transform = `translateY(${-i * 12}px) scale(${1 - i * 0.05})`;
        t.style.opacity = i < 3 ? "1" : "0";
        t.style.height = `${front._h}px`;
        t.classList.toggle("behind", i > 0);
      }
    });
    box.style.height = !front ? "0px" : toastsOpen ? `${y - 8}px` : `${front._h + Math.min(list.length - 1, 2) * 12}px`;
  }
  function enterToast(t, ms) {
    const box = $("#toasts");
    t.style.transform = "translateY(110%)";
    t.style.opacity = "0";
    box.append(t);
    t._h = t.offsetHeight;                               // measured before any height is set on it
    t._left = ms || null;
    if (ms && !toastsOpen) { t._t0 = performance.now(); t._timer = setTimeout(() => leaveToast(t), ms); }
    stackToasts();
    const live = liveToasts();
    if (live.length > 4) leaveToast(live[0]);
  }
  function leaveToast(t) {
    if (!t || t.classList.contains("gone")) return;
    const front = liveToasts().pop() === t;
    clearTimeout(t._timer);
    t._left = null;
    t.classList.add("gone");
    if (front) t.style.transform = "translateY(110%)";
    t.style.opacity = "0";
    setTimeout(() => t.remove(), REDUCED ? 0 : 520);
    stackToasts();
  }
  $("#toasts").addEventListener("pointerenter", () => {
    toastsOpen = true;
    $("#toasts").classList.add("held");
    liveToasts().forEach(t => { if (t._timer) { clearTimeout(t._timer); t._timer = 0; t._left -= performance.now() - t._t0; } });
    stackToasts();
  });
  $("#toasts").addEventListener("pointerleave", () => {
    toastsOpen = false;
    $("#toasts").classList.remove("held");
    liveToasts().forEach(t => { if (t._left != null) { t._t0 = performance.now(); t._timer = setTimeout(() => leaveToast(t), Math.max(1500, t._left)); } });
    stackToasts();
  });

  // ── titles that clean themselves ─────────────────────────────────────
  // The app always stripped "(Official Video) [HD]" and the like from YouTube titles, but out of sight,
  // so you couldn't tell what it took. Now the raw title shows for a moment, shimmering, then each piece
  // of junk is struck through and folds away. If the clean title can't be found inside the raw one, it
  // simply shows the clean one - never an animation that tells you something untrue.
  function cleanTitle(node, raw, clean) {
    // Which characters of the raw title the clean one keeps, in order, starting where its first word
    // starts. Character by character, so "(feat. Yoko Gold and Trippie Redd)" becoming "(feat. Yoko
    // Gold)" still shows " and Trippie Redd" folding away rather than giving up on the whole title.
    const start = raw.indexOf(clean.split(/\s+/)[0]);
    const keep = new Array(raw.length).fill(false);
    let k = 0;
    if (start >= 0) for (let i = start; i < raw.length && k < clean.length; i++) if (raw[i] === clean[k]) { keep[i] = true; k++; }
    const runs = [];
    for (let i = 0; i < raw.length; i++) {
      if (runs.length && runs[runs.length - 1][1] === keep[i]) runs[runs.length - 1][0] += raw[i];
      else runs.push([raw[i], keep[i]]);
    }
    // No clean match, or one so scattered it would read as noise: just show the clean title.
    if (start < 0 || k < clean.length || runs.length > 12) { node.textContent = clean; return; }
    const tok = (text, cut) => { const s = el("span", "tok" + (cut ? " cut" : "")); s.textContent = text; return s; };
    const parts = [];
    runs.forEach(([text, kept]) => {
      if (kept) parts.push(tok(text, false));
      else (text.match(/\s*[(\[][^)\]]*[)\]]|\s*\S+|\s+/g) || [text]).forEach(bit => parts.push(tok(bit, true)));
    });
    node.replaceChildren(...parts);
    node.classList.add("tidying");
    const cuts = parts.filter(p => p.classList.contains("cut"));
    const gap = Math.min(210, Math.round(1400 / Math.max(1, cuts.length)));   // a long title folds no slower overall
    setTimeout(() => {
      node.classList.remove("tidying");
      cuts.forEach((s, i) => setTimeout(() => {
        s.classList.add("strike");
        setTimeout(() => {
          const w = s.getBoundingClientRect().width;
          s.animate([{ width: `${w}px`, opacity: 1 }, { width: "0px", opacity: 0 }], { duration: 420, easing: EASE, fill: "forwards" });
        }, 280);
      }, i * gap));
      setTimeout(() => { if (node.isConnected) node.textContent = clean; }, cuts.length * gap + 900);
    }, 1350);
  }
  const fmtLen = sec => { if (!sec) return "—"; sec = Math.round(sec); return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`; };
  const SOURCE_NAME = { spotify: "Spotify", applemusic: "Apple Music", youtube: "YouTube", soundcloud: "SoundCloud" };
  // Anything the backend refuses because the app is locked sends us back to the password screen.
  const guard = res => { if (res && res.locked) { showLocked(); throw new Error("locked"); } return res; };
  const call = async (name, ...args) => guard(await api[name](...args));

  // ── Camelot ────────────────────────────────────────────────────────────
  // Wheel colours: the usual Camelot hues, number 1 at the top going round. Minor (A) on the inner ring.
  const camelot = code => { const m = /^(1[0-2]|[1-9])([AB])$/.exec(String(code || "").toUpperCase()); return m ? { n: +m[1], l: m[2] } : null; };
  const camHue = n => (((n - 1) * 30) + 150) % 360;
  const camColor = (code, a = 1) => { const c = camelot(code); return c ? `hsla(${camHue(c.n)}, 78%, ${c.l === "B" ? 64 : 56}%, ${a})` : "var(--muted-2)"; };
  function relation(a, b) {
    const pa = camelot(a), pb = camelot(b);
    if (!pa || !pb) return null;
    const stepN = ((pb.n - pa.n) % 12 + 12) % 12;
    if (pa.l === pb.l && stepN === 0) return 0;
    if ((pa.l !== pb.l && stepN === 0) || (pa.l === pb.l && (stepN === 1 || stepN === 11))) return 1;
    if (pa.l === pb.l && (stepN === 2 || stepN === 7)) return 2;
    return null;
  }

  function drawWheel(svg, base, matches) {
    const NS = "http://www.w3.org/2000/svg";
    svg.replaceChildren();
    const counts = {};
    (matches || []).forEach(m => { const c = (m.track.camelot || "").toUpperCase(); counts[c] = (counts[c] || 0) + 1; });
    const arc = (r0, r1, a0, a1) => {
      const p = (r, a) => [r * Math.sin(a), -r * Math.cos(a)];
      const [x0, y0] = p(r1, a0), [x1, y1] = p(r1, a1), [x2, y2] = p(r0, a1), [x3, y3] = p(r0, a0);
      return `M${x0} ${y0}A${r1} ${r1} 0 0 1 ${x1} ${y1}L${x2} ${y2}A${r0} ${r0} 0 0 0 ${x3} ${y3}Z`;
    };
    for (let n = 1; n <= 12; n++) {
      [["B", 66, 96], ["A", 36, 64]].forEach(([l, r0, r1]) => {
        const code = `${n}${l}`;
        const a0 = ((n - 1) / 12) * Math.PI * 2 - Math.PI / 12 + 0.012, a1 = (n / 12) * Math.PI * 2 - Math.PI / 12 - 0.012;
        const rel = base ? relation(base, code) : null;
        const seg = document.createElementNS(NS, "path");
        seg.setAttribute("d", arc(r0, r1, a0, a1));
        seg.setAttribute("class", "seg" + (base && code === String(base).toUpperCase() ? " base" : rel === 1 ? " near" : rel === 2 ? " far" : ""));
        seg.style.setProperty("--c", camColor(code));
        const title = document.createElementNS(NS, "title");
        title.textContent = counts[code] ? `${code} · ${counts[code]} track${counts[code] > 1 ? "s" : ""}` : code;
        seg.append(title);
        // The compatibility maths was already here and the wheel was a picture of it. Clicking a
        // segment now filters the crate to what mixes with that key - the fastest way to find the
        // next track, instead of reading the diagram and then typing the answer into the search box.
        seg.setAttribute("tabindex", "0");
        seg.setAttribute("role", "button");
        seg.setAttribute("aria-label", `Show tracks that mix with ${code}`);
        const pick = () => wheelFilter(code);
        seg.addEventListener("click", pick);
        seg.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
        if (wheelKey === code) seg.classList.add("picked");
        svg.append(seg);
        const mid = (a0 + a1) / 2, rt = (r0 + r1) / 2;
        const t = document.createElementNS(NS, "text");
        t.setAttribute("x", rt * Math.sin(mid));
        t.setAttribute("y", -rt * Math.cos(mid) + 3);
        t.setAttribute("class", "seg-label" + (counts[code] ? " has" : ""));
        t.textContent = code;
        svg.append(t);
      });
    }
    const hub = document.createElementNS(NS, "text");
    hub.setAttribute("x", 0); hub.setAttribute("y", 6);
    hub.setAttribute("class", "hub");
    hub.textContent = base || "—";
    svg.append(hub);
    if (svg.id === "wheel" && !wheelDrawn) { wheelDrawn = true; drawIn(svg); }
  }
  // The first time the wheel appears in a session, each key traces its outline around the circle and
  // then fills, the keys that mix with your track last. Once a session: after that it just appears.
  let wheelDrawn = false;
  function drawIn(svg) {
    if (REDUCED) return;
    const DRAW = "cubic-bezier(0.645, 0.045, 0.355, 1)";
    [...svg.querySelectorAll(".seg")].forEach((s, i) => {
      const len = s.getTotalLength();
      const lit = s.classList.contains("base") || s.classList.contains("near");
      s.style.strokeDasharray = String(len);
      s.animate([
        { strokeDashoffset: len, fillOpacity: 0, stroke: "rgba(241, 236, 236, 0.8)", strokeWidth: 0.8 },
        { strokeDashoffset: 0, fillOpacity: 0, stroke: "rgba(241, 236, 236, 0.8)", strokeWidth: 0.8, offset: 0.6 },
        { strokeDashoffset: 0, fillOpacity: 1 },
      ], { duration: 1300, delay: i * 38 + (lit ? 340 : 0), easing: DRAW, fill: "backwards" }).onfinish = () => { s.style.strokeDasharray = ""; };
    });
    [...svg.querySelectorAll(".seg-label, .hub")].forEach((t, i) =>
      t.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 400, delay: 900 + i * 22, fill: "backwards" }));
  }
  // Which key the wheel is filtering by, if any.
  let wheelKey = null;
  function wheelFilter(code) {
    flipNext = true;
    wheelKey = wheelKey === code ? null : code;
    goToSection("crate");
    renderCrate();
    if (wheelKey) toast(`Crate filtered to what mixes with ${wheelKey}. Click it again to clear.`);
  }

  drawWheel($("#wheel-idle"), null, []);

  // Every filter off at once: search, tempo, key, folder, smart crate and the wheel.
  function clearCrateFilters() {
    $("#crate-search").value = ""; $("#bpm-min").value = ""; $("#bpm-max").value = "";
    keySelect.value = ""; folderPick = ""; crateFilterIds = null; wheelKey = null;
    document.querySelectorAll("#smart-list .smart-row.on").forEach(r => r.classList.remove("on"));
    document.querySelectorAll(".wheel .seg.picked").forEach(s => s.classList.remove("picked"));
    flipNext = true;
    renderCrate();
  }

  // ── gate: set up once, then sign in every time ─────────────────────────
  let boot = null;
  // The shop edition downloads nothing from links (see app.py). Its words are in [data-shop] in the
  // page and behind shop() here; html.store, set from get_boot, shows the right set.
  const shop = () => !!boot && boot.fetch === false;
  const gate = $("#gate");
  function openGate() {
    if (!boot) return;
    if (boot.unlocked) { unlock(boot.dj); return; }
    showLocked();
  }
  // The way out: locking runs the splash backwards. Two halves slide shut over the app, meet at a line
  // that glows once, and the lock card rises from that seam as its shackle clicks shut. Only when you
  // lock a running app - at start-up the splash has already said all this.
  let doors = null;
  function closeDoors() {
    if (REDUCED || doors) return false;
    const top = el("div", "door top"), bot = el("div", "door bot"), seam = el("div", "door-seam");
    top.append(el("div", "door-mark", "YOSHI C'S"));
    bot.append(el("div", "door-mark", "DJ MASTER · LOCKED"));
    document.body.append(top, bot, seam);
    doors = { top, bot, seam };
    document.documentElement.classList.add("doors");
    const shut = { duration: 820, easing: "cubic-bezier(0.7, 0, 0.2, 1)", fill: "forwards" };
    top.animate([{ transform: "translateY(-100%)" }, { transform: "none" }], shut);
    bot.animate([{ transform: "translateY(100%)" }, { transform: "none" }], shut);
    setTimeout(() => seam.animate([{ transform: "scaleX(0)", opacity: 1 }, { transform: "scaleX(1)", opacity: 1, offset: 0.55 }, { transform: "scaleX(1)", opacity: 0 }],
      { duration: 900, easing: "ease-out" }), 780);
    return true;
  }
  function openDoors() {
    if (!doors) return;
    const { top, bot, seam } = doors;
    doors = null;
    const open = { duration: 900, delay: 260, easing: "cubic-bezier(0.7, 0, 0.2, 1)", fill: "forwards" };
    top.animate([{ transform: "none" }, { transform: "translateY(-100%)" }], open);
    bot.animate([{ transform: "none" }, { transform: "translateY(100%)" }], open);
    seam.animate([{ transform: "scaleX(1)", opacity: 1 }, { transform: "scaleX(1)", opacity: 0 }], { duration: 500 });
    setTimeout(() => { top.remove(); bot.remove(); seam.remove(); document.documentElement.classList.remove("doors"); }, 1250);
  }
  // Locking a running app (G1, 7 Oct): the giant padlock rises, slams and shrinks into the card's lock as the card
  // comes up. At start-up the splash has already said it, so the card just appears; a second lock arriving while the
  // padlock is out (the button, then the backend saying so) waits for it.
  let padlocking = false;
  function showLocked() {
    const root = document.documentElement;
    if (padlocking) return;
    if (loaded && !doors && !root.classList.contains("locked") && window.YCM?.padlock && !REDUCED) {
      padlocking = true;
      root.classList.add("u-giant-lock");
      YCM.padlock.lock({
        back: [$(".shell"), $(".console")],         // .console: the top bar, or the status bar with pro.css
        gate,
        icon: () => $(".gate-lock svg"),
        show: () => { padlocking = false; showLockedNow(true); setTimeout(() => root.classList.remove("u-giant-lock"), 900); },
      });
      return;
    }
    showLockedNow(false);
  }
  function showLockedNow(padlock) {
    // Locking can arrive twice (the button, then the backend saying so); the second leaves the doors be.
    if (padlock) gate.classList.remove("after-doors");
    else if (!doors) {
      const shackle = $(".gate-lock path");
      const closing = loaded && closeDoors();
      gate.classList.toggle("after-doors", closing);       // the card waits for the doors to meet
      if (shackle) {
        shackle.classList.toggle("open", closing);
        if (closing) setTimeout(() => shackle.classList.remove("open"), 1450);
      }
    }
    document.documentElement.classList.remove("entering");
    document.documentElement.classList.add("locked");
    gate.classList.remove("leaving");
    // Activation comes first: without a key there is nothing to sign in to.
    const licence = (boot && boot.licence) || { ok: true };
    const activating = !licence.ok;
    const setup = !activating && (!boot || !boot.has_account);
    $("#activate-form").hidden = !activating;
    $("#setup-form").hidden = !setup;
    $("#signin-form").hidden = activating || setup;
    const removed = activating && !!licence.removed;      // Yoshi took this computer off, or blocked this copy
    const farewell = activating && !!licence.farewell;    // a private copy past its last day (licence.PRIVATE_ENDS)
    const ended = activating && licence.ended && licence.sub && !removed;
    const site = !!(boot && boot.site);
    $(".gate-tag").textContent = farewell ? "Private copy ended" : removed ? "Access removed" : ended ? "Subscription ended" : activating ? "Not activated" : "Password protected";
    $(".gate-title").textContent = farewell ? "The site is live." : removed ? "This copy is switched off." : ended ? "Time to renew." : activating ? "This copy needs a key." : "This is a password protected app.";
    // Past its last day, a key won't open it - only the way to the website stays.
    $("#activate-key").closest("label").style.display = farewell ? "none" : "";
    $("#activate-form button[type=submit]").style.display = farewell ? "none" : "";
    $("#activate-note").style.display = farewell ? "none" : "";
    if (activating) {
      $("#activate-lede").textContent = removed ? licence.error : ended
        ? (site ? "Renew on the website and DJ Master opens again by itself - or press Check again once it's paid." : "Once it's paid again, DJ Master opens by itself while it's online.")
        : site ? "This copy of DJ Master needs a key. Subscribe on the website, then get this computer's key there - it takes a minute. Already have one? Paste it below."
        : "This copy of DJ Master needs a key before it will open. Send Yoshi the installation ID below and he'll send one back.";
      $("#gate-site").hidden = (removed && !farewell) || (!site && !ended);
      $("#gate-site-go").hidden = !site;
      $("#gate-site-go").textContent = farewell ? "Go to yoshicmusic.com" : ended ? "Renew on the website" : "Get my key";
      $("#gate-site-go").dataset.page = farewell ? "/pricing/" : "/account/";
      $("#gate-site-alt").hidden = farewell;
      $("#gate-site-alt").textContent = ended ? "Check again" : "See the plans";
      $("#gate-site-alt").dataset.mode = ended ? "check" : "plans";
      if (ended) $("#activate-key").value = "";     // the key that just ran out isn't the answer
      $("#install-id").textContent = licence.id || "";
      gateError("#activate-error", removed || (licence.error && licence.error.includes("hasn't been activated")) ? "" : licence.error);
      $("#activate-note").textContent = !licence.id
        ? "This computer didn't answer when the app asked which computer it is, so there's no ID to send yet. Restart it and open the app again."
        : licence.solid === false
        ? "This computer's own ID couldn't be read, so the app used the network card instead. The app now holds on to that first answer, so the ID won't change under you."
        : "The key is tied to this computer. Nothing is sent anywhere to check it - the app works out the answer on its own, offline.";
    }
    spellName($("#signin-name"), state.dj || (boot && boot.dj) || "", 0.35);
    gate.hidden = false;
    requestAnimationFrame(() => gate.classList.add("show"));
    setTimeout(() => { if (document.documentElement.classList.contains("locked")) gate.classList.add("show"); }, 200);   // even if no frame comes
    const first = activating ? "#activate-key" : setup ? "#setup-name" : "#signin-pass";
    setTimeout(() => $(first).focus(), REDUCED ? 0 : 500);
  }

  // ── activation ─────────────────────────────────────────────────────────
  // The same facts in Settings, once you're in: who the key is for, and which computer it's tied to.
  function renderActivation() {
    const l = (boot && boot.licence) || {};
    const who = l.name ? `Activated for <b>${escapeHtml(l.name)}</b>` : "This copy is activated";
    const when = l.issued ? ` on ${escapeHtml(l.issued)}` : "";
    const until = l.until ? ` · runs until <b>${escapeHtml(l.until)}</b>` : "";
    $("#lic-who").innerHTML = who + when + (l.sub || l.trial ? "" : until) + ".";
    $("#lic-id").textContent = l.id || "";
    // On a subscription or trial: where it stands. The date always comes from the key itself.
    const day = iso => fmtDay(iso);
    const timedKey = String(l.until || "").includes("T");
    const lapsed = l.status === "lapsed" || l.status === "cancelled";
    const plan = l.trial && !l.sub
      ? (l.left != null ? `Free trial: ${l.left <= 0 ? "last day today" : `${l.left} day${l.left === 1 ? "" : "s"} left`} (ends ${day(l.until)}).` : "Free trial.")
      : l.sub ? (lapsed ? `The last payment didn't go through. DJ Master keeps working until ${day(l.until)}, then stops until it's paid.`
                        : `Subscription: ${l.left != null && !timedKey ? `${l.left} day${l.left === 1 ? "" : "s"} left in this month, ` : ""}` +
                          (l.renews ? `renews by itself before ${day(l.until)}.` : `until ${day(l.until)}.`))
      : l.until && l.left != null ? `This key runs until ${day(l.until)} - ${l.left} day${l.left === 1 ? "" : "s"} left.`
      : "";
    const gigsPlan = l.sub ? "Gigs is included with your DJ Master subscription."
      : l.ok && !l.trial ? "Desktop activation. Gigs requires a DJ Master subscription." : "";
    $("#lic-plan").textContent = [plan, gigsPlan].filter(Boolean).join(" ");
    $("#lic-plan").hidden = !plan && !gigsPlan;
    $("#lic-plan").classList.toggle("warn", lapsed || (l.trial && !l.sub && l.left != null && l.left <= 2));
    $("#lic-name").textContent = l.computer ? `This computer: ${l.computer}` : "";
    $("#lic-key-form").hidden = !!l.sub;
    if (l.local_trial) $("#lic-who").innerHTML = "On the free trial - no key yet.";
    renderPlanChip(l);
    $("#lic-release").hidden = !l.renews;
    $("#lic-manage").hidden = !(boot && boot.site) || !l.sub;
    if (boot && boot.site) $("#lic-fine").textContent = "One key, one computer, and two computers on a subscription. Moving to a new machine? Manage computers opens your account with this one ready to move. A subscription renews itself online before its date.";
    $("#lic-computer").hidden = !l.computer && !l.renews;
    if (l.expiring && !l.sub) toast(l.trial ? `Your free trial ends in ${l.expiring} day${l.expiring === 1 ? "" : "s"}.`
                                            : `Your licence runs out in ${l.expiring} day${l.expiring === 1 ? "" : "s"}. Ask Yoshi for a new key.`, true, 9000);
  }
  // ── the free trial ─────────────────────────────────────────────────────
  // A copy with no key opens on a TRIAL_DAYS free trial (licence.begin_trial). The first launch gets a
  // welcome once the DJ is in; after that the chip in the top bar keeps count, and the card comes back for
  // the last two days. When it ends, the key screen takes over (onLicence) - never mid-download.
  let trialDays = 5;
  const fmtDay = iso => {
    if (String(iso || "").includes("T")) return new Date(iso).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit", second: "2-digit" });
    const [y, m, d] = String(iso || "").split("-").map(Number); return y ? new Date(y, m - 1, d).toLocaleDateString(undefined, { day: "numeric", month: "long" }) : ""; };
  function showTrial(l, first) {
    const left = Math.max(0, l.left != null ? l.left : trialDays);
    $("#trial-tag").textContent = first ? "Welcome" : "Free trial";
    $("#trial-title").textContent = first ? `${trialDays} days free, starting now.` :
      left <= 1 ? "Last day of your free trial." : `${left} days left of your free trial.`;
    $("#trial-text").textContent = first
      ? `All of DJ Master is yours for ${trialDays} days - the crate, the cues, requests from the floor, rekordbox and Serato. No key needed until then.`
      : "When it ends, DJ Master asks for a key to keep going. Your crate, tracks and settings stay exactly as they are.";
    $("#trial-days").replaceChildren(...Array.from({ length: trialDays }, (_, i) => el("i", i < trialDays - left ? "used" : "")));
    $("#trial-when").textContent = l.until ? `The trial runs until ${fmtDay(l.until)}.` : "";
    $("#trial-go").textContent = first ? "Let's go" : "Keep going";
    const box = $("#trial");
    box.hidden = false;
    requestAnimationFrame(() => box.classList.add("in"));
    setTimeout(() => $("#trial-go").focus(), 200);
  }
  function hideTrial() {
    const box = $("#trial");
    box.classList.remove("in");
    setTimeout(() => (box.hidden = true), 300);
  }
  // The chip: how long this copy has left - a free trial, a subscription's paid month, or a key with an
  // end date. A key that never ends shows nothing.
  function renderPlanChip(l) {
    const chip = $("#trial-chip");
    const timed = !!(l && l.ok && l.until && l.left != null);
    chip.hidden = !timed;
    if (!timed) return;
    const days = String(l.until || "").includes("T") ? `until ${fmtDay(l.until)}` : l.left <= 0 ? "last day" : l.left === 1 ? "1 day left" : `${l.left} days left`;
    const lapsed = l.status === "lapsed" || l.status === "cancelled";
    chip.textContent = l.local_trial || (l.trial && !l.sub) ? `Trial · ${days}` : lapsed ? `Payment due · ${days}` : days;
    chip.classList.toggle("warn", lapsed || l.left <= 2);
    chip.title = l.sub ? (lapsed ? `The last payment didn't go through - DJ Master stops on ${fmtDay(l.until)} unless it's paid.`
                                 : `This month of your subscription runs until ${fmtDay(l.until)}, and renews by itself.`)
               : `Runs until ${fmtDay(l.until)}.`;
    chip.onclick = () => {
      if (l.local_trial) return showTrial(l, false);
      openSettings("activation");
    };
  }
  $("#trial-go").onclick = hideTrial;
  $("#trial-key").onclick = () => {
    hideTrial();
    openSettings("activation", "#lic-key");
  };
  addEventListener("keydown", e => { if (e.key === "Escape" && !$("#trial").hidden) hideTrial(); });
  $("#lic-key-form").addEventListener("submit", async e => {
    e.preventDefault();
    const r = await api.activate($("#lic-key").value);
    if (!r.ok) return toast(r.error, true, 8000);
    $("#lic-key").value = "";
    const wasTrial = !!(boot && boot.licence && boot.licence.local_trial);   // the Gigs page can bring a keyed copy here too
    if (boot) boot.licence = r;
    renderActivation();
    toast((r.name ? `Activated for ${r.name}.` : "Activated.") + (wasTrial ? " No more trial." : "") +
      (r.sub ? " Gigs is included with your subscription." : " Gigs requires a DJ Master subscription."));
    loadGigs();                                   // a subscription key opens the Gigs page too
  });

  $("#gate-site-go").onclick = () => call("open_site", $("#gate-site-go").dataset.page || "/account/");
  $("#gate-site-alt").onclick = async () => {
    const b = $("#gate-site-alt");
    if (b.dataset.mode !== "check") return call("open_site", "/pricing/");
    b.disabled = true; b.textContent = "Checking…";
    const l = await call("check_licence_now");
    b.disabled = false; b.textContent = "Check again";
    if (l && !l.ok) gateError("#activate-error", l.status === "cancelled" || l.status === "lapsed"
      ? "Not paid yet - renew on the website, then check again." : l.error);
  };
  $("#lic-manage").onclick = () => call("open_site", "/account/");
  $("#lic-release").onclick = async () => {
    const b = $("#lic-release");
    if (b.dataset.armed !== "1") {                 // two clicks: DJ Master locks straight after
      b.dataset.armed = "1";
      b.textContent = "Click again to free it - DJ Master locks here";
      setTimeout(() => { b.dataset.armed = ""; b.textContent = "Free up this computer"; }, 5000);
      return;
    }
    b.disabled = true;
    const r = await call("release_computer");
    b.disabled = false;
    b.dataset.armed = "";
    b.textContent = "Free up this computer";
    if (!r || !r.ok) return toast((r && r.error) || "Couldn't free this computer.", true);
    toast("This computer's place is free. Activate DJ Master on the other one.", false, 7000);
  };
  const escapeHtml = t => String(t).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  $("#lic-copy").onclick = async () => {
    try { await navigator.clipboard.writeText($("#lic-id").textContent); toast("Installation ID copied."); }
    catch (err) { toast("Couldn't copy it - read it off the screen instead.", true); }
  };

  $("#diag-copy").onclick = async () => {
    const r = await call("diagnostics");
    if (!r.ok) return toast(r.error, true);
    const header = `Yoshi C's DJ Master ${r.version} · ${state.platform === "mac" ? "Mac" : "Windows"}\n\n`;
    try { await navigator.clipboard.writeText(header + r.text); toast("Copied. Paste it wherever you're describing the problem."); }
    catch (err) { toast("Couldn't copy it.", true); }
  };

  // Settings > Help & legal > Make a report: a zip on the Desktop for Yoshi; nothing is sent (app.py make_report).
  $("#report-make").addEventListener("click", async () => {
    const b = $("#report-make");
    if (b.disabled) return;
    b.disabled = true;
    b.textContent = "Making it…";
    try {
      const r = await call("make_report");
      if (!r || !r.ok) { toast((r && r.error) || "The report couldn't be made.", true); return; }
      $("#report-name").textContent = r.name;
      $("#report-where").textContent = `${r.where} · ${Math.max(1, Math.round(r.size / 1024))} KB`;
      const made = $("#report-made");
      made.hidden = false;
      if (!REDUCED) made.animate([{ opacity: 0, transform: "translateY(6px)" }, { opacity: 1, transform: "none" }], { duration: 250, easing: "cubic-bezier(0.22, 1, 0.36, 1)" });
      b.textContent = "Make another";
    } catch (err) {
      toast("The report couldn't be made.", true);
    } finally {
      b.disabled = false;
      if (b.textContent === "Making it…") b.textContent = "Make a report";
    }
  });
  $("#report-show").addEventListener("click", () => call("show_report"));

  $("#install-copy").onclick = async () => {
    try {
      await navigator.clipboard.writeText($("#install-id").textContent);
      toast(boot && boot.site ? "Installation ID copied." : "Installation ID copied. Send it to Yoshi.");
    } catch (err) { toast("Couldn't copy it - read it off the screen instead.", true); }
  };
  $("#activate-form").addEventListener("submit", async e => {
    e.preventDefault();
    if (!api) return;
    const btn = $("#activate-form .gate-go");
    btn.disabled = true;
    try {
      const r = await api.activate($("#activate-key").value);
      if (!r.ok) return gateError("#activate-error", r.error);
      gateError("#activate-error", "");
      boot.licence = r;
      $("#activate-key").value = "";
      showLocked();                                   // straight on to the sign-in, or to setting up
      toast((r.name ? `Activated for ${r.name}.` : "Activated.") +
        (r.sub ? " Gigs is included with your subscription." : " Gigs requires a DJ Master subscription."));
    } finally { btn.disabled = false; }
  });
  // A wrong password clears the field, and now you can see it go: the dots you typed drop out one by
  // one and the field's edge flashes amber, so there's no wondering whether it kept what you typed. The
  // field is a real password box, so these dots are drawn over it, measured from its own font.
  function dropDots(input, n) {
    if (REDUCED || !n || !input) return;
    const s = getComputedStyle(input);
    const probe = el("span", null, "\u2022".repeat(10));
    Object.assign(probe.style, { position: "absolute", visibility: "hidden", font: s.font, letterSpacing: s.letterSpacing, whiteSpace: "pre" });
    document.body.append(probe);
    const pitch = probe.getBoundingClientRect().width / 10;
    probe.remove();
    const r = input.getBoundingClientRect();
    const row = el("div", "drop-dots");
    Object.assign(row.style, { left: `${r.left + parseFloat(s.paddingLeft) + parseFloat(s.borderLeftWidth)}px`, top: `${r.top}px`,
      height: `${r.height}px`, font: s.font, color: s.color });
    const count = Math.min(n, 40);
    for (let i = 0; i < count; i++) {
      const d = el("span", null, "\u2022");
      d.style.width = `${pitch}px`;
      row.append(d);
      d.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: "translateY(8px) scale(0.6)" }], { duration: 340, delay: i * 55, easing: "ease-in", fill: "forwards" });
    }
    document.body.append(row);
    input.classList.add("bad");
    setTimeout(() => input.classList.remove("bad"), 1200);
    setTimeout(() => row.remove(), count * 55 + 420);
  }
  function gateError(id, msg) {
    const e = $(id);
    e.textContent = msg || "";
    e.hidden = !msg;
    if (msg && !REDUCED) {
      const card = $(".gate-card");
      card.classList.remove("shake");
      void card.offsetWidth;
      card.classList.add("shake");
    }
  }
  const setupSteps = window.YCFX?.steps($("#setup-form"), [
    [$("#setup-name")?.closest("label")],
    [$("#setup-pass")?.closest("label"), $("#setup-confirm")?.closest("label")],
    [$("#setup-form .setup-theme")],
  ], {
    error: "#setup-error",
    check: (i) => i === 1 && $("#setup-pass").value.length < 4 ? "Use at least 4 characters for the password."
      : i === 1 && $("#setup-pass").value !== $("#setup-confirm").value ? "The two passwords don't match." : "",
  });
  $("#setup-form").addEventListener("submit", async e => {
    e.preventDefault();
    if (!api) return;
    const btn = e.submitter || $("#setup-form .gate-go");
    btn.disabled = true;
    try {
      const r = await api.create_account($("#setup-name").value, $("#setup-pass").value, $("#setup-confirm").value);
      if (!r.ok) {
        setupSteps?.go(/DJ name/i.test(r.error) ? 0 : /password/i.test(r.error) ? 1 : 2);
        return gateError("#setup-error", r.error);
      }
      gateError("#setup-error", "");
      boot.has_account = true;
      $("#setup-pass").value = $("#setup-confirm").value = "";
      if (pendingTheme) {
        const [hex, id] = pendingTheme;
        pendingTheme = null;
        // Saved before unlocking, so the state the app loads already carries the colour.
        await saveAccent(hex, id).catch(() => {});
      }
      unlock(r.dj, `Welcome to Yoshi C's DJ Master, DJ ${r.dj}.`);
    } finally { btn.disabled = false; }
  });
  let waitTimer = 0;
  $("#signin-form").addEventListener("submit", async e => {
    e.preventDefault();
    if (!api) return;
    const btn = $("#signin-form .gate-go");
    btn.disabled = true;
    const typed = $("#signin-pass").value.length;
    const r = await api.sign_in($("#signin-pass").value);
    $("#signin-pass").value = "";
    if (r.ok) {
      btn.disabled = false;
      gateError("#signin-error", "");
      unlock(r.dj);
      return;
    }
    dropDots($("#signin-pass"), typed);
    window.YCM?.padlock?.wrong({ gate, icon: $(".gate-lock svg"), card: $(".gate-card") });
    gateError("#signin-error", r.error);
    if (r.wait) {
      clearTimeout(waitTimer);
      waitTimer = setTimeout(() => { btn.disabled = false; gateError("#signin-error", ""); }, r.wait * 1000);
    } else {
      btn.disabled = false;
      $("#signin-pass").focus();
    }
  });

  // Depth transition: the password card rushes past the camera and fades while the app rises out of the
  // background (scaled back, blurred) into place, and the smoke settles from a slight zoom.
  let loaded = false, enterTimer = 0;
  async function unlock(dj, message) {
    // The giant padlock comes out of the card's lock, springs open and drops away as the app comes forward (G1).
    // Without it (reduced motion, or the doors are shut from an older lock): the shackle lifts as the card goes, and
    // if the doors are shut they open behind it.
    const giant = !!window.YCM?.padlock && !REDUCED && !doors && !gate.hidden;
    const shackle = $(".gate-lock path");
    if (giant) {
      document.documentElement.classList.add("u-giant-way");
      YCM.padlock.unlock({ gate, icon: $(".gate-lock svg") });
      setTimeout(() => document.documentElement.classList.remove("u-giant-way"), 1500);
    } else if (shackle && !REDUCED) shackle.classList.add("open");
    openDoors();
    gate.classList.remove("after-doors");
    state.dj = dj;
    $("#dj-name").textContent = dj;
    setWelcome(dj);
    const root = document.documentElement;
    if (!REDUCED) {
      clearTimeout(enterTimer);
      root.classList.remove("entering");
      void root.offsetWidth;
      root.classList.add("entering");
      enterTimer = setTimeout(() => root.classList.remove("entering"), 1450);
    }
    gate.classList.add("leaving");
    gate.classList.remove("show");
    setTimeout(() => { if (!root.classList.contains("locked")) { gate.hidden = true; gate.classList.remove("leaving"); } }, REDUCED ? 0 : 1150);
    root.classList.remove("locked");
    if (!loaded) {
      loaded = true;
      await loadState();
      startReveals();
      const l = (boot && boot.licence) || {};
      if (l.ok && l.local_trial && (boot.trial_new || (l.left != null && l.left <= 2)))
        setTimeout(() => showTrial(l, !!boot.trial_new), REDUCED ? 0 : 1200);
      setTimeout(() => input.focus({ preventScroll: true }), REDUCED ? 0 : 700);
    } else {
      refreshAll();
    }
    if (message) toast(message);
    renderActivation();
    // After the way in, not during it: the depth animation gets to finish first.
    setTimeout(() => showWhatsNew().catch(() => {}), REDUCED ? 0 : 1900);
    setTimeout(() => showFarewell().catch(() => {}), REDUCED ? 0 : 2600);
  }
  // A private copy with a last day (licence.PRIVATE_ENDS) says so each time it opens, with the way to the website.
  async function showFarewell() {
    const f = await call("farewell");
    if (!f || f.over) return;
    const left = f.days <= 1 ? "Today is the last day." : `${f.days} days left.`;
    toastWithAction(`Private copies end ${f.on} - ${left} The site is live: subscribe at yoshicmusic.com and Yoshi C will give you the private copy again, plus free months.`,
      "Go to the site", () => call("open_site", "/pricing/"), 20000);
  }
  async function lockNow() {
    if (!api) return;
    await api.lock();
    ["#new-name", "#name-pass", "#pass-current", "#pass-new", "#pass-confirm"].forEach(id => ($(id).value = ""));
    showLocked();
  }
  $("#lock-btn").addEventListener("click", lockNow);
  // Locked means the card is on screen, whatever led here: on 7 Oct a reopened DJ Master sat locked with no card -
  // only the wallpaper and the top bar - until something else happened. Checked every second; costs nothing.
  setInterval(() => {
    const root = document.documentElement;
    if (!introDone || !boot || doors || !root.classList.contains("locked") || root.classList.contains("booting")) return;
    if (gate.hidden || !gate.classList.contains("show") || gate.classList.contains("leaving")) showLocked();
  }, 1000);
  $("#lock-now").addEventListener("click", lockNow);

  // ── homepage ───────────────────────────────────────────────────────────
  // Good morning / afternoon / evening, DJ name. Before five it's still the night before.
  function greeting() {
    const h = new Date().getHours();
    return h >= 5 && h < 12 ? "Good morning" : h >= 12 && h < 18 ? "Good afternoon" : "Good evening";
  }
  function setWelcome(dj) {
    spellName($("#home-name"), dj ? `${greeting()}, DJ ${dj}` : "", 0.25);
  }

  const PHONE_WINDOW = 8 * 3600;        // "tonight" = the last eight hours, so a set over midnight still counts
  const WAVE_BARS = 46;
  // Steady per-track bar heights: the same job always draws the same shape.
  function waveHeights(seed) {
    let h = 0;
    for (const ch of String(seed || "x")) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    return Array.from({ length: WAVE_BARS }, (_, i) => {
      h = (h * 1664525 + 1013904223) >>> 0;
      const base = 0.45 + 0.55 * Math.abs(Math.sin(i * 0.5));
      return Math.round((18 + ((h >>> 16) % 60) * 0.55 * base) );
    });
  }
  function renderWave(seed, filled) {
    const box = $("#now-wave");
    if (box._seed !== seed) {
      box._seed = seed;
      box.replaceChildren(...waveHeights(seed).map(h => {
        const i = el("i");
        i.style.height = `${h}%`;
        return i;
      }));
    }
    [...box.children].forEach((bar, i) => bar.classList.toggle("on", i / WAVE_BARS < filled));
  }
  function jobState(j) {
    return j.status === "running" ? `${Math.round((j.progress || 0) * 100)}%`
      : j.status === "held" ? "needs you"           // a booth request: nothing has been downloaded
      : j.status === "wanted" ? "to buy"            // the shop edition: not in the crate yet
      : j.status === "waiting" ? "waiting" : j.status === "done" ? "ready"
      : j.status === "cancelled" ? "cancelled" : "failed";
  }
  function renderHome() {
    renderHomeWait();
    if (!loaded) return;
    const jobs = [...state.jobs.values()];
    const running = jobs.find(j => j.status === "running");
    const waiting = jobs.filter(j => j.status === "waiting");
    const done = jobs.filter(j => j.status === "done");
    const wanted = jobs.filter(j => j.status === "wanted");

    // Crate, and what landed over the last fortnight.
    const tracks = [...state.crate.values()];
    $("#tile-crate").innerHTML = `${tracks.length} <small>track${tracks.length === 1 ? "" : "s"}</small>`;
    // Room left on the drive, under the count. Red when there is not enough for a night's work:
    // a download that dies half way through, an hour before a gig, is the thing this prevents.
    const space = state.space;
    const spaceFoot = $("#tile-space");
    if (spaceFoot) {
      if (!space) spaceFoot.textContent = "";
      else {
        const gb = space.free / 1073741824;
        // "room for ~5736" left out what it was counting. Round numbers: it's an estimate (a WAV is about 40 MB).
        const n = space.tracks, about = n >= 1000 ? Math.round(n / 100) * 100 : n >= 100 ? Math.round(n / 10) * 10 : n;
        spaceFoot.textContent = `${gb < 10 ? gb.toFixed(1) : Math.round(gb)} GB free · room for ${n >= 100 ? "about " : ""}${about.toLocaleString("en")} more track${about === 1 ? "" : "s"}`;
        spaceFoot.classList.toggle("low", space.tracks < 40);
      }
    }
    const day = 86400, now = Date.now() / 1000;
    const days = Array.from({ length: 14 }, (_, i) => tracks.filter(t => {
      const age = now - (t.added || 0);
      return age >= (13 - i) * day && age < (14 - i) * day;
    }).length);
    const peak = Math.max(1, ...days);
    $("#tile-spark").replaceChildren(...days.map(n => {
      const i = el("i");
      i.style.height = `${Math.round((n / peak) * 100)}%`;
      i.style.opacity = n ? "1" : "0.25";
      return i;
    }));

    // Requests from the phone tonight.
    const phone = jobs.filter(j => j.origin === "phone" && now - (j.added || 0) < PHONE_WINDOW);
    $("#tile-tonight").innerHTML = `${phone.length} <small>request${phone.length === 1 ? "" : "s"}</small>`;
    const latest = phone.slice().sort((a, b) => (b.added || 0) - (a.added || 0))[0];
    $("#tile-tonight-sub").textContent = latest ? `latest: ${latest.title}` : shop() ? "from your phone and the booth link" : `${state.requests.size} in Song Requests`;
    const req = $("#home-requests");
    req.hidden = !phone.length;
    if (phone.length) req.replaceChildren(el("span", "dotlive"), el("span", null, `${phone.length} request${phone.length === 1 ? "" : "s"} tonight`));

    // What's downloading.
    const pct = running ? Math.round((running.progress || 0) * 100) : 0;
    $("#tile-dl").textContent = shop() ? (wanted.length ? `${wanted.length} to buy` : "None")
      : running ? `${pct}%` : waiting.length ? `${waiting.length} waiting` : "Idle";
    // translate, not width: see .hbar i. 0% shows nothing, 100% sits flush.
    $("#tile-dl-bar").style.transform = `translateX(${running ? pct - 100 : -100}%)`;
    const qp = $("#queue-pill");
    qp.replaceChildren();
    if (running) {
      const eq = el("span", "eq");
      eq.append(el("i"), el("i"), el("i"), el("i"));
      qp.append(eq, el("span", null, "working"));
    } else qp.append(el("span", null, waiting.length ? `${waiting.length} waiting` : wanted.length ? `${wanted.length} to buy` : "Idle"));

    // Your DJ software: rekordbox and Serato, whichever are switched on - named underneath, so the tile never reads
    // as rekordbox-only.
    const rbOn = !!(rbInfo && rbInfo.enabled), soft = [rbOn && "rekordbox", state.settings.serato_enabled && "Serato"].filter(Boolean);
    const rb = $("#tile-rb");
    rb.replaceChildren();
    if (!rbInfo && !soft.length) rb.append(el("span", null, "—"));
    else if (!soft.length) rb.append(el("span", null, "Off"));
    else if (rbOn && rbInfo.error) rb.append(el("span", null, "Error"));
    else rb.append(el("span", "dotlive"), el("span", null, "In sync"));
    $("#tile-rb-sub").textContent = !soft.length ? (rbInfo ? "switched off in DJ software" : "")
      : rbOn && rbInfo.error ? rbInfo.error.slice(0, 40)
      // the tile's label already names the picked software; the line under it only names what it doesn't
      : [soft.join(" and ") === ({ rekordbox: "rekordbox", serato: "Serato", both: "rekordbox and Serato" })[djSoftware()] ? "" : soft.join(" and "),
         rbOn && rbInfo.written ? `updated ${ago(rbInfo.written)}` : ""].filter(Boolean).join(", ");

    // The queue, newest work first.
    const order = { running: 0, waiting: 1, held: 1, wanted: 2, error: 2, done: 3, cancelled: 4 };
    const rows = jobs.slice().sort((a, b) => (order[a.status] - order[b.status]) || (b.added || 0) - (a.added || 0)).slice(0, 5);
    $("#home-queue-empty").hidden = rows.length > 0;
    $("#home-queue").replaceChildren(...rows.map(j => {
      const tr = el("tr", "row" + (j.status === "running" ? " live" : ""));
      const who = el("td", "t");
      who.append(el("b", null, j.title));
      const from = [j.subtitle, j.origin === "phone" ? "phone" : ""].filter(Boolean).join(" · ");
      if (from) who.append(el("small", null, from));
      const a = j.analysis && !j.analysis.pending ? j.analysis : {};
      const cam = el("td", "num", a.camelot || "—");
      cam.style.color = a.camelot ? camColor(a.camelot) : "";
      tr.append(who, el("td", "num", a.bpm ? String(Math.round(a.bpm)) : "—"), el("td", "num", a.key ? a.key.replace(" minor", "m").replace(" major", "") : "—"),
                cam, el("td", "num", jobState(j)));
      tr.onclick = () => window.YCS.to("queue");
      return tr;
    }));

    // Now downloading, or the last thing that landed.
    const show = running || done.slice().sort((a, b) => (b.finished || 0) - (a.finished || 0))[0]
      || (shop() ? wanted.slice().sort((a, b) => (b.added || 0) - (a.added || 0))[0] : null);
    $("#now-label").textContent = running ? "Now downloading" : shop() ? "Last request" : "Last added";
    const np = $("#now-pill");
    np.hidden = !show;
    if (show) np.textContent = running ? `${pct}%` : show.status === "wanted" ? "to buy" : show.analysis && show.analysis.bpm ? `${Math.round(show.analysis.bpm)} BPM` : "ready";
    renderWave(show ? show.id : "idle", running ? (running.progress || 0) : show ? 1 : 0);
    const row = $("#now-row"), foot = $("#now-foot");
    row.replaceChildren();
    foot.replaceChildren();
    if (!show) {
      row.append(el("div", "qempty", shop() ? "No requests yet. A song sent from a phone shows up here - in your crate, or with where to buy it."
                                           : "Nothing downloaded yet. Paste a link and it lands here with its tempo, key and Camelot."));
      return;
    }
    const thumb = show.thumbnail ? el("img", "nowthumb") : el("span", "nowthumb");
    if (show.thumbnail) thumb.src = show.thumbnail;
    const t = el("div", "t");
    t.append(el("b", null, show.title));
    t.append(el("small", null, [show.subtitle, show.origin === "phone" ? "from your phone" : ""].filter(Boolean).join(" · ")));
    row.append(thumb, t);
    const a = show.analysis && !show.analysis.pending ? show.analysis : null;
    if (a && a.camelot) {
      const cam = el("span", "cam", a.camelot);
      cam.style.setProperty("--cam", camColor(a.camelot));
      row.append(cam);
    }
    foot.append(el("span", null, running ? show.stage || "Working" : a ? [a.bpm ? `${Math.round(a.bpm)} BPM` : "", a.key || ""].filter(Boolean).join(" · ") : "Ready"));
    if (!running && show.track_id) {
      const find = el("button", "btn-text", "Show in crate →");
      find.type = "button";
      find.onclick = () => selectTrack(show.track_id, true);
      foot.append(find);
    }
  }
  function tickClock() {
    const d = new Date();
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    $("#home-when").textContent = `${days[d.getDay()]} · ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  }
  setInterval(tickClock, 20000);
  tickClock();

  // ── link → preview ─────────────────────────────────────────────────────
  const input = $("#link-input");
  const kindCap = $("#link-kind");
  let pasteHint = "⌘ V";
  function linkKind(url) {
    const u = url.trim().toLowerCase();
    if (u.includes("spotify.com") || u.startsWith("spotify:") || u.includes("spotify.link")) return ["Spotify", "spotify"];
    if (u.includes("music.apple.com") || u.includes("itunes.apple.com")) return ["Apple Music", "applemusic"];
    if (u.includes("youtube.com") || u.includes("youtu.be")) return ["YouTube", "youtube"];
    if (u.includes("soundcloud.com")) return ["SoundCloud", "soundcloud"];
    return ["Link", ""];
  }
  const isLink = v => /^(https?:\/\/|spotify:)\S+$/i.test(String(v).trim());
  function showKind() {
    const [label, cls] = linkKind(input.value);
    const typed = input.value.trim();
    const known = typed && cls;
    kindCap.textContent = known ? label : typed ? (isLink(typed) ? "Link" : "Search") : pasteHint;
    kindCap.className = "kind " + (known ? cls : "");
  }
  input.addEventListener("input", showKind);
  input.addEventListener("paste", () => setTimeout(() => {
    if (/^(https?:\/\/|spotify:)\S+$/i.test(input.value.trim())) $("#link-form").requestSubmit();
  }, 0));
  const goBtn = $("#link-go");
  // "songs" = the record catalogue, "youtube" = the uploads. Whichever you used last is where the
  // next search starts, instead of Songs every time.
  let searchSource = (() => { try { return localStorage.getItem("searchSource") === "youtube" ? "youtube" : "songs"; } catch (e) { return "songs"; } })();
  // "1.2M views": on YouTube, how many people found an upload is the quickest way to tell the
  // official one from a re-upload.
  const fmtViews = n => {
    n = Number(n);
    if (!n) return "";
    const s = n >= 1e9 ? (n / 1e9).toFixed(1) + "B" : n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? Math.round(n / 1e3) + "K" : String(n);
    return s.replace(".0", "") + " views";
  };
  $("#link-form").addEventListener("submit", async e => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text || state.resolving || !api) return;
    state.resolving = true;
    goBtn.disabled = true;
    goBtn.innerHTML = '<span class="spinner"></span>';
    try {
      const res = isLink(text) ? await call("lookup", text) : await call("search", text, searchSource);
      if (!res.ok) { toast(res.error, true, 7000); return; }
      state.preview = res.info;
      state.pick = 0;
      state.selected = null;
      renderPreview();
    } catch (err) {
      if (err.message !== "locked") toast(String(err), true);
    } finally {
      state.resolving = false;
      goBtn.disabled = false;
      goBtn.textContent = "↵";
    }
  });

  const previewBox = $("#preview");
  const previewBody = $("#preview-body");
  let previewClear = 0;
  function closePreview() {
    state.preview = null;
    state.selected = null;
    clearTimeout(previewClear);
    previewBox.classList.remove("show");
    previewClear = setTimeout(() => previewBody.replaceChildren(), 600);
  }
  function previewHead(info, label, facts) {
    const main = el("div", "pv-main");
    const cover = el("img", "cover");
    cover.src = info.thumbnail || (info.candidates && info.candidates[state.pick] ? info.candidates[state.pick].thumbnail : "") || "";
    cover.alt = "";
    cover.onerror = () => (cover.style.visibility = "hidden");
    const meta = el("div", "pv-meta");
    meta.style.minWidth = "0";
    meta.append(el("span", "label", label), el("h3", "pv-title", info.title));
    if (info.artist) meta.append(el("span", "pv-artist", info.artist));
    const f = el("div", "pv-facts");
    facts.forEach(([k, v, cls], i) => { if (i) f.append(el("br")); f.append(k + " "); f.append(el("b", cls || null, v)); });
    main.append(cover, meta, f);
    return main;
  }
  function actions(label, onGet, disabled) {
    const row = el("div", "pv-actions");
    const dismiss = el("button", "btn-text", "Dismiss");
    dismiss.type = "button";
    dismiss.onclick = closePreview;
    const go = el("button", "btn-pill get", label);
    go.type = "button";
    go.disabled = !!disabled;
    go.onclick = onGet;
    row.append(dismiss, el("span", "grow"), el("span", "est", "WAV · 24-bit · 44.1 kHz"), go);
    return row;
  }
  function renderPreview() {
    const info = state.preview;
    if (!info) return closePreview();
    clearTimeout(previewClear);
    const scroll = previewBody.querySelector(".tracklist-rows");
    const keep = scroll ? scroll.scrollTop : 0;
    previewBody.replaceChildren();
    if (info.collection) renderCollection(info);
    else if (info.kind === "search" && info.store) renderShop(info);
    else if (info.kind === "search") renderSearch(info);
    else renderLink(info);
    const rows = previewBody.querySelector(".tracklist-rows");
    if (rows) rows.scrollTop = keep;
    // Already in the crate? A note, never a refusal - downloading it again is a perfectly
    // reasonable thing to want, and the app has no business deciding otherwise. Asked for after
    // the preview is drawn so it never delays it.
    flagDuplicate(info);
    if (!previewBox.classList.contains("show")) requestAnimationFrame(() => requestAnimationFrame(() => previewBox.classList.add("show")));
  }
  async function research(source) {
    const info = state.preview;
    if (!info || state.resolving) return;
    state.resolving = true;
    try {
      const res = await call("search", info.query, source);
      if (!res.ok) return toast(res.error, true, 7000);
      searchSource = source;
      try { localStorage.setItem("searchSource", source); } catch (e) {}
      state.preview = res.info;
      state.pick = 0;
      state.showAllVersions = false;
      renderPreview();
    } finally { state.resolving = false; }
  }

  function renderSearch(info) {
    const cat = info.source === "songs";
    const head = el("div", "sr-head");
    head.append(el("span", "label", `${info.candidates.length} result${info.candidates.length === 1 ? "" : "s"}`),
                el("span", "sr-note", cat ? `for “${info.query}” · the record, found on YouTube when it downloads`
                                          : `for “${info.query}” · YouTube uploads`));
    const seg = el("div", "segmented");
    [["Songs", "songs"], ["YouTube", "youtube"]].forEach(([label, source]) => {
      const b = el("button", info.source === source ? "on" : null, label);
      b.type = "button";
      b.title = source === "songs" ? "Search the record catalogue" : "Search YouTube uploads: edits, bootlegs, remixes";
      b.onclick = () => research(source);
      seg.append(b);
    });
    head.append(seg);

    // ── the record, or a version of it ────────────────────────────────────
    // YouTube answers "mr brightside" with the single, four festival recordings, a nightcore edit
    // and somebody reacting to it. Only the first of those is any use in a set, so the others are
    // folded away by default - shown, counted, one click from coming back, because now and then a
    // bootleg IS the thing you want.
    const versions = info.candidates.filter(c => c.version);
    const showAll = state.showAllVersions || !versions.length ||
                    versions.length === info.candidates.length;
    if (versions.length && versions.length < info.candidates.length) {
      const toggle = el("button", "sr-filter" + (showAll ? "" : " on"));
      toggle.type = "button";
      toggle.textContent = showAll
        ? `Hide ${versions.length} live, remix and edit${versions.length === 1 ? "" : "s"}`
        : `Showing the record · ${versions.length} other version${versions.length === 1 ? "" : "s"} hidden`;
      toggle.title = "Live sets, remixes, covers, sped-up and slowed edits, karaoke and reactions";
      toggle.onclick = () => {
        state.showAllVersions = !state.showAllVersions;
        // Keep the highlighted result highlighted, rather than whatever now sits at that index.
        const chosen = info.candidates[state.pick];
        renderPreview();
        const again = info.candidates.indexOf(chosen);
        if (again >= 0) state.pick = again;
      };
      head.append(toggle);
    }

    const shown = showAll ? info.candidates : info.candidates.filter(c => !c.version);
    if (!state.showAllVersions && shown.length && info.candidates[state.pick] &&
        info.candidates[state.pick].version) {
      state.pick = info.candidates.indexOf(shown[0]);   // never leave a hidden row selected
    }

    const list = el("div", "sr-list");
    shown.forEach((c) => {
      const i = info.candidates.indexOf(c);
      const row = el("button", "sr" + (i === state.pick ? " selected" : ""));
      row.type = "button";
      row.append(el("span", "radio"));
      if (c.thumbnail) {
        const img = el("img");
        img.src = c.thumbnail;
        img.alt = "";
        img.onerror = () => img.replaceWith(el("span", "sr-ph"));
        row.append(img);
      } else row.append(el("span", "sr-ph"));
      const t = el("div", "sr-t");
      t.append(el("b", null, c.title || "Untitled"));
      t.append(el("small", null, cat ? [c.artist, c.album, c.year].filter(Boolean).join(" · ")
                                     : [c.channel, fmtViews(c.views)].filter(Boolean).join(" · ")));
      row.append(t);
      if (cat && c.explicit) row.append(el("span", "chip", "E"));
      // Say what it is rather than just ranking it lower: "live" on a row is the difference
      // between picking a festival recording by accident and picking one on purpose.
      if (c.version) row.append(el("span", "chip version", c.version));
      row.append(el("span", "sr-len", c.length || "—"));
      row.onclick = () => { state.pick = i; renderPreview(); };
      row.ondblclick = () => getPicked(info);
      list.append(row);
    });
    previewBody.append(head, list, actions("Get the WAV", () => getPicked(info)));
  }

  // ── the shop edition: what you have, and where to buy the rest ─────────
  // Your crate's own tracks first - the quickest answer there is - then the record from the catalogue,
  // marked In your crate when it is, and otherwise with the shops that sell it. A link gets the same
  // answer: only the song's name was read from it.
  function shopButtons(c, where) {
    const row = el("div", "shop-row");
    if (c.have) {
      const go = el("button", "btn-pill get", "Show in crate");
      go.type = "button";
      go.onclick = () => { closePreview(); selectTrack(c.have.id, true); };
      row.append(el("span", "shop-have", "In your crate"), go);
      return row;
    }
    row.append(el("span", "shop-label", where || "Buy it from"));
    (c.buy || []).forEach(s => {
      const b = el("button", "btn-pill shop", s.name);
      b.type = "button";
      b.title = `Search ${s.name} for “${c.artist ? c.artist + " - " : ""}${c.title}”`;
      b.onclick = async () => {
        const r = await call("open_shop", s.url);
        if (r && r.ok) toast(r.watching ? `Opened ${s.name}. Buy it there - when the file lands in your purchases folder it's in your crate within seconds.`
                                         : `Opened ${s.name}. When you've bought it, drop the file on this window - or watch your Downloads folder in Settings → Prepare my purchases and it comes in by itself.`,
                             false, 9000);
      };
      row.append(b);
    });
    return row;
  }
  function renderShop(info) {
    const head = el("div", "sr-head");
    const n = info.candidates.length;
    head.append(el("span", "label", info.link ? `From ${info.link}` : `${n} result${n === 1 ? "" : "s"}`),
                el("span", "sr-note", info.link ? "only the song's name is read from a link - nothing is downloaded"
                                                : `for “${info.query}” · in your crate, or where to buy it`));
    const parts = [head];
    if (info.crate && info.crate.length) {
      const mine = el("div", "sr-list mine");
      mine.append(el("span", "label sr-group", "In your crate"));
      info.crate.forEach(t => {
        const row = el("button", "sr");
        row.type = "button";
        row.append(keptCover("sr:" + t.id, t, "sr-cover"));
        const tx = el("div", "sr-t");
        tx.append(el("b", null, t.title || "Untitled"), el("small", null, [t.artist, t.bpm ? `${Math.round(t.bpm)} BPM` : "", t.key || ""].filter(Boolean).join(" · ")));
        row.append(tx);
        if (t.camelot) { const cam = el("span", "chip cam", t.camelot); cam.style.setProperty("--cam", camColor(t.camelot)); row.append(cam); }
        row.onclick = () => { closePreview(); selectTrack(t.id, true); };
        mine.append(row);
      });
      parts.push(mine);
    }
    if (n) {
      const list = el("div", "sr-list");
      if (info.crate && info.crate.length) list.append(el("span", "label sr-group", "The record"));
      info.candidates.forEach((c, i) => {
        const row = el("button", "sr" + (i === state.pick ? " selected" : ""));
        row.type = "button";
        row.append(el("span", "radio"));
        if (c.thumbnail) {
          const img = el("img");
          img.src = c.thumbnail;
          img.alt = "";
          img.onerror = () => img.replaceWith(el("span", "sr-ph"));
          row.append(img);
        } else row.append(el("span", "sr-ph"));
        const tx = el("div", "sr-t");
        tx.append(el("b", null, c.title || "Untitled"), el("small", null, [c.artist, c.album, c.year].filter(Boolean).join(" · ")));
        row.append(tx);
        if (c.explicit) row.append(el("span", "chip", "E"));
        if (c.have) row.append(el("span", "chip have", "In your crate"));
        row.append(el("span", "sr-len", c.length || "—"));
        row.onclick = () => { state.pick = i; renderPreview(); };
        list.append(row);
      });
      parts.push(list);
    }
    const act = el("div", "pv-actions");
    const dismiss = el("button", "btn-text", "Dismiss");
    dismiss.type = "button";
    dismiss.onclick = () => { input.value = ""; showKind(); closePreview(); };
    act.append(dismiss, el("span", "grow"));
    const pick = info.candidates[state.pick];
    if (pick) act.append(shopButtons(pick));
    parts.push(act);
    previewBody.append(...parts);
  }

  async function getPicked(info) {
    await call("get_link", info, state.pick);
    const c = info.candidates[state.pick] || {};
    input.value = ""; showKind(); closePreview();
    toast(`Getting “${c.title || info.query}”`);
  }

  function renderLink(info) {
    const cand = info.candidates[state.pick];
    const matched = info.kind === "spotify" || info.kind === "applemusic";
    const close = info.duration && cand && cand.duration && Math.abs(cand.duration - info.duration) <= 3;
    const facts = [["Length", info.length || fmtLen(info.duration)]];
    if (matched && cand) facts.push(["Match", cand.length || fmtLen(cand.duration), close ? "close" : ""]);
    else if (info.bitrate) facts.push(["Source", `~${info.bitrate} kbps`]);
    previewBody.append(previewHead(info, matched ? `From ${SOURCE_NAME[info.kind]} · matched on YouTube` : `From ${SOURCE_NAME[info.kind] || "link"}`, facts));
    if (matched) {
      const box = el("div", "matches");
      const head = el("div", "matches-head");
      head.append(el("span", "label", "Matched recording"),
                  el("span", "note", `${SOURCE_NAME[info.kind]} audio is protected, so the same song is taken from YouTube. Check it's the right version.`));
      box.append(head);
      info.candidates.slice(0, 3).forEach((c, i) => {
        const row = el("button", "match" + (i === state.pick ? " selected" : ""));
        row.type = "button";
        row.append(el("span", "radio"));
        const img = el("img"); img.src = c.thumbnail; img.alt = ""; row.append(img);
        const text = el("div", "match-info");
        const t = el("div", "match-title", c.title);
        if (i === 0) t.append(el("span", "chip signal", "Best match"));
        text.append(t, el("div", "match-sub", c.channel));
        row.append(text);
        const near = info.duration && c.duration && Math.abs(c.duration - info.duration) <= 3;
        row.append(el("span", "match-len" + (near ? " close" : ""), c.length));
        row.onclick = () => { state.pick = i; renderPreview(); };
        box.append(row);
      });
      previewBody.append(box);
    }
    previewBody.append(actions("Get the WAV", async () => {
      await call("get_link", info, state.pick);
      input.value = ""; showKind(); closePreview();
      toast(`Getting “${info.title}”`);
    }));
  }
  function renderCollection(info) {
    if (!state.selected) state.selected = new Set(info.tracks.map((_, i) => i));
    const sel = state.selected;
    const matched = info.kind === "spotify" || info.kind === "applemusic";
    previewBody.append(previewHead(info, `${SOURCE_NAME[info.kind] || "Link"} ${String(info.collection_type || "playlist").toLowerCase()}${matched ? " · matched on YouTube" : ""}`,
      [["Songs", String(info.count || info.tracks.length)]]));
    const list = el("div", "tracklist");
    const head = el("div", "tracklist-head");
    const all = el("label", "check");
    const allBox = el("input");
    allBox.type = "checkbox";
    allBox.checked = sel.size === info.tracks.length;
    allBox.indeterminate = sel.size > 0 && sel.size < info.tracks.length;
    allBox.onchange = () => { state.selected = allBox.checked ? new Set(info.tracks.map((_, i) => i)) : new Set(); renderPreview(); };
    all.append(allBox, el("span", "check-mark"), el("span", "label", `${sel.size} of ${info.tracks.length} selected`));
    head.append(all);
    if (matched) head.append(el("span", "note", "Each song is matched on YouTube when its turn comes."));
    list.append(head);
    if (info.note) list.append(el("div", "tracklist-note", info.note));
    const rows = el("div", "tracklist-rows");
    info.tracks.forEach((t, i) => {
      const row = el("label", "track" + (sel.has(i) ? " on" : ""));
      const cb = el("input");
      cb.type = "checkbox";
      cb.checked = sel.has(i);
      cb.onchange = () => { cb.checked ? sel.add(i) : sel.delete(i); renderPreview(); };
      const text = el("span", "track-text");
      text.append(el("span", "track-title", t.title));
      if (t.artist) text.append(el("span", "track-artist", t.artist));
      row.append(cb, el("span", "check-mark"), el("span", "track-num", String(i + 1).padStart(2, "0")), text, el("span", "track-len", t.length || "—"));
      rows.append(row);
    });
    list.append(rows);
    previewBody.append(list, actions(sel.size === 1 ? "Get 1 WAV" : `Get ${sel.size} WAVs`, async () => {
      const indices = [...sel].sort((a, b) => a - b);
      const n = await call("get_collection", info, indices);
      input.value = ""; showKind(); closePreview();
      toast(`Getting ${n} track${n === 1 ? "" : "s"} from “${info.title}”`);
    }, sel.size === 0));
  }

  // ── downloads ──────────────────────────────────────────────────────────
  const STEP_LABEL = { download: "Download", key: "Tempo & key", save: "Crate" };
  function jobNode(job, animate, before) {
    let node = document.getElementById("job-" + job.id);
    if (node) return node;
    node = el("div", "job");
    node.id = "job-" + job.id;
    node.innerHTML = `
      <div class="job-row">
        <span class="job-idx"></span>
        <span class="job-thumb"></span>
        <div class="job-info"><div class="job-title"></div><div class="job-sub"></div></div>
        <div class="job-stage"><span class="stage-text"></span><span class="pct"></span></div>
        <button class="job-x" type="button" title="Remove">×</button>
        <button class="job-jump" type="button" title="Move this to the front of the queue" hidden>Do this next</button>
        <button class="job-cancel" type="button" title="Stop this download">Cancel</button>
        <button class="job-retry" type="button" title="Try this one again">Retry</button>
        <button class="job-ok" type="button" title="Say yes to this request">Approve</button>
        <button class="job-no" type="button" title="Turn this request down">Reject</button>
      </div>
      <div class="job-steps" hidden></div>
      <div class="job-analysis" hidden></div>
      <div class="job-note" hidden></div>
      <div class="job-error" hidden></div>
      <div class="job-out" hidden></div>
      <div class="job-rule"><i></i></div>
      <svg class="runlight" aria-hidden="true"><rect pathLength="100"></rect></svg>`;
    node._r = {
      title: $(".job-title", node), sub: $(".job-sub", node), stage: $(".stage-text", node), pct: $(".pct", node),
      steps: $(".job-steps", node), analysis: $(".job-analysis", node), note: $(".job-note", node), error: $(".job-error", node),
      out: $(".job-out", node), rule: $(".job-rule i", node), cancel: $(".job-cancel", node), thumb: $(".job-thumb", node),
    };
    node._sig = {};
    node._shown = job.progress || 0;
    $(".job-x", node).onclick = async () => {
      const current = state.jobs.get(job.id);
      if (current && current.status === "waiting") return removeWaiting(current);
      syncJobs(await call("remove_job", job.id));
    };
    node._r.cancel.onclick = async () => { node._r.cancel.disabled = true; syncJobs(await call("cancel", job.id)); };
    // A request lands for something you want in ten minutes and it is sixth in line. The worker
    // takes the first waiting job, so moving it to the front IS the feature.
    const jump = $(".job-jump", node);
    if (jump) {
      jump.hidden = job.status !== "waiting" || queuePosition(job.id) === 0;
      jump.onclick = async (e) => {
        e.stopPropagation();
        const r = await call("jump_queue", job.id);
        if (!r.ok) return toast(r.error, true);
        syncJobs(r.jobs);
        toast(`“${job.title}” is next.`);
      };
    }
    $(".job-retry", node).onclick = async () => syncJobs(await call("retry", job.id));
    // Held requests: the DJ decides before anything is fetched.
    $(".job-ok", node).onclick = (e) => { window.YCFX?.spark(e); approveRequest(job); };
    $(".job-no", node).onclick = () => rejectRequest(job);
    if (before && before.isConnected) before.before(node); else $("#jobs").append(node);
    window.YCM?.decorate(node);                  // the tick a finished row shows before "Done" (M2)
    node._fresh = !!animate;                     // renderJob brings it in once its words are in (M1)
    queueMeta(true);
    return node;
  }
  // One way to answer a request, whichever screen you answer it from. Booth view used to carry its
  // own copy, which forgot the row in Downloads: a request you had turned down sat there with Approve
  // and Reject still on it, and pressing Reject then failed because it was already gone.
  async function approveRequest(job) {
    // Approved on screen immediately. The disk takes a few hundred milliseconds and there is no
    // reason to spend them watching a disabled button.
    const before = { ...(state.jobs.get(job.id) || job) };
    renderJob({ ...before, status: "waiting", stage: "Waiting" });
    drawBooth();
    // Private edition: a song already in the crate is pointed at, not downloaded again (app.py _run).
    toast(shop() || job.have ? `“${job.title}” approved.` : `“${job.title}” approved - downloading now.`);
    const r = await call("request_approve", job.id);
    if (!r.ok) {
      renderJob(before);                         // put it back exactly as it was
      drawBooth();
      return toast(r.error, true);
    }
    refreshBooth().catch(() => {});
  }
  // Reject takes the request off the screen at once and offers Undo for six seconds (Ctrl Z too); only when they're
  // up is it turned down for real, so a slip in a dark booth costs nothing. One at a time: rejecting another sends
  // the first one through. Closing the app inside the six seconds leaves the request waiting, as if never rejected.
  // Removing a waiting download works the same way since 7 Oct (as do Stem Splitter's waiting songs). The row slides
  // away (M3), anything that arrives for it meanwhile is kept aside, and Undo puts it back where it was.
  const UNDO_MS = 6000;
  let pendingUndo = null;
  function holdForUndo(job, message, send) {
    pendingUndo?.commit();
    const before = { ...(state.jobs.get(job.id) || job) };
    let latest = null;
    state.jobs.delete(job.id);
    const row = document.getElementById("job-" + job.id);
    const rows = [...$("#jobs").children];
    const next = row ? rows.slice(rows.indexOf(row) + 1).find(n => n.id && !n.dataset.leaving) : null;
    if (row) removeJobNode(row);
    drawBooth();
    queueMeta(true);
    renderHomeSoon();
    let settled = false, note = null;
    const putBack = () => {
      const j = latest || before;
      state.jobs.set(j.id, j);
      renderJob(j, { before: next && next.isConnected ? next : null });
      drawBooth(); queueMeta(true); renderHomeSoon();
    };
    const undo = () => {
      if (settled) return;
      settled = true; clearTimeout(timer); pendingUndo = null;
      if (note) leaveToast(note);
      putBack();
    };
    const commit = async () => {
      if (settled) return;
      settled = true; clearTimeout(timer); pendingUndo = null;
      const r = await send();
      if (r && r.ok === false) { putBack(); return toast(r.error, true); }       // it never left, so it's back everywhere
      queueMeta(true);
      renderHomeSoon();
      refreshBooth().catch(() => {});
    };
    const timer = setTimeout(commit, UNDO_MS);
    pendingUndo = { id: job.id, commit, undo, hold: j => { latest = j; } };
    note = toastWithAction(message, "Undo", async () => undo(), UNDO_MS, isMac() ? "⌘Z" : "Ctrl Z");
  }
  function rejectRequest(job) {
    holdForUndo(job, `Turned down “${job.title || "the request"}”.`, () => call("request_reject", job.id));
  }
  function removeWaiting(job) {
    holdForUndo(job, `Removed “${job.title || "the download"}” from the queue.`, async () => { syncJobs(await call("cancel", job.id)); return { ok: true }; });
  }
  document.addEventListener("keydown", (e) => {
    if (!pendingUndo || !(e.ctrlKey || e.metaKey) || e.key.toLowerCase() !== "z") return;
    // In a box with text in it, Ctrl Z undoes the typing as usual; an empty one (the search box is usually focused) doesn't.
    const field = e.target.closest && e.target.closest("input, textarea, [contenteditable]");
    if (field && (field.value ?? field.textContent ?? "").length) return;
    e.preventDefault();
    pendingUndo.undo();
  });
  // The empty screens' buttons (U4) press or focus something that already exists elsewhere in the window.
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest("[data-click], [data-focus]");
    if (!b) return;
    const to = document.querySelector(b.dataset.click || b.dataset.focus);
    if (!to) return;
    if (b.dataset.click) to.click();
    else {
      if ($("#main").contains(to)) window.YCS.into(to, "center");
      else to.scrollIntoView({ block: "center", behavior: REDUCED ? "auto" : "smooth" });
      to.focus({ preventScroll: true });
    }
  });

  function removeJobNode(node) {
    if (window.YCM) return YCM.leave(node, () => { node.remove(); queueMeta(true); });
    if (REDUCED) { node.remove(); queueMeta(true); return; }
    node.style.overflow = "hidden";
    const a = node.animate([{ height: `${node.offsetHeight}px`, opacity: 1 }, { height: "0px", opacity: 0 }], { duration: 380, easing: EASE, fill: "forwards" });
    node.dataset.leaving = "1";
    a.onfinish = () => { node.remove(); queueMeta(true); };
  }
  function renderSteps(node, job) {
    const box = node._r.steps;
    const show = job.status === "running" && job.steps;
    box.hidden = !show;
    if (!show) return;
    if (!box.childElementCount) {
      box.replaceChildren(...job.steps.map(k => {
        const st = el("div", "st");
        st.dataset.step = k;
        st.innerHTML = `<div class="bar"><i></i></div><span>${STEP_LABEL[k] || k}</span>`;
        return st;
      }));
    }
    const ranges = { download: [0, 0.8], key: [0.8, 0.96], save: [0.96, 1] };
    const current = job.steps.indexOf(job.step);
    [...box.children].forEach((st, i) => {
      st.classList.toggle("done", i < current);
      st.classList.toggle("now", i === current);
      const [lo, hi] = ranges[st.dataset.step] || [0, 1];
      const fill = i < current ? 1 : i > current ? 0 : Math.max(0, Math.min(1, (job.progress - lo) / (hi - lo)));
      st.firstElementChild.firstElementChild.style.transform = `scaleX(${fill})`;
    });
  }
  function renderAnalysis(box, a) {
    box.replaceChildren();
    if (!a) { box.hidden = true; return; }
    const cell = (label, value, sub, cls = "") => {
      const c = el("div", "an-cell " + cls);
      c.append(el("span", "label", label), el("span", "an-value", value));
      if (sub) c.append(el("span", "an-sub", sub));
      return c;
    };
    if (a.pending) {
      box.append(cell("Tempo", "…", "Listening", "pending"), cell("Key", "…", "Listening", "pending"), cell("Camelot", "…", "Listening", "pending"));
    } else {
      box.append(cell("Tempo", a.bpm ? `${a.bpm}` : "—", a.bpm_alt ? `or ${a.bpm_alt} half/double time` : "Whole-song average", "tempo"));
      box.append(cell("Key", a.key || "—", a.relative ? `Relative ${a.relative}` : "", "key"));
      const cam = cell("Camelot", a.camelot || "—", a.confidence != null ? `${a.confidence}% confidence` : "", "camelot");
      cam.style.setProperty("--cam", camColor(a.camelot));
      box.append(cam);
    }
    box.hidden = false;
  }
  function renderOut(node, job) {
    const out = node._r.out;
    if (job.status === "wanted") {                 // the shop edition: not in the crate yet - here's where to get it
      const sig = "wanted:" + JSON.stringify(job.buy || []);
      if (node._sig.out === sig) return;
      node._sig.out = sig;
      out.replaceChildren(shopButtons({ title: job.title, artist: job.artist, buy: job.buy || [] }, "Not in your crate yet ·"));
      out.hidden = false;
      return;
    }
    const sig = job.status === "done" ? JSON.stringify([job.wav, job.track_id]) : "";
    if (node._sig.out === sig) return;
    node._sig.out = sig;
    out.replaceChildren();
    out.hidden = job.status !== "done" || !job.wav;
    if (out.hidden) return;
    if (job.track_id) {
      const find = el("button", "btn-text", "Show in crate →");
      find.type = "button";
      find.onclick = () => selectTrack(job.track_id, true);
      out.append(find);
    }
    const open = el("button", "btn-text", "Open folder →");
    open.type = "button";
    open.onclick = () => call("open_path", job.wav, true);
    out.append(open);
  }
  function renderJob(job, opts = {}) {
    // A row waiting out its six seconds of Undo stays off the screen; what arrives for it is kept for putting it back.
    if (pendingUndo && pendingUndo.id === job.id) { pendingUndo.hold(job); return; }
    const prev = state.jobs.get(job.id);
    state.jobs.set(job.id, job);
    $("#jobs-empty").hidden = true;
    const node = jobNode(job, opts.animate !== false, opts.before);
    const r = node._r, sig = node._sig;
    const shownBefore = node._shown;
    const justDone = prev && (prev.status === "running" || prev.status === "wanted") && job.status === "done";
    const cls = "job " + job.status + (justDone || node.classList.contains("just-done") ? " just-done" : "");
    if (node.className !== cls) node.className = cls;
    if (justDone) {
      setTimeout(() => node.classList.remove("just-done"), 1800);
      if (job.booth || job.origin === "phone") noteOut(job);   // it was asked for and it arrived
    }
    if (sig.thumb !== (job.thumbnail || "")) {
      sig.thumb = job.thumbnail || "";
      if (job.thumbnail) { const img = el("img", "job-thumb"); img.src = job.thumbnail; img.alt = ""; r.thumb.replaceWith(img); r.thumb = img; }
    }
    if (sig.title !== job.title) {
      const first = sig.title === undefined;
      sig.title = job.title;
      // A job that has only just arrived shows its clean-up; one restored at start-up doesn't.
      const fresh = first && job.raw && job.raw !== job.title && Date.now() / 1000 - (job.added || 0) < 5;
      if (fresh && !REDUCED && opts.animate !== false) cleanTitle(r.title, job.raw, job.title);
      else r.title.textContent = job.title;
    }
    const kind = { spotify: "Spotify → YouTube", applemusic: "Apple Music → YouTube", youtube: "YouTube", soundcloud: "SoundCloud",
                   catalogue: "Search → YouTube", search: "Search · YouTube", track: "Download again" }[job.kind] || "Link";
    const group = job.group ? `${job.group_type ? job.group_type.toUpperCase() + ": " : ""}${job.group} · ` : "";
    const from = (job.booth && job.votes > 1 ? `▲ ${job.votes} PEOPLE WANT THIS · ` : "") + (job.booth ? "🎧 FROM THE BOOTH LINK · " : job.origin === "phone" ? "📱 FROM PHONE · " : "");
    // The most-wanted waiting request rises above the ones fewer people asked for.
    if (job.status === "held" && job.votes > 1 && node.parentElement) {
      const lower = [...node.parentElement.children].find(n => n !== node && n.classList.contains("held") && ((state.jobs.get(n.id.slice(4)) || {}).votes || 1) < job.votes);
      if (lower && (node.compareDocumentPosition(lower) & Node.DOCUMENT_POSITION_PRECEDING)) node.parentElement.insertBefore(node, lower);
    }
    // What they asked for, when it is not simply the name of what it matched - so a confident
    // wrong match is visible before it is approved rather than after it is played.
    const asked = job.asked && job.asked.toLowerCase() !== (job.name || "").toLowerCase() ? job.asked : "";
    const fmt = shop() ? "" : job.origin === "phone" ? " · MP3" : " · WAV";
    const wanted = asked ? ` · asked for “${asked}”` : "";
    const sub = shop() ? `${from}${job.subtitle || job.artist || ""}${wanted}`
                       : `${from}${group}${kind}${fmt}${job.subtitle ? " · " + job.subtitle : ""}${wanted}`;
    if (sig.sub !== sub) { sig.sub = sub; r.sub.textContent = sub; }
    if (job.status !== "running") r.cancel.disabled = false;
    // A request for something you already have says so, with the way to it - before anything is fetched.
    const have = job.have && job.status !== "done" ? job.have : null;
    const noteText = job.status === "error" ? "" : job.note || (have ? `Already in your crate: ${have.title}${have.artist ? " by " + have.artist : ""}.` : "");
    if (sig.note !== noteText + job.note_level) {
      sig.note = noteText + job.note_level;
      r.note.hidden = !noteText;
      r.note.textContent = noteText;
      r.note.classList.toggle("warn", job.note_level === "warn");
      r.note.classList.toggle("have", !!have && !job.note);
      if (have && !job.note && have.id) {
        const go = el("button", "btn-text", "Show in crate →");
        go.type = "button";
        go.onclick = () => selectTrack(have.id, true);
        r.note.append(" ", go);
      }
    }
    if (sig.error !== (job.error || "")) { sig.error = job.error || ""; r.error.hidden = !job.error; r.error.textContent = job.error || ""; }
    const running = job.status === "running";
    const stageText = running && job.step ? STEP_LABEL[job.step] || job.stage : job.stage || "";
    if (r.stage.textContent !== stageText) r.stage.textContent = stageText;
    r.stage.title = job.stage || "";
    if (!running) r.pct.textContent = "";
    node._target = job.status === "waiting" ? 0 : job.status === "done" ? 1 : job.progress || 0;
    if (!running) { node._shown = node._target; r.rule.style.transform = `scaleX(${node._shown})`; } else startTween();
    renderSteps(node, job);
    const aSig = JSON.stringify(job.analysis);
    if (sig.analysis !== aSig) {
      const landed = job.analysis && !job.analysis.pending && sig.analysis !== undefined;
      sig.analysis = aSig;
      renderAnalysis(r.analysis, job.analysis);
      if (landed) r.analysis.querySelectorAll(".an-value").forEach(v => v.classList.add("landed"));
    }
    renderOut(node, job);
    if (node._fresh) { node._fresh = false; window.YCM?.arrive(node); }        // M1
    else if (justDone) window.YCM?.finish(node, shownBefore);                 // M2
    queueMeta(false);
    renderHomeSoon();
  }
  let tweenRaf = 0;
  function startTween() { if (!tweenRaf) tweenRaf = requestAnimationFrame(tween); }
  function tween() {
    tweenRaf = 0;
    let moving = false;
    document.querySelectorAll(".job.running").forEach(node => {
      const gap = (node._target || 0) - node._shown;
      node._shown = REDUCED || Math.abs(gap) < 0.001 ? node._target : node._shown + gap * 0.12;
      if (node._shown !== node._target) moving = true;
      node._r.pct.textContent = `${Math.round(node._shown * 100)}%`;
      node._r.rule.style.transform = `scaleX(${node._shown})`;
    });
    if (moving) startTween();
  }
  let metaRaf = 0, listChanged = false;
  function queueMeta(changed) {
    listChanged = listChanged || changed;
    if (!metaRaf) metaRaf = requestAnimationFrame(runQueueMeta);
  }
  function runQueueMeta() {
    metaRaf = 0;
    if (listChanged) {
      listChanged = false;
      let n = 0;
      document.querySelectorAll("#jobs .job").forEach(node => {
        if (node.dataset.leaving) return;
        n++;
        $(".job-idx", node).textContent = String(n).padStart(2, "0");
      });
      $("#jobs-skel")?.remove();
      $("#jobs-empty").hidden = n > 0;
      measureSections();
    }
    const jobs = [...state.jobs.values()];
    const running = jobs.some(j => j.status === "running");
    const waiting = jobs.filter(j => j.status === "waiting").length;
    const heldNow = jobs.filter(j => j.status === "held").length;
    const wanted = jobs.filter(j => j.status === "wanted").length;
    const qText = running ? `Working${waiting ? ` · +${waiting}` : ""}` : waiting ? `${waiting} waiting`
      : heldNow ? `${heldNow} need${heldNow === 1 ? "s" : ""} you` : wanted ? `${wanted} to buy` : "Idle";
    if (window.YCM) YCM.roll($("#queue-count"), qText); else $("#queue-count").textContent = qText;
    if (window.bgActivity) window.bgActivity(running ? 1 : 0);
  }
  function syncJobs(jobs, opts = {}) {
    if (!Array.isArray(jobs)) return;
    const keep = new Set(jobs.map(j => j.id));
    for (const id of [...state.jobs.keys()]) {
      if (!keep.has(id)) {
        state.jobs.delete(id);
        const n = document.getElementById("job-" + id);
        if (n) removeJobNode(n);
      }
    }
    jobs.forEach(j => renderJob(j, opts));
    queueMeta(true);
  }
  $("#clear-finished").onclick = async () => syncJobs(await call("clear_finished"));
  $("#cancel-waiting").onclick = async () => {
    const waiting = [...state.jobs.values()].filter(j => j.status === "waiting").length;
    if (!waiting) return toast("Nothing is waiting.");
    syncJobs(await call("cancel_waiting"));
    toast(`Cancelled ${waiting} waiting download${waiting === 1 ? "" : "s"}`);
  };

  // ── native drag out (into rekordbox, Serato, VirtualDJ, a folder) ──────
  // What a drag carries: the picked set when this row is part of it, otherwise just this row.
  function pickedPaths(track) {
    if (!picked.has(track.id) || picked.size < 2) return null;
    return [...picked].map(id => (state.crate.get(id) || state.requests.get(id) || {}).path).filter(Boolean);
  }

  // ── dropped in from outside ─────────────────────────────────────────────
  // Any file dragged over the window can land anywhere on it. app.py reads the dropped files' paths
  // (pywebview's drop handler on document); this only shows where they're going and keeps the page
  // from opening the file itself. Capture phase on window, because that handler stops the event; and
  // a watchdog on dragover, because dragenter/dragleave counting is unreliable.
  let ownDrag = false, ownDragTimer = 0, dragWatch = 0;
  const veil = $("#drop-veil");
  const hasFiles = e => !!(e.dataTransfer && [...(e.dataTransfer.types || [])].includes("Files"));
  const veilOff = () => { clearTimeout(dragWatch); veil.classList.remove("over"); };
  const veilOn = () => { veil.classList.add("over"); clearTimeout(dragWatch); dragWatch = setTimeout(veilOff, 350); };
  window.addEventListener("dragenter", e => { e.preventDefault(); if (!ownDrag && hasFiles(e) && api && loaded) veilOn(); }, true);
  window.addEventListener("dragover", e => { e.preventDefault(); if (!ownDrag && hasFiles(e) && api && loaded) veilOn(); }, true);
  window.addEventListener("dragleave", e => { if (!e.relatedTarget) veilOff(); }, true);
  window.addEventListener("drop", e => { e.preventDefault(); veilOff(); }, true);
  $("#pick-files").onclick = async () => {
    const r = await call("pick_files");
    if (r && typeof r.added === "number") window.app.onDropped(r);
  };

  function makeDraggable(node, path, onClick, manyFn) {
    let down = null, dragging = false;
    const start = () => {
      dragging = true;
      down = null;
      ownDrag = true;                            // our own track on its way out: not something to take in
      clearTimeout(ownDragTimer);
      ownDragTimer = setTimeout(() => { ownDrag = false; }, 30000);
      node.classList.add("dragging");
      const many = manyFn && manyFn();
      api.drag_out(many && many.length > 1 ? many : [path]).then(res => guard(res)).catch(() => {});
      noteOut(state.crate.get(node.dataset.id) || state.requests.get(node.dataset.id));
      setTimeout(() => node.classList.remove("dragging"), 700);
    };
    node.addEventListener("pointerdown", e => { if (e.button === 0 && !e.target.closest("button:not(.chip-drag)")) { down = { x: e.clientX, y: e.clientY }; dragging = false; } });
    node.addEventListener("pointermove", e => { if (down && !dragging && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 6) start(); });
    node.addEventListener("pointerleave", e => { if (down && !dragging && e.buttons === 1) start(); });
    node.addEventListener("pointerup", e => { if (down && !dragging && onClick) onClick(e); down = null; });
    node.addEventListener("dragstart", e => e.preventDefault());
  }
  // Windows recycles, a Mac trashes - the app says whichever one the person is actually looking at.
  const trashName = () => (state.platform === "mac" ? "Trash" : "Recycle Bin");

  // ── crate ──────────────────────────────────────────────────────────────
  // The side menu shows its icons and names all the time now (u.css), so the A1 lean-out is retired.
  window.YCFX?.glint("img.cart, img.sr-cover, img.job-thumb, img.mcart");
  const keySelect = $("#key-filter");
  keySelect.append(new Option("Any key", ""), new Option("Mixes with selected", "compat"));
  for (let n = 1; n <= 12; n++) ["A", "B"].forEach(l => keySelect.append(new Option(`${n}${l}`, `${n}${l}`)));
  window.YCFX?.wheel(keySelect);
  // Bridge deliveries can contain many tracks. Store all of them immediately, paint once per frame.
  let crateFrame = 0;
  function renderCrateNextFrame() {
    if (!crateFrame) crateFrame = requestAnimationFrame(() => { crateFrame = 0; renderCrate(); });
  }
  let crateTimer = 0;
  const renderCrateSoon = () => { clearTimeout(crateTimer); crateTimer = setTimeout(renderCrate, 60); };
  ["#crate-search", "#bpm-min", "#bpm-max"].forEach(id => $(id).addEventListener("input", renderCrateSoon));
  ["#key-filter", "#crate-sort"].forEach(id => $(id).addEventListener("change", renderCrate));

  // ── covers and shapes ─────────────────────────────────────────────────
  // A track's cover, kept on this computer when it arrived. With none - a track found by Scan folders,
  // or a picture that won't load - a tile in its Camelot colour stands in, so rows line up.
  function coverTile(t, cls, onBlank) {
    const blank = () => {
      const s = el("span", cls + " blank");
      s.style.setProperty("--cam", camColor(t.camelot));
      s.setAttribute("aria-hidden", "true");
      return s;
    };
    if (!t.art) return blank();
    const img = el("img", cls);
    img.alt = "";
    img.loading = "lazy";
    img.decoding = "async";
    img.draggable = false;
    img.onerror = () => { const b = blank(); img.replaceWith(b); if (onBlank) onBlank(b); };
    img.src = t.art;
    return img;
  }
  // The crate redraws on every star and every arrival, and booth view every two seconds. A fresh
  // <img> each time would flicker - the window's server tells the browser not to cache anything - so
  // each place keeps its cover element and moves it into the new row instead.
  const covers = new Map();
  function keptCover(key, t, cls) {
    const have = covers.get(key);
    if (have && have.art === (t.art || "") && have.cam === t.camelot) return have.node;
    const entry = { art: t.art || "", cam: t.camelot };
    entry.node = coverTile(t, cls, b => { entry.node = b; });
    covers.set(key, entry);
    return entry.node;
  }

  // How loud the track is along its length - the build, the drop, the breakdown - from the 120
  // characters analysis wrote. One silhouette, stretched to the row, under everything else in it.
  const WAVE_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_";
  const SVG_NS = "http://www.w3.org/2000/svg";
  function waveStrip(t) {
    if (!t.wave) return null;
    const n = t.wave.length;
    let d = "M0 1";
    for (let i = 0; i < n; i++) {
      const h = Math.max(0.05, WAVE_CHARS.indexOf(t.wave[i]) / 63);
      d += `L${i + 0.5} ${(1 - h).toFixed(3)}`;
    }
    d += `L${n} 1Z`;
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("class", "cwave");
    svg.setAttribute("viewBox", `0 0 ${n} 1`);
    svg.setAttribute("preserveAspectRatio", "none");
    svg.setAttribute("aria-hidden", "true");
    const path = document.createElementNS(SVG_NS, "path");
    path.setAttribute("d", d);
    svg.append(path);
    return svg;
  }

  // ── a track landing ───────────────────────────────────────────────────
  // A finished download used to appear in the crate without a word. Now its row arrives with one
  // pulse of the accent, and the count in the top bar ticks up to take it in. Once, then it's a row.
  // The start time is kept rather than a flag, because the crate redraws often: a redraw mid-pulse
  // carries on from where it was instead of starting it again.
  const LAND_MS = 1800;
  const landedAt = new Map();
  let tickCount = false, countShown = null, scanning = false;

  // A long folder path gives way to the tabs beside it: where it starts, then its last two folders. The whole
  // path is the tooltip.
  function shortPath(p) {
    p = String(p || "");
    const parts = p.split(/[\\/]+/).filter(Boolean);
    if (p.length <= 44 || parts.length <= 3) return p;
    const sep = p.includes("\\") ? "\\" : "/";
    return (p.startsWith("/") ? "/" : "") + parts[0] + sep + "…" + sep + parts.slice(-2).join(sep);
  }
  // ── listen before you load ─────────────────────────────────────────────
  // One track at a time, in a bar along the bottom: its shape to click on, its hot cues to jump to. The audio comes
  // from the file where it lives (player.py); a kind the web view can't play is asked for again as a plain copy.
  const playing = { id: null, plainTried: false };
  const plAudio = $("#pl-audio");
  const clock = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
  function playerPaint() {
    const d = plAudio.duration || 0, at = plAudio.currentTime || 0;
    $("#pl-time").textContent = d ? `${clock(at)} / ${clock(d)}` : clock(at);
    const part = d ? at / d : 0;
    $("#pl-head").style.left = `${part * 100}%`;
    const bars = $("#pl-bars").children, upTo = part * bars.length;
    for (let i = 0; i < bars.length; i++) bars[i].classList.toggle("on", i < upTo);
    $("#pl-wave").setAttribute("aria-valuenow", String(Math.round(part * 100)));
    $("#player").classList.toggle("is-playing", !plAudio.paused);
    $("#pl-play").setAttribute("aria-label", plAudio.paused ? "Play" : "Pause");
  }
  async function playTrack(id, at) {
    const t = trackById(id) || state.crate.get(id) || state.requests.get(id);
    if (!t) return;
    if (playing.id === id && plAudio.src) {                 // the same track again: play or pause, or jump
      if (at != null) { plAudio.currentTime = at; plAudio.play().catch(() => {}); }
      else if (plAudio.paused) plAudio.play().catch(() => {}); else plAudio.pause();
      return;
    }
    const r = await call("preview_url", id, false);
    if (!r || !r.ok) return toast((r && r.error) || "Couldn't play that.", true);
    playing.id = id; playing.plainTried = false; playing.startAt = at || 0;
    $("#pl-title").textContent = t.title || "Untitled";
    $("#pl-sub").textContent = [t.artist, t.camelot, t.bpm ? `${Math.round(t.bpm * 10) / 10} BPM` : ""].filter(Boolean).join(" · ");
    const wave = t.wave || "";
    $("#pl-bars").replaceChildren(...[...(wave || "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW")].map(ch => {
      const bar = document.createElement("i");
      bar.style.height = `${Math.max(8, Math.round(WAVE_CHARS.indexOf(ch) / 63 * 100))}%`;
      return bar;
    }));
    const len = t.length || 0;
    $("#pl-marks").replaceChildren(...(len ? (t.cues || []) : []).map(c => { const m = document.createElement("i"); m.style.left = `${Math.min(100, c.at / len * 100)}%`; return m; }));
    $("#pl-cues").replaceChildren(...(t.cues || []).slice(0, 8).map((c, i) => {
      const b = el("button", "pl-cue", `${String.fromCharCode(65 + i)} ${c.name} ${clock(c.at)}`);
      b.type = "button";
      b.title = `Jump to ${c.name}`;
      b.onclick = () => { plAudio.currentTime = c.at; plAudio.play().catch(() => {}); };
      return b;
    }));
    $("#player").hidden = false;
    document.documentElement.classList.add("has-player");
    plAudio.src = r.url;
    plAudio.play().catch(() => {});
    document.querySelectorAll(".cplay.on").forEach(x => x.classList.remove("on"));
    document.querySelector(`#track-${CSS.escape(id)} .cplay`)?.classList.add("on");
  }
  function closePlayer() {
    plAudio.pause();
    plAudio.removeAttribute("src");
    plAudio.load();
    playing.id = null;
    $("#player").hidden = true;
    document.documentElement.classList.remove("has-player");
    document.querySelectorAll(".cplay.on").forEach(x => x.classList.remove("on"));
  }
  plAudio.addEventListener("loadedmetadata", () => { if (playing.startAt) { plAudio.currentTime = playing.startAt; playing.startAt = 0; } playerPaint(); });
  ["timeupdate", "play", "pause", "ended", "seeked"].forEach(ev => plAudio.addEventListener(ev, playerPaint));
  plAudio.addEventListener("error", async () => {
    if (!playing.id || !plAudio.getAttribute("src")) return;
    if (playing.plainTried) { toast("This kind of file can't be played here. It will still play in your DJ software.", true); return closePlayer(); }
    playing.plainTried = true;                              // once: a plain copy the web view can play
    const at = plAudio.currentTime || 0;
    const r = await call("preview_url", playing.id, true);
    if (!r || !r.ok) { toast((r && r.error) || "Couldn't play that.", true); return closePlayer(); }
    playing.startAt = at;
    plAudio.src = r.url;
    plAudio.play().catch(() => {});
  });
  $("#pl-play").onclick = () => { if (plAudio.paused) plAudio.play().catch(() => {}); else plAudio.pause(); };
  $("#pl-close").onclick = closePlayer;
  {
    const waveBox = $("#pl-wave");
    const seek = e => { const r = waveBox.getBoundingClientRect(), d = plAudio.duration || 0; if (d) plAudio.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * d; };
    let held = false;
    waveBox.addEventListener("pointerdown", e => { held = true; waveBox.setPointerCapture(e.pointerId); seek(e); });
    waveBox.addEventListener("pointermove", e => { if (held) seek(e); });
    waveBox.addEventListener("pointerup", () => { held = false; });
    waveBox.addEventListener("keydown", e => {
      const d = plAudio.duration || 0;
      if (e.key === "ArrowRight") { plAudio.currentTime = Math.min(d, plAudio.currentTime + 5); e.preventDefault(); }
      else if (e.key === "ArrowLeft") { plAudio.currentTime = Math.max(0, plAudio.currentTime - 5); e.preventDefault(); }
      else if (e.key === " " || e.key === "Enter") { $("#pl-play").click(); e.preventDefault(); }
    });
  }

  function crateRow(t) {
    const row = el("div", "crow" + (t.missing ? " missing" : "") + (state.active === t.id ? " active" : "")
                          + (picked.has(t.id) ? " picked" : ""));
    row.dataset.id = t.id;
    const requested = state.requests.has(t.id);
    row.id = "track-" + t.id;
    row.setAttribute("role", "option");
    row.tabIndex = 0;
    row.style.setProperty("--cam", camColor(t.camelot));
    const landed = landedAt.get(t.id);
    if (landed != null) {
      const age = performance.now() - landed;
      if (age < LAND_MS) { row.classList.add("landed"); row.style.setProperty("--land-delay", `${-Math.round(age)}ms`); }
      else landedAt.delete(t.id);
    }
    const grip = el("span", "grip");
    const who = el("div", "ct");
    const words = el("div", "ct-t");
    const sub = t.missing ? "File moved or deleted" : t.artist || (t.origin === "scan" ? "From your folder" : "");
    const line = el("small", null, sub);
    if (t.folder) {
      // Which imported folder it came from - the last part of the path, the whole path on hover.
      const tag = el("span", "ftag", t.folder.split("/").pop());
      tag.title = t.folder.split("/").join(" / ");
      line.append(tag);
    }
    const nk = nicheKey(t);
    if (nk && nicheName(nk)) {
      // Its genre, worked out by the app - quiet, and put right in the open row if it's wrong.
      const g = el("span", "ftag gtag", nicheName(nk));
      g.title = `${nicheName(nk, true)} - ${nicheHow(t.niche)}. Open the track to change it`;
      line.append(g);
    }
    for (const tag of (t.tags || []).slice(0, 2)) {
      const chip = el("span", "ftag ttag", tag);
      chip.title = `Tagged ${(t.tags || []).join(", ")} - click to show only these`;
      chip.onclick = e => { e.stopPropagation(); $("#crate-search").value = "#" + tag; renderCrate(); };
      line.append(chip);
    }
    const issue = healthIssue(t);
    if (issue) {
      const tag = el("span", "htag" + (issue.low ? " low" : ""), issue.flag);
      tag.title = issue.text;
      line.prepend(tag);                   // first, so a long artist name can't push it out of sight
    }
    const name = el("b", null, t.title || "Untitled");
    words.append(name, line);
    // A title or artist too long for the row: the whole of it on the pointer, only when it's actually cut.
    words.addEventListener("pointerenter", () => {
      name.title = name.scrollWidth > name.clientWidth ? t.title || "" : "";
      if (!line.title || line.title === sub) line.title = line.scrollWidth > line.clientWidth ? sub : "";
    });
    who.append(keptCover("row:" + t.id, t, "cart"), words);
    if (!t.missing) {
      // Over the cover, on the pointer: play it here. The row itself still selects, drags and opens.
      const play = el("button", "cplay" + (playing.id === t.id ? " on" : ""));
      play.type = "button";
      play.title = "Listen";
      play.setAttribute("aria-label", `Listen to ${t.title || "this track"}`);
      play.onclick = e => { e.stopPropagation(); playTrack(t.id); };
      who.append(play);
    }
    const cam = el("span", "cam", t.camelot || "—");
    cam.style.setProperty("--cam", camColor(t.camelot));
    // One button per row, and it is a word rather than an icon: Delete takes the track out of the list
    // AND sends the audio to the Recycle Bin. Two clicks, and it's the bin rather than an erase, so a
    // mis-click is recoverable. A row whose file has already gone just says Remove.
    const label = t.missing ? "Remove" : "Delete";
    const bin = el("button", "crow-del", label);
    bin.type = "button";
    bin.title = t.missing
      ? "Take this out of the list - the file itself is already gone"
      : "Delete the file itself - it's kept for 30 days, so you can put it back (Settings, What changed)";
    let armed = 0;
    const disarm = () => { clearTimeout(armed); armed = 0; bin.classList.remove("arm"); bin.textContent = label; };
    bin.onclick = async e => {
      e.stopPropagation();
      if (!armed) {
        bin.classList.add("arm");
        bin.textContent = "Sure?";
        armed = setTimeout(disarm, 5000);
        return;
      }
      disarm();
      bin.disabled = true;
      const r = await call("crate_remove", t.id, true);
      if (r.ok === false) { bin.disabled = false; return toast(r.error, true); }
      syncLibrary(r);
      refreshRekordboxSoon();
      if (state.active === t.id) selectTrack(null);
      if (t.missing) {
        toast(`“${t.title || "Track"}” taken out of the list.`);
      } else {
        // Ten seconds to change your mind, without leaving the app to go hunting in the bin.
        toastWithAction(`“${t.title || "Track"}” deleted.`, "Undo", async () => {
          const back = await call("restore_track", t.id);
          if (!back.ok) return toast(back.error || "Couldn't put that one back.", true);
          syncLibrary(back);
          refreshRekordboxSoon();
          toast(`“${t.title || "Track"}” is back in your crate.`);
        });
      }
    };
    row.addEventListener("pointerleave", () => { if (armed) disarm(); });
    // One grid cell holds the row's buttons, so the row keeps its seven columns however many there are.
    const acts = el("div", "crow-acts");
    row.append(grip, who, el("span", "cn", t.bpm ? String(Math.round(t.bpm * 10) / 10) : "—"), el("span", "ck", t.key || "—"), cam,
               el("span", "cl", fmtLen(t.length)), acts);
    if (requested) {
      // Keep: the file moves into the save folder and the track joins the crate.
      const keep = el("button", "keep", "Keep");
      keep.type = "button";
      keep.title = "Move this into your crate and your save folder";
      keep.onclick = async e => {
        e.stopPropagation();
        keep.disabled = true;
        const r = await call("request_to_crate", t.id);
        if (!r.ok) { keep.disabled = false; return toast(r.error, true); }
        syncLibrary(r);
        refreshRekordboxSoon();
        toast(`“${t.title}” kept in your crate`);
      };
      acts.append(keep);
    }
    acts.append(bin);
    // Your own marks sit in the same last cell as Delete. As a cell of their own they were an eighth
    // item in a seven-column row, which pushed Delete onto a second line the row then clipped away.
    if (!t.missing && state.store !== "requests") acts.prepend(stars(t));
    const wave = waveStrip(t);
    if (wave) row.append(wave);
    // A modified click builds a selection; a plain one selects the single track as before.
    row.addEventListener("click", (e) => { if (handlePick(e, t.id)) { e.preventDefault(); e.stopPropagation(); } }, true);
    if (!t.missing) {
      makeDraggable(row, t.path, () => { selectTrack(t.id); toggleOpen(t.id); }, () => pickedPaths(t));
    } else row.onclick = () => { selectTrack(t.id); toggleOpen(t.id); };
    row.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); selectTrack(t.id); } });
    row.addEventListener("dblclick", () => { if (!t.missing) call("open_path", t.path, true); });
    return row;
  }
  // ── rows that move instead of blinking ────────────────────────────────
  // ── only the rows on screen ───────────────────────────────────────────
  // The crate drew a row for every track: 3,500 tracks was 3,500 rows, each with its waveform, built again on
  // every change - and the app crawled until you picked a smaller folder. Now only the rows in view exist, and
  // a few either side; two spacers stand in for the rest, so the list is exactly as tall and the scrollbar
  // exactly as long as before. However many tracks there are, a redraw is a few dozen rows.
  // `shown` is every track the filters leave, in order; crateIndex finds a track's place in it. Rows are all one
  // height (vPitch); the one open row's panel (openMore, openH tall) pushes the rows after it down.
  const V_EXTRA = 8;                           // rows drawn beyond each edge of the view
  let shown = [], crateIndex = new Map(), vFrom = 0, vTo = 0, vPitch = 54, vRaf = 0, openMore = null, openH = 0;
  const rowsBox = () => $("#crate-rows");
  const openAt = () => (openRow && crateIndex.has(openRow) ? crateIndex.get(openRow) : -1);
  const rowY = i => i * vPitch + (openAt() >= 0 && i > openAt() ? openH : 0);
  function rowAtY(y) {
    const o = openAt();
    if (o < 0 || y <= (o + 1) * vPitch) return Math.floor(y / vPitch);
    if (y < (o + 1) * vPitch + openH) return o + 1;
    return Math.floor((y - openH) / vPitch);
  }
  function drawRows(force) {
    const box = rowsBox(), list = $("#crate-list"), n = shown.length, o = openAt();
    const y = Math.max(0, list.scrollTop - box.offsetTop), h = list.clientHeight || 620;
    const first = Math.max(0, Math.min(n - 1, rowAtY(y))), last = Math.max(first, Math.min(n - 1, rowAtY(y + h)));
    // Scrolling only redraws once the view nears the edge of what's drawn.
    if (!force && vTo > vFrom && first >= vFrom + (vFrom > 0 ? 2 : 0) && last < vTo - (vTo < n ? 2 : 0)) return;
    const from = Math.max(0, first - V_EXTRA), to = Math.min(n, last + 1 + V_EXTRA);
    const kept = new Map();                       // a scroll keeps the rows it still needs; a redraw makes them afresh
    if (!force) for (const node of box.children) if (node.dataset.id) kept.set(node.dataset.id, node);
    const pad = px => { const d = el("div", "vpad"); d.style.height = `${Math.max(0, px)}px`; return d; };
    const nodes = [pad(rowY(from))];
    for (let i = from; i < to; i++) {
      const t = shown[i], row = kept.get(t.id) || crateRow(t);
      nodes.push(row);
      if (i === o) {                              // an open row stays open through a redraw and a scroll
        row.classList.add("open");
        if (force || !openMore) { openMore = moreFor(t); openMore.classList.add("shown"); }
        nodes.push(openMore);
      }
    }
    nodes.push(pad(rowY(n) - rowY(to)));
    box.replaceChildren(...nodes);
    vFrom = from; vTo = to;
    const probe = box.querySelector(".crow");
    if (probe && probe.offsetHeight > 20 && Math.abs(probe.offsetHeight - vPitch) > 0.4) { vPitch = probe.offsetHeight; return drawRows(true); }
    if (o >= from && o < to && openMore && openMore.offsetHeight) openH = openMore.offsetHeight;
  }
  function setShown(list) {
    shown = list;
    crateIndex = new Map(list.map((t, i) => [t.id, i]));
    if (openRow && !crateIndex.has(openRow)) { openRow = null; openMore = null; openH = 0; }
    const view = $("#crate-list"), max = Math.max(0, rowsBox().offsetTop + rowY(list.length) - view.clientHeight);
    if (view.scrollTop > max) view.scrollTop = max;
    drawRows(true);
  }
  // Bring a track's row into the list's view - drawing it if it wasn't - without moving the page.
  function showRow(id, mode) {
    const i = crateIndex.get(id);
    if (i == null) return null;
    const list = $("#crate-list"), head = list.querySelector(".crate-head");
    const top = rowsBox().offsetTop + rowY(i), headH = head ? head.offsetHeight : 0;
    if (mode === "center") list.scrollTop = top - (list.clientHeight - vPitch) / 2;
    else if (top < list.scrollTop + headH) list.scrollTop = top - headH;
    else if (top + vPitch > list.scrollTop + list.clientHeight) list.scrollTop = top + vPitch - list.clientHeight;
    drawRows(false);
    return document.getElementById("track-" + id);
  }
  // A filter used to redraw the crate in one go, so you couldn't see what it took away. Now rows that
  // stay glide to their new places, new ones fade in, and the ones that go fade where they were.
  // Only for filters you pick - a key, a folder, a smart crate, a tempo range - never while typing,
  // where rows sliding on every keystroke would be tiring. Only rows actually on screen are measured.
  let flipNext = false;
  function flipRows(box, list) {
    const animate = flipNext && !REDUCED;
    flipNext = false;
    const scroller = $("#crate-list");
    const view = scroller.getBoundingClientRect();
    const seen = r => r.height > 0 && r.bottom > view.top && r.top < view.bottom;
    const first = new Map(), before = new Map();
    if (animate) {
      for (const row of box.children) {
        if (!row.dataset.id) continue;
        const r = row.getBoundingClientRect();
        if (seen(r)) { first.set(row.dataset.id, r); before.set(row.dataset.id, row); }
      }
    }
    setShown(list);                              // draws the rows in view (an open row stays open)
    if (!animate) return;
    const now = new Set(list.map(t => t.id));
    for (const [id, f] of first) {
      if (now.has(id)) continue;
      // The old row, lifted out where it was, fades while the others move up under it.
      const ghost = before.get(id);
      ghost.removeAttribute("id");
      delete ghost.dataset.id;
      Object.assign(ghost.style, { position: "absolute", left: `${f.left - view.left}px`, width: `${f.width}px`,
        top: `${f.top - view.top + scroller.scrollTop}px`, pointerEvents: "none", zIndex: "0", margin: "0" });
      scroller.append(ghost);
      ghost.animate([{ opacity: 1 }, { opacity: 0, transform: "scale(0.98)" }], { duration: 240, easing: "ease-out", fill: "forwards" });
      setTimeout(() => ghost.remove(), 290);
    }
    for (const row of box.children) {
      if (!row.dataset.id) continue;
      const r = row.getBoundingClientRect();
      if (!seen(r)) continue;
      const f = first.get(row.dataset.id);
      if (f) {
        const dy = f.top - r.top;
        if (Math.abs(dy) > 1) row.animate([{ transform: `translateY(${dy}px)` }, { transform: "none" }], { duration: 560, easing: EASE });
      } else {
        row.animate([{ opacity: 0, transform: "translateY(8px)" }, { opacity: 1, transform: "none" }], { duration: 420, delay: 150, easing: EASE, fill: "backwards" });
      }
    }
  }
  // The filters you pick, as opposed to type, ask for the movement.
  const flipOn = () => { flipNext = true; setTimeout(() => { flipNext = false; }, 500); };
  keySelect.addEventListener("change", flipOn, true);
  ["#bpm-min", "#bpm-max"].forEach(s => $(s).addEventListener("change", flipOn, true));
  ["#crate-folders", "#smart-list"].forEach(s => $(s).addEventListener("click", flipOn, true));

  // ── rows that open in place ───────────────────────────────────────────
  // What the app worked out about a track - the other tempo reading, how sure it is of the key, the
  // relative key, where it came from - showed once on the download row and never again. Clicking a
  // crate row now opens it to show all of that. One open at a time; arrows close it.
  let openRow = null;
  // The crate's rows follow its scrolling and its size (drawRows, above) - wired here, once openRow exists.
  {
    const list = $("#crate-list");
    list.addEventListener("scroll", () => { if (!vRaf) vRaf = requestAnimationFrame(() => { vRaf = 0; drawRows(false); }); }, { passive: true });
    new ResizeObserver(() => drawRows(false)).observe(list);
  }
  const SOURCE_HOSTS = [["youtu", "A YouTube link"], ["spotify", "A Spotify link, matched on YouTube"], ["apple", "An Apple Music link, matched on YouTube"], ["soundcloud", "A SoundCloud link"]];
  function cameFrom(t) {
    if (t.origin === "phone") return "A phone request";
    if (t.origin === "scan") return "Already in your save folder";
    if (t.origin === "stemsplitter") return "The Stem Splitter";
    if (t.origin === "intro") return "An extended intro, made here";
    if (t.origin === "dropped") return "Dropped in";
    if (t.origin === "purchase") return "Your purchases folder";
    // Taken in where they already live: a library folder from Settings, Serato's own library, a rekordbox export.
    if (t.origin === "library") return "Your music folder";
    if (t.origin === "serato") return "Your Serato library";
    if (t.origin === "rekordbox") return "Your rekordbox collection";
    if (!t.source) return "";
    try {
      const host = new URL(t.source).hostname;
      const hit = SOURCE_HOSTS.find(([k]) => host.includes(k));
      return hit ? hit[1] : `A link from ${host.replace(/^www\./, "")}`;
    } catch (e) { return ""; }
  }
  function agoText(ts) {
    if (!ts) return "";
    const d = (Date.now() / 1000 - ts) / 86400;
    return d < 1 ? "Today" : d < 2 ? "Yesterday" : d < 14 ? `${Math.floor(d)} days ago` : d < 60 ? `${Math.floor(d / 7)} weeks ago` : new Date(ts * 1000).toLocaleDateString();
  }
  // What the background check found (health.py), in words - or "" when there's nothing to say.
  const LOW_KHZ = 16;
  function healthIssue(t) {
    if (t.missing || !t.health_v) return null;
    if (t.health === "broken") return { flag: "Won't open", text: "Won't open as audio - get it again" };
    if (t.health === "short") return { flag: "Cut short", text: t.played && t.length
      ? `Stops at ${fmtLen(t.played)} of ${fmtLen(t.length)} - the download was cut off. Get it again`
      : "Stops before the end - the download was cut off. Get it again" };
    if (t.cutoff && t.cutoff < LOW_KHZ && t.origin !== "stemsplitter")
      return { flag: "Low quality", low: true, text: `A low-quality rip - nothing above ${t.cutoff} kHz, so it sounds dull on a big system. Worth finding a better copy` };
    return null;
  }
  function healthText(t) {
    const issue = healthIssue(t);
    if (issue) return issue.text;
    if (!t.health_v) return "";
    return t.cutoff ? `Whole, and a proper copy - reaches ${t.cutoff} kHz` : "Whole";
  }
  // ── genres, worked out on their own ───────────────────────────────────
  // Every track's genre down to the niche - Rawstyle, not Dance - worked out by the app from the file's tags, the
  // title, who made or remixed it, its folder, Apple's catalogue and its tempo (genres.py). Nobody has to tag a
  // thing. It shows on the row, and the open row has a box to put it right, which is remembered.
  const genreNames = new Map();
  let genreTree = [], genreBy = {};
  function loadGenres() {
    return call("genres_info").then(g => {
      if (!g || !g.tree) return;
      genreTree = g.tree; genreBy = g.by || {};
      genreNames.clear();
      for (const p of g.tree) {
        genreNames.set(p.k, { name: p.name, full: p.name });
        for (const s of p.subs) genreNames.set(s.k, { name: s.name, full: s.full, parent: p.name });
      }
      renderCrateSoon();
      if (currentSet()) renderSet();
    }).catch(() => {});
  }
  const nicheKey = t => (t && t.niche && t.niche.k) || "";
  const nicheName = (k, full) => { const g = genreNames.get(k || ""); return g ? (full ? g.full : g.name) : ""; };
  // "from the artist and the tempo"
  const nicheHow = n => (n && n.by ? n.by.split("+").map(b => genreBy[b] || "").filter(Boolean).join(" and ").replace(/ and from /g, " and ") : "");
  function genreRow(t) {
    const row = el("label", "note-row genre-row");
    const pick = el("select", "genre-in");
    pick.setAttribute("aria-label", "This track's genre");
    const worked = nicheName(nicheKey(t), true);
    pick.append(new Option(t.niche_fix ? "Let DJ Master work it out" : worked ? `${worked} - worked out` : "Not sure yet - worked out", ""));
    for (const p of genreTree) {
      const g = document.createElement("optgroup");
      g.label = p.name;
      g.append(new Option(`${p.name}, any`, p.k), ...p.subs.map(s => new Option(s.full, s.k)));
      pick.append(g);
    }
    pick.value = t.niche_fix || "";
    pick.addEventListener("keydown", e => e.stopPropagation());
    pick.addEventListener("change", async () => {
      const r = await call("set_genre", t.id, pick.value).catch(() => null);
      if (!r || !r.ok) return toast((r && r.error) || "That didn't go through.", true);
      const mine = state.crate.get(t.id) || t;
      Object.assign(mine, { niche_fix: r.niche_fix, niche: r.niche, niche_in: r.niche_in });
      toast(r.niche_fix ? `Kept as ${nicheName(r.niche_fix, true)}.` : `Back to the app's own reading${nicheKey(mine) ? `: ${nicheName(nicheKey(mine), true)}` : ""}.`);
      renderCrateSoon();
      genreSoon();
    });
    row.append(el("span", "label", "Genre"), pick);
    return row;
  }

  // ── tags and a note ───────────────────────────────────────────────────
  // Stars and energy can't say "opener", "singalong" or "clean version". Your own tags can, and one line of notes
  // says the rest. Both are searched by the crate's search box (#opener shows exactly that tag), can drive a crate
  // that fills itself, and go to rekordbox in the comment.
  const TAG_IDEAS = ["opener", "warm-up", "peak", "closer", "singalong", "clean", "explicit", "instrumental", "request"];
  let refocusTags = null;                     // the track whose tag box gets the caret back after a redraw
  function tagsAndNote(t) {
    const box = el("div", "marks-edit");
    box.addEventListener("click", e => e.stopPropagation());
    const save = async fields => {
      const res = await call("set_marks", t.id, null, null, fields.tags ?? null, fields.note ?? null);
      syncCrate(res.crate);
      renderSmart(res.smart);
      refreshRekordboxSoon();
    };
    const tags = [...(t.tags || [])];
    const row = el("div", "tag-row"), tagList = el("div", "tag-list");
    row.append(el("span", "label", "Tags"), tagList);
    for (const tag of tags) {
      const chip = el("button", "tag-chip", tag);
      chip.type = "button";
      chip.title = "Take this tag off";
      chip.append(el("span", "x", "×"));
      chip.onclick = () => { refocusTags = { id: t.id, until: performance.now() + 1500 }; save({ tags: tags.filter(x => x !== tag) }); };
      tagList.append(chip);
    }
    const input = el("input", "tag-add");
    input.type = "text"; input.maxLength = 24; input.spellcheck = false;
    input.placeholder = tags.length ? "Add another" : "opener, singalong, clean…";
    input.setAttribute("aria-label", "Add a tag");
    input.setAttribute("list", "tag-ideas");
    const add = () => {
      const fresh = input.value.split(",").map(x => x.replace(/#/g, "").trim().toLowerCase()).filter(x => x && !tags.includes(x));
      if (!fresh.length) { input.value = ""; return; }
      refocusTags = { id: t.id, until: performance.now() + 1500 };
      save({ tags: [...tags, ...fresh] });
    };
    input.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); add(); } });
    input.addEventListener("change", add);
    tagList.append(input);
    if (tags.length >= 8) input.hidden = true;
    // The ideas: the tags you already use, then a few to start from.
    let ideas = document.getElementById("tag-ideas");
    if (!ideas) { ideas = document.createElement("datalist"); ideas.id = "tag-ideas"; document.body.append(ideas); }
    const used = new Set();
    for (const x of state.crate.values()) for (const tag of x.tags || []) used.add(tag);
    ideas.replaceChildren(...[...new Set([...used, ...TAG_IDEAS])].filter(x => !tags.includes(x)).map(x => { const o = document.createElement("option"); o.value = x; return o; }));
    const noteRow = el("label", "note-row");
    const note = el("input", "note-in");
    note.type = "text"; note.maxLength = 200; note.value = t.note || "";
    note.placeholder = "A note to yourself - what it follows, where to come in";
    note.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter") note.blur(); });
    note.addEventListener("change", () => { if (note.value.trim() !== (t.note || "")) save({ note: note.value }); });
    noteRow.append(el("span", "label", "Note"), note);
    box.append(row, noteRow);
    if (genreTree.length) box.append(genreRow(t));
    if (refocusTags && refocusTags.id === t.id && performance.now() < refocusTags.until) setTimeout(() => { if (input.isConnected) input.focus({ preventScroll: true }); }, 40);
    return box;
  }

  function moreFor(t) {
    const more = el("div", "crow-more");
    const inner = el("div");
    const dl = el("dl", "crow-dl");
    const add = (k, v) => { if (!v) return; const d = el("div"); d.append(el("dt", null, k), el("dd", null, v)); dl.append(d); };
    const conf = t.confidence == null ? null : Math.round(t.confidence <= 1 ? t.confidence * 100 : t.confidence);
    const r1 = n => Math.round(n * 10) / 10;
    add("Track", [t.title, t.artist].filter(Boolean).join(" - "));        // in full: the row cuts a long one short
    add("Tempo", t.bpm ? `${r1(t.bpm)} BPM${t.bpm_alt ? ` · could also read as ${r1(t.bpm_alt)}` : ""}` : "Not measured");
    add("Key", t.camelot ? [`${t.camelot}${t.key ? " · " + t.key : ""}`, t.relative ? `relative ${t.relative}` : "", conf != null ? `${conf}% sure` : ""].filter(Boolean).join(" · ") : "Not measured");
    add("Came from", cameFrom(t));
    add("Added", [agoText(t.added), t.folder ? `in ${t.folder.split("/").pop()}` : "", t.length ? fmtLen(t.length) : ""].filter(Boolean).join(" · "));
    if (t.niche) add("Genre", nicheKey(t)
      ? [nicheName(nicheKey(t), true), (() => { const p = (genreNames.get(nicheKey(t)) || {}).parent || "";      // "Frenchcore · Hardcore", not "Euphoric hardstyle · Hardstyle"
          return p && !nicheName(nicheKey(t), true).toLowerCase().includes(p.toLowerCase()) ? p : ""; })(), nicheHow(t.niche),
         t.niche.c < 1 && t.niche.c ? `${Math.round(t.niche.c * 100)}% sure` : ""].filter(Boolean).join(" · ")
      : "Not sure - nothing in its tags, title or artist points to one yet");
    add("Health", healthText(t));
    add("Cues", (t.cues || []).map(c => `${c.name} ${Math.floor(c.at / 60)}:${String(Math.floor(c.at % 60)).padStart(2, "0")}`).join(" · "));
    add("Your marks", [t.rating ? "\u2605".repeat(t.rating) : "", t.energy ? `energy ${t.energy}` : t.energy_auto ? `energy ≈${t.energy_auto} (estimated)` : ""].filter(Boolean).join(" · ")
      || "None yet - stars on the row, energy under Mixes well with");
    inner.append(dl);
    if (!t.missing && state.store !== "requests") inner.append(tagsAndNote(t));
    const go = el("div", "crow-go");                // what you can do with it: one row, under the facts
    inner.append(go);
    if (!t.missing && state.store !== "requests") {
      const toSet = el("button", "btn-text", inSet(t.id) ? "In your set ✓" : "Add to set →");
      toSet.type = "button";
      toSet.disabled = inSet(t.id);
      toSet.onclick = e => { e.stopPropagation(); addToSet([t.id]); toSet.textContent = "In your set ✓"; toSet.disabled = true; };
      go.append(toSet);
    }
    // The other app: split this track into stems there. Only offered when it's installed on this computer.
    if (state.stemSplitter && !t.missing) {
      const split = el("button", "btn-text", "Split in the Stem Splitter →");
      split.type = "button";
      split.title = "Send this track to the Stem Splitter, which opens and queues it";
      split.onclick = async e => {
        e.stopPropagation();
        split.disabled = true;
        const r = await call("split_in_stem_splitter", t.id);
        split.disabled = false;
        if (!r.ok) return toast(r.error, true);
        toast(`“${t.title}” sent to the Stem Splitter - it's in its queue. The stems land in its save folder, not your crate.`, false, 7000);
      };
      go.append(split);
    }
    // A copy with 16 or 32 bars of its own music, vocal taken out, up front (intro.py) - both editions. Not of an intro.
    if (boot && !t.missing && state.store !== "requests" && t.origin !== "intro") {
      const ext = el("button", "btn-text intro-make", "Extended intro →");
      ext.type = "button";
      ext.dataset.id = t.id;
      ext.title = "Make a copy that starts with this track's own music, vocal taken out (Settings > General sets 16 or 32 bars)";
      ext.onclick = async e => {
        e.stopPropagation();
        ext.disabled = true;
        const r = await call("make_intro", t.id);
        if (!r || !r.ok) { ext.disabled = false; return toast((r && r.error) || "Couldn't start the intro.", true); }
        ext.textContent = "Making the intro…";
        toast(`Making a ${r.bars}-bar intro of “${t.title}” - about half a minute. The first one also downloads the vocal remover (67 MB, once).`, false, 7000);
      };
      go.append(ext);
    }
    more.append(inner);
    return more;
  }
  function closeOpen() {
    if (!openRow) return;
    openRow = null; openMore = null; openH = 0;
    document.querySelectorAll("#crate-rows .crow.open").forEach(r => r.classList.remove("open"));
    document.querySelectorAll("#crate-rows .crow-more").forEach(m => {
      if (REDUCED) return m.remove();
      m.classList.remove("shown");
      setTimeout(() => m.remove(), 620);
    });
  }
  function toggleOpen(id) {
    const again = openRow === id;
    closeOpen();
    if (again) return;
    const t = trackById(id), row = document.getElementById("track-" + id);
    if (!t || !row) return;
    openRow = id;
    row.classList.add("open");
    const more = moreFor(t);
    row.after(more);
    openMore = more; openH = 0;
    // Laid out closed first, so opening is a transition rather than a jump.
    if (!REDUCED) void more.offsetHeight;
    more.classList.add("shown");
    setTimeout(() => { if (openMore === more) openH = more.offsetHeight; }, REDUCED ? 0 : 650);   // how far it pushes the rows below
  }

  // ── lists that show there's more ──────────────────────────────────────
  // The crate scrolls inside its own box and nothing said so. The edge now fades wherever there is
  // more to scroll, and sharpens at the end - under the sticky column heads, so they stay crisp.
  function syncEdges(box) {
    if (!box) return;
    box.classList.toggle("more-up", box.scrollTop > 2);
    box.classList.toggle("more-down", box.scrollTop + box.clientHeight < box.scrollHeight - 2);
  }
  ["#crate-list", "#palette-list", ".mixes"].forEach(sel => {
    const box = $(sel);
    if (!box) return;
    box.classList.add("edge-fade");
    let raf = 0;
    box.addEventListener("scroll", () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; syncEdges(box); }); }, { passive: true });
    new ResizeObserver(() => syncEdges(box)).observe(box);
  });

  // ── more than one at a time ────────────────────────────────────────────
  // 420 tracks and everything was one at a time. Shift-click takes a run of them, Ctrl or Cmd adds
  // and removes one, and whatever is picked can be deleted or dragged into rekordbox together.
  const picked = new Set();
  let anchor = null;                          // where a shift-click measures its run from

  function visibleIds() {
    return shown.map(t => t.id);              // every track the filters leave - not only the rows drawn
  }

  function paintPicked() {
    [...$("#crate-rows").children].forEach(row => row.classList.toggle("picked", picked.has(row.dataset.id)));
    const bar = $("#pickbar");
    bar.hidden = picked.size < 2;             // one track is just a selection; two is a job
    if (picked.size >= 2) $("#pick-count").textContent = `${picked.size} tracks picked`;
  }

  function handlePick(e, id) {
    const ids = visibleIds();
    if (e.shiftKey && anchor && ids.includes(anchor)) {
      const [from, to] = [ids.indexOf(anchor), ids.indexOf(id)].sort((x, y) => x - y);
      ids.slice(from, to + 1).forEach(x => picked.add(x));
    } else if (e.ctrlKey || e.metaKey) {
      picked.has(id) ? picked.delete(id) : picked.add(id);
      anchor = id;
    } else {
      return false;                           // an ordinary click still just selects the track
    }
    paintPicked();
    return true;
  }

  function clearPicked() { picked.clear(); anchor = null; paintPicked(); }

  $("#pick-clear").onclick = clearPicked;
  $("#pick-set").onclick = () => { addToSet(shown.filter(t => picked.has(t.id) && !t.missing).map(t => t.id)); clearPicked(); };
  $("#pick-delete").onclick = async () => {
    const btn = $("#pick-delete");
    if (btn.dataset.armed !== "1") {
      btn.dataset.armed = "1";
      btn.textContent = `Delete ${picked.size} — sure?`;
      setTimeout(() => { btn.dataset.armed = "0"; btn.textContent = "Delete picked"; }, 5000);
      return;
    }
    btn.dataset.armed = "0";
    btn.textContent = "Delete picked";
    const ids = [...picked];
    btn.disabled = true;
    const r = await call("crate_remove_many", ids, true);
    btn.disabled = false;
    clearPicked();
    syncLibrary(r);
    renderSmart(r.smart);
    refreshRekordboxSoon();
    toast(r.failed
      ? `${r.removed} deleted, ${r.failed} couldn't be. ${r.error || ""}`
      : `${r.removed} tracks deleted. They're kept for 30 days - Settings, What changed puts them back.`,
      !!r.failed);
  };

  // ── the lit read-out ───────────────────────────────────────────────────────────
  // Tempo, key and how much of your crate mixes with it, on a display you can read from the booth -
  // with the unlit digits faintly behind the lit ones, the way a real display has them. Picking another
  // track counts the tempo across to its new value in steps, like the hardware it borrows from.
  let readoutBpm = null, readoutMixes = null;
  function countTo(node, from, to) {
    if (REDUCED || from == null || from === to) { node.textContent = String(to); return; }
    let i = 0;
    const steps = 10;
    const iv = setInterval(() => {
      i++;
      node.textContent = String(Math.round(from + (to - from) * (i / steps)));
      if (i >= steps || !node.isConnected) clearInterval(iv);
    }, 42);
  }
  function readout(track) {
    const box = el("div", "lcd");
    const cell = (cls, label, ghost, sub) => {
      const c = el("div", "lcd-cell " + cls);
      const num = el("div", "lcd-num");
      num.append(el("span", "ghost", ghost), el("span", "val", ""));
      c.append(el("span", "lcd-label", label), num, el("small", null, sub));
      return c;
    };
    const bpm = track.bpm ? Math.round(track.bpm) : null;
    // The same 8% the mixing maths uses, so the display and the list below it agree.
    const tempo = cell("lcd-tempo", "Tempo", "888", bpm ? `mixes ${Math.round(bpm * 0.92)}-${Math.round(bpm * 1.08)}` : "not measured");
    const key = cell("lcd-key", "Key", "88", track.key || "");
    const mixes = cell("lcd-mixes", "Mixes", "88", "in your crate");
    key.querySelector(".val").textContent = track.camelot || "--";
    mixes.querySelector(".val").textContent = "--";
    const tv = tempo.querySelector(".val");
    if (bpm) (window.YCFX ? YCFX.roll(tv, readoutBpm, bpm) : countTo(tv, readoutBpm, bpm)); else tv.textContent = "---";
    readoutBpm = bpm;
    box.append(tempo, key, mixes, energyMeter(track));
    return box;
  }
  // Energy out of ten, set by hand: ten segments, click one to set it, click it again to clear.
  // It goes to rekordbox as "Energy 7" in the comment, the convention Mixed In Key started.
  function energyMeter(track) {
    const wrap = el("div", "energy");
    const bar = el("div", "energy-bar");
    bar.setAttribute("role", "group");
    bar.setAttribute("aria-label", "Energy, one to ten");
    const val = el("span", "energy-val");
    // Your energy when you've set one; otherwise the app's estimate, drawn fainter and marked ≈.
    const paint = n => {
      const auto = !n && track.energy_auto ? track.energy_auto : 0;
      const shown = n || auto;
      [...bar.children].forEach((s, i) => {
        s.classList.toggle("on", i < shown);
        s.classList.toggle("auto", !!auto && i < shown);
        s.setAttribute("aria-pressed", String(i + 1 === n));
      });
      val.textContent = n ? String(n) : auto ? `≈${auto}` : "-";
      val.title = auto ? "The app's estimate from the audio. Click a bar to set your own." : "";
    };
    for (let n = 1; n <= 10; n++) {
      const s = el("button", "energy-seg");
      s.type = "button";
      s.setAttribute("aria-label", `Energy ${n}`);
      s.onclick = async () => {
        const next = (track.energy || 0) === n ? 0 : n;
        track.energy = next;
        paint(next);
        const res = await call("set_marks", track.id, null, next);
        syncCrate(res.crate);
        renderSmart(res.smart);
        refreshRekordboxSoon();
      };
      bar.append(s);
    }
    paint(track.energy || 0);
    wrap.append(el("span", "lcd-label", "Energy"), bar, val);
    return wrap;
  }

  // ── your own opinion of a track ────────────────────────────────────────────────
  // The app can measure tempo and key. It cannot measure whether a record lands, so that part is
  // typed: five stars, and an energy out of ten. Both are what the smart crates below run on.
  function stars(track) {
    const box = el("div", "stars");
    box.title = "How good is it? Click a star; click the same one again to clear it";
    for (let n = 1; n <= 5; n++) {
      const star = el("button", "star" + (n <= (track.rating || 0) ? " on" : ""));
      star.type = "button";
      star.textContent = "\u2605";
      star.setAttribute("aria-label", `${n} star${n === 1 ? "" : "s"}`);
      star.onclick = async (e) => {
        e.stopPropagation();
        const next = (track.rating || 0) === n ? 0 : n;   // clicking the current one clears it
        track.rating = next;
        [...box.children].forEach((s, i) => s.classList.toggle("on", i < next));
        const res = await call("set_marks", track.id, next, null);
        syncCrate(res.crate);
        renderSmart(res.smart);
        refreshRekordboxSoon();
      };
      box.append(star);
    }
    return box;
  }

  // ── crates that fill themselves ────────────────────────────────────────
  let smartCrates = [];
  let crateFilterIds = null;                 // the smart crate currently being shown, if any
  let editing = null;                        // index being edited, or -1 for a new one

  function ruleFromForm() {
    const num = (id) => { const v = $(id).value.trim(); return v === "" ? null : +v; };
    const rule = { name: $("#sm-name").value.trim() || "Untitled" };
    const [bl, bh] = [num("#sm-bpm-lo"), num("#sm-bpm-hi")];
    if (bl !== null || bh !== null) rule.bpm = [bl, bh];
    const [el_, eh] = [num("#sm-en-lo"), num("#sm-en-hi")];
    if (el_ !== null || eh !== null) rule.energy = [el_, eh];
    if ($("#sm-rating").value) rule.rating = +$("#sm-rating").value;
    const keys = $("#sm-keys").value.split(/[,\s]+/).map(k => k.trim().toUpperCase()).filter(Boolean);
    if (keys.length) { rule.keys = keys; rule.harmonic = true; }
    if ($("#sm-days").value) rule.added_days = +$("#sm-days").value;
    if ($("#sm-text").value.trim()) rule.text = $("#sm-text").value.trim();
    const tags = $("#sm-tags").value.split(",").map(x => x.replace(/#/g, "").trim().toLowerCase()).filter(Boolean);
    if (tags.length) rule.tags = tags;
    return rule;
  }

  function formFromRule(rule) {
    rule = rule || {};
    $("#sm-name").value = rule.name && rule.name !== "Untitled" ? rule.name : "";
    $("#sm-bpm-lo").value = rule.bpm && rule.bpm[0] != null ? rule.bpm[0] : "";
    $("#sm-bpm-hi").value = rule.bpm && rule.bpm[1] != null ? rule.bpm[1] : "";
    $("#sm-en-lo").value = rule.energy && rule.energy[0] != null ? rule.energy[0] : "";
    $("#sm-en-hi").value = rule.energy && rule.energy[1] != null ? rule.energy[1] : "";
    $("#sm-rating").value = rule.rating || "";
    $("#sm-keys").value = (rule.keys || []).join(", ");
    $("#sm-days").value = rule.added_days || "";
    $("#sm-text").value = rule.text || "";
    $("#sm-tags").value = (rule.tags || []).join(", ");
  }

  function renderSmart(list) {
    if (list) smartCrates = list;
    const box = $("#smart-list");
    box.replaceChildren(...smartCrates.map((entry, i) => {
      const row = el("button", "smart-row" + (entry.tracks ? "" : " empty"));
      row.type = "button";
      if (window.YCFX) row.append(YCFX.folder((entry.ids || []).slice(0, 3).map(id => trackById(id)?.title).filter(Boolean)));
      row.append(el("b", null, entry.name),
                 el("span", "smart-says", entry.says),
                 el("span", "smart-count", `${entry.tracks} track${entry.tracks === 1 ? "" : "s"}`));
      // Clicking a crate shows what is in it, rather than opening the rule: the tracks are what
      // you came for, and the rule is one more click away.
      row.onclick = () => {
        const ids = new Set(entry.ids || []);
        crateFilterIds = crateFilterIds === entry ? null : entry;
        $("#crate-search").value = "";
        renderCrate();
        row.classList.toggle("on", crateFilterIds === entry);
        [...box.children].forEach(other => { if (other !== row) other.classList.remove("on"); });
      };
      const edit = el("span", "smart-edit-link", "edit");
      edit.onclick = (e) => { e.stopPropagation(); editing = i; formFromRule(entry.rule); sayRule(); disarmSmartDelete(); $("#sm-delete").hidden = false; $("#smart-edit").hidden = false; $("#sm-name").focus(); };
      row.append(edit);
      return row;
    }));
    $("#smart").classList.toggle("has-rules", smartCrates.length > 0);
  }

  async function sayRule() {
    // Say the rule back before it is saved, so a rule that does not mean what someone thought is
    // visible while they are still looking at it.
    const rule = ruleFromForm();
    const bits = [];
    if (rule.bpm) bits.push(`${rule.bpm[0] ?? "any"}-${rule.bpm[1] ?? "any"} BPM`);
    if (rule.rating) bits.push(`${rule.rating} stars or more`);
    if (rule.energy) bits.push(`energy ${rule.energy[0] ?? "any"}-${rule.energy[1] ?? "any"}`);
    if (rule.keys) bits.push(`mixes with ${rule.keys.join(", ")}`);
    if (rule.added_days) bits.push(`added in the last ${rule.added_days} days`);
    if (rule.text) bits.push(`"${rule.text}" in the name`);
    $("#sm-says").textContent = bits.length ? "Gathers: " + bits.join(", and ") + "." : "Gathers everything in your crate.";
  }

  $("#smart-new").onclick = () => { editing = -1; formFromRule({}); sayRule(); $("#sm-delete").hidden = true; $("#smart-edit").hidden = false; $("#sm-name").focus(); };
  $("#sm-cancel").onclick = () => { $("#smart-edit").hidden = true; editing = null; disarmSmartDelete(); };
  // Deleting a crate deletes a rule, not a track - but it is still two clicks, like every other delete
  // here, and it forgets being armed after a few seconds.
  let smartDeleteArmed = 0;
  function disarmSmartDelete() {
    clearTimeout(smartDeleteArmed);
    smartDeleteArmed = 0;
    const b = $("#sm-delete");
    b.classList.remove("arm");
    b.textContent = "Delete this crate";
  }
  $("#sm-delete").onclick = async () => {
    if (editing == null || editing < 0) return;
    const b = $("#sm-delete");
    if (!smartDeleteArmed) {
      b.classList.add("arm");
      b.textContent = "Sure? The tracks stay";
      smartDeleteArmed = setTimeout(disarmSmartDelete, 5000);
      return;
    }
    disarmSmartDelete();
    const gone = smartCrates[editing];
    const wasShowing = crateFilterIds === gone;
    renderSmart(await call("delete_smart_crate", editing));
    $("#smart-edit").hidden = true;
    editing = null;
    if (wasShowing) { crateFilterIds = null; renderCrate(); }
    refreshRekordboxSoon();
    toast(`"${(gone && gone.name) || "Crate"}" deleted. Its tracks are still in your crate.`);
  };
  $("#smart-edit").addEventListener("input", sayRule);
  $("#crate-clear-filters").onclick = clearCrateFilters;
  $("#crate-only-clear").onclick = () => { crateFilterIds = null; renderCrate(); };
  $("#smart-edit").addEventListener("submit", async (e) => {
    e.preventDefault();
    renderSmart(await call("save_smart_crate", ruleFromForm(), editing >= 0 ? editing : null));
    $("#smart-edit").hidden = true;
    editing = null;
    refreshRekordboxSoon();
    toast("Rule saved. It's a playlist in rekordbox too.");
  });

  // ── folders ────────────────────────────────────────────────────────────────────────────
  // Paste a folder of songs into the save folder, press Scan, and it stays a folder: a chip here, a
  // playlist in rekordbox, a subcrate in Serato. A crate of plain downloads has none, and then the
  // whole row stays out of the way.
  let folderPick = "";
  // Folders as one button that opens a searchable list, nested folders folded under their parents (glass redesign,
  // from a working DJ's crate: ~50 chips in a wall, "Crates / djcity / yoshi / DOMIN..." spelled out on each).
  // Picking a folder shows everything in it and in the folders inside it.
  let folderOpen = false, folderQuery = "";
  const folderOpenSet = new Set();
  function renderFolders() {
    const box = $("#crate-folders");
    const own = new Map();
    if (state.store === "crate") for (const t of state.crate.values()) if (t.folder) own.set(t.folder, (own.get(t.folder) || 0) + 1);
    if (!own.size) { box.hidden = true; box.replaceChildren(); folderPick = ""; return; }
    // the tree: every path, and every parent of one, as a node
    const nodes = new Map();
    const node = path => {
      if (!nodes.has(path)) {
        const n = { path, name: path.split("/").pop(), own: own.get(path) || 0, kids: [] };
        nodes.set(path, n);
        const up = path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "";
        if (up) node(up).kids.push(n);
      }
      return nodes.get(path);
    };
    for (const p of own.keys()) node(p);
    const total = n => n.own + n.kids.reduce((s, k) => s + total(k), 0);
    const roots = [...nodes.values()].filter(n => !n.path.includes("/"));
    const byName = (a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
    if (folderPick && !nodes.has(folderPick)) folderPick = "";
    const pickLabel = folderPick ? folderPick.split("/").join(" › ") : "All folders";
    const pickN = folderPick ? total(nodes.get(folderPick)) : state.crate.size;
    const head = el("button", "fpick" + (folderOpen ? " open" : ""));
    head.type = "button";
    head.setAttribute("aria-expanded", String(folderOpen));
    head.append(el("span", "fpick-ic", "▤"), el("span", "fpick-name", pickLabel), el("span", "fn", pickN.toLocaleString("en")),
      el("span", "fpick-more", `${nodes.size} folders ${folderOpen ? "▴" : "▾"}`));
    head.onclick = () => { folderOpen = !folderOpen; renderFolders(); if (folderOpen) setTimeout(() => $("#fq") && $("#fq").focus(), 30); };
    const parts = [head];
    if (folderPick) {
      const all = el("button", "btn-text fclear", "Show all folders");
      all.type = "button";
      all.onclick = () => { folderPick = ""; renderCrate(); };
      parts.push(all);
    }
    if (folderOpen) {
      const panel = el("div", "fpanel");
      const q = el("input", "fq"); q.id = "fq"; q.type = "search"; q.placeholder = "Find a folder"; q.value = folderQuery; q.setAttribute("aria-label", "Find a folder");
      q.oninput = () => { folderQuery = q.value; drawTree(); };
      const tree = el("div", "ftree"); tree.setAttribute("role", "tree");
      const drawTree = () => {
        const fq = folderQuery.trim().toLowerCase();
        const hit = n => !fq || n.path.toLowerCase().includes(fq) || n.kids.some(hit);
        const rows = [];
        const walk = (list, depth) => list.filter(hit).sort(byName).forEach(n => {
          const opened = !!fq || folderOpenSet.has(n.path);
          const r = el("div", "frow" + (folderPick === n.path ? " on" : ""));
          r.style.setProperty("--d", depth);
          r.setAttribute("role", "treeitem");
          const tw = el("button", "ftw", n.kids.length ? (opened ? "▾" : "▸") : "");
          tw.type = "button"; tw.tabIndex = -1; tw.disabled = !n.kids.length;
          tw.onclick = e => { e.stopPropagation(); folderOpenSet.has(n.path) ? folderOpenSet.delete(n.path) : folderOpenSet.add(n.path); drawTree(); };
          const name = el("button", "fname", n.name); name.type = "button"; name.title = n.path.split("/").join(" / ");
          name.onclick = () => { folderPick = folderPick === n.path ? "" : n.path; if (n.kids.length) folderOpenSet.add(n.path); renderCrate(); };
          r.append(tw, name, el("span", "fn", total(n).toLocaleString("en")));
          rows.push(r);
          if (n.kids.length && opened) walk(n.kids, depth + 1);
        });
        walk(roots, 0);
        tree.replaceChildren(...(rows.length ? rows : [el("p", "fnone", "No folder by that name.")]));
      };
      drawTree();
      panel.append(q, tree);
      parts.push(panel);
    }
    box.replaceChildren(...parts);
    box.hidden = false;
  }

  function filteredTracks() {
    const q = $("#crate-search").value.trim().toLowerCase();
    const lo = parseFloat($("#bpm-min").value), hi = parseFloat($("#bpm-max").value);
    const key = keySelect.value;
    const base = state.active && trackById(state.active);
    const tagOnly = q.startsWith("#") ? q.slice(1).trim() : "";
    let list = [...store().values()].filter(t => {
      if (tagOnly) { if (!(t.tags || []).includes(tagOnly)) return false; }
      else if (q && !`${t.title} ${t.artist} ${(t.tags || []).join(" ")} ${t.note || ""} ${nicheName(nicheKey(t), true)}`.toLowerCase().includes(q)) return false;
      if (folderPick && t.folder !== folderPick && !(t.folder || "").startsWith(folderPick + "/")) return false;   // a folder and the folders inside it
      if (!isNaN(lo) && !(t.bpm >= lo)) return false;
      if (!isNaN(hi) && !(t.bpm <= hi)) return false;
      if (key === "compat") return base ? t.id === base.id || relation(base.camelot, t.camelot) !== null : true;
      if (key && String(t.camelot || "").toUpperCase() !== key) return false;
      return true;
    });
    const sort = $("#crate-sort").value;
    const camKey = t => { const c = camelot(t.camelot); return c ? c.n * 2 + (c.l === "B" ? 1 : 0) : 99; };
    const by = {
      added: (a, b) => (b.added || 0) - (a.added || 0),
      bpm: (a, b) => (a.bpm || 999) - (b.bpm || 999),
      camelot: (a, b) => camKey(a) - camKey(b) || (a.bpm || 0) - (b.bpm || 0),
      title: (a, b) => String(a.title).localeCompare(String(b.title)),
      artist: (a, b) => String(a.artist).localeCompare(String(b.artist)),
    }[sort];
    return list.sort(by);
  }
  let homeRaf = 0;
  const renderHomeSoon = () => { if (!homeRaf) homeRaf = requestAnimationFrame(() => { homeRaf = 0; renderHome(); }); };

  function renderCrate() {
    $("#crate-skel")?.remove();                 // the loading rows (U3) give way to the real ones
    renderFolders();
    // A smart crate narrows the list the same way the search box does, so everything below - the
    // count, the empty state, dragging into rekordbox - keeps working without knowing about it.
    let rows = filteredTracks();
    if (crateFilterIds && state.store !== "requests") {
      const ids = new Set(crateFilterIds.ids || []);
      rows = rows.filter(t => ids.has(t.id));
    }
    if (wheelKey) {
      // relation() already knows the wheel: 0 is the key itself, 1 and 2 are the ones that mix.
      rows = rows.filter(t => {
        const cam = (t.camelot || "").toUpperCase();
        return cam === wheelKey || relation(wheelKey, cam) !== null;
      });
    }
    flipRows($("#crate-rows"), rows);
    const requests = state.store === "requests";
    const total = store().size;
    $("#crate-empty").hidden = requests || total > 0;
    $("#requests-empty").hidden = !requests || total > 0;
    // Tracks exist, the filters just left none of them: a blank list read as an empty crate.
    $("#crate-nomatch").hidden = !(total > 0 && rows.length === 0);
    $("#crate-sum").textContent = total ? (rows.length === total ? `${total} track${total === 1 ? "" : "s"}` : `${rows.length} of ${total}`) : "";
    $("#crate-sum").title = crateFilterIds && !crateFilterIds.own ? `Showing the smart crate "${crateFilterIds.name}"` : "";
    const only = !!(crateFilterIds && crateFilterIds.own && !requests);
    $("#crate-only").hidden = !only;
    if (only) $("#crate-only-name").textContent = `Showing: ${crateFilterIds.name.toLowerCase()} · ${rows.length}`;
    paintCrateCount();
    $("#tab-crate-n").textContent = state.crate.size || "";
    $("#tab-req-n").textContent = state.requests.size || "";
    $("#crate-where").textContent = "‎" + shortPath(requests ? state.requestsDir : state.settings.output_dir || "");
    $("#crate-where").title = requests ? state.requestsDir : state.settings.output_dir || "";
    $("#scan-pick").hidden = requests;                        // scanning fills the crate, never the requests
    if (requests) { $("#scan-menu").hidden = true; $("#crate-scan").setAttribute("aria-expanded", "false"); }
    $("#crate-clean").hidden = requests;
    const clear = $("#requests-clear");
    clear.hidden = !requests || !state.requests.size;
    if (clear.hidden) disarmClear();
    const wipe = $("#requests-delete");
    wipe.hidden = clear.hidden;
    if (wipe.hidden) disarmWipe();
    renderHomeSoon();
    if (pagesReady) pagesSoon();
    measureSections();
    syncEdges($("#crate-list"));
  }
  function paintCrateCount() {
    const n = state.crate.size, node = $("#crate-count");
    const word = ` track${n === 1 ? "" : "s"}`;
    if (tickCount && countShown != null && n > countShown) {
      const num = el("span", null, String(countShown));
      node.replaceChildren(num, word);
      countTo(num, countShown, n);
    } else {
      node.textContent = n + word;
    }
    tickCount = false;
    countShown = n;
  }
  function syncCrate(list) {
    if (!Array.isArray(list)) return;
    state.crate = new Map(list.map(t => [t.id, t]));
    renderCrate();
    if (state.active && !trackById(state.active)) selectTrack(null);
  }
  function syncRequests(list) {
    if (!Array.isArray(list)) return;
    state.requests = new Map(list.map(t => [t.id, t]));
    renderCrate();
    if (state.active && !trackById(state.active)) selectTrack(null);
  }
  function syncLibrary(r) {
    if (!r) return;
    if (r.crate) syncCrate(r.crate);
    if (r.requests) syncRequests(r.requests);
  }
  // Clearing the whole list is one click to arm and one to confirm - no dialog, and it forgets
  // after a few seconds if you walk away.
  let clearArmed = 0;
  function disarmClear() {
    clearTimeout(clearArmed);
    clearArmed = 0;
    const b = $("#requests-clear");
    b.classList.remove("arm");
    b.textContent = "Clear all";
  }
  $("#requests-clear").onclick = async () => {
    const b = $("#requests-clear");
    const n = state.requests.size;
    if (!n) return;
    if (!clearArmed) {
      disarmWipe();
      b.classList.add("arm");
      b.textContent = `Clear ${n} request${n === 1 ? "" : "s"}?`;
      clearArmed = setTimeout(disarmClear, 5000);
      return;
    }
    disarmClear();
    const r = await call("requests_clear");
    if (!r.ok) return toast(r.error || "Couldn't clear the list", true);
    syncLibrary(r);
    refreshRekordboxSoon();
    toast(`Cleared ${r.removed} request${r.removed === 1 ? "" : "s"}. The files are still in your Song Requests folder.`);
  };

  // Delete all: the same two clicks, but this one sends every request file to the Recycle Bin. The
  // crate deliberately has no version of this - there you delete one row at a time.
  let wipeArmed = 0;
  function disarmWipe() {
    clearTimeout(wipeArmed);
    wipeArmed = 0;
    const b = $("#requests-delete");
    b.classList.remove("arm");
    b.textContent = "Delete all";
  }
  $("#requests-delete").onclick = async () => {
    const b = $("#requests-delete");
    const n = state.requests.size;
    if (!n) return;
    if (!wipeArmed) {
      disarmClear();
      b.classList.add("arm");
      b.textContent = `Delete ${n} file${n === 1 ? "" : "s"}?`;
      wipeArmed = setTimeout(disarmWipe, 5000);
      return;
    }
    disarmWipe();
    const r = await call("requests_clear", true);
    if (!r.ok) return toast(r.error || "Couldn't delete the requests", true);
    syncLibrary(r);
    refreshRekordboxSoon();
    if (r.failed) toast(`${r.deleted} sent to your ${trashName()}; ${r.failed} couldn't be deleted and are still on disk.`, true);
    else toast(`${r.deleted} request${r.deleted === 1 ? "" : "s"} deleted. They're kept for 30 days - Settings, What changed puts them back.`);
  };

  document.querySelectorAll("#crate-tabs button").forEach(b => (b.onclick = () => {
    state.store = b.dataset.store;
    document.querySelectorAll("#crate-tabs button").forEach(x => x.classList.toggle("on", x === b));
    renderCrate();
  }));
  let mixesSeq = 0;
  // Arrow keys move through the crate's own list and nothing else. scrollIntoView scrolls every
  // scrollable ancestor, so each press dragged the whole page along with the selection. This moves
  // the list only, and only when the row reaches an edge - under the sticky header, not behind it.
  function keepInList(row) {
    const list = $("#crate-list");
    if (!list || !list.contains(row)) return;
    const head = list.querySelector(".crate-head");
    const box = list.getBoundingClientRect(), r = row.getBoundingClientRect();
    const top = box.top + (head ? head.offsetHeight : 0);
    if (r.top < top) list.scrollTop -= top - r.top;
    else if (r.bottom > box.bottom) list.scrollTop += r.bottom - box.bottom;
  }

  // scroll: true takes you to the track (the page moves, as "Show in crate" wants); "list" keeps it
  // in view inside the crate and leaves the page where it is.
  async function selectTrack(id, scroll) {
    if (id && window.YCMore) YCMore.mark("mixes");
    state.active = id;
    document.querySelectorAll(".crow.active").forEach(n => n.classList.remove("active"));
    const base = id && trackById(id);
    $("#mixes-empty").hidden = !!base;
    $("#mixes-body").hidden = !base;
    if (!base) return;
    if (keySelect.value === "compat") renderCrate();
    // The row may not be drawn (only the ones in view are): asked to show it, the list goes to it first.
    let row = document.getElementById("track-" + id);
    if (!row && scroll && crateIndex.has(id)) row = showRow(id, scroll === "list" ? "nearest" : "center");
    if (row) {
      row.classList.add("active");
      if (scroll === "list") keepInList(row);
      else if (scroll) { showRow(id, "center"); window.YCS.into($("#crate-list"), "center"); }
    } else if (scroll === true) {
      $("#crate-search").value = ""; $("#bpm-min").value = ""; $("#bpm-max").value = ""; keySelect.value = ""; folderPick = "";
      renderCrate();
      const again = showRow(id, "center");
      if (again) { again.classList.add("active"); window.YCS.into($("#crate-list"), "center"); }
    }
    const b = $("#mix-base");
    b.replaceChildren();
    const cam = el("span", "cam", base.camelot || "—");
    cam.style.setProperty("--cam", camColor(base.camelot));
    const cover = el("div", "mix-cover");
    cover.append(keptCover("mix:" + base.id, base, "mcart"), cam);
    const text = el("div");
    text.style.minWidth = "0";
    // Tempo and key moved to the display below, where they can be read from the booth.
    text.append(el("b", null, base.title), el("small", null, base.artist || ""));
    b.append(cover, text, readout(base));
    const seq = ++mixesSeq;
    // Stepping through the crate with the arrow keys asks once, where you stop - not once for every row passed.
    await new Promise(r => setTimeout(r, 120));
    if (seq !== mixesSeq) return;
    const matches = await call("crate_mixes", id);
    if (seq !== mixesSeq) return;
    drawWheel($("#wheel"), base.camelot, matches);
    const mixCount = b.querySelector(".lcd-mixes .val");
    if (mixCount) {
      if (window.YCFX) YCFX.roll(mixCount, readoutMixes, matches.length); else countTo(mixCount, 0, matches.length);
      readoutMixes = matches.length;
    }
    $("#mix-none").hidden = matches.length > 0;
    $("#mix-list").replaceChildren(...matches.map(m => {
      const li = el("li", "mix");
      const c = el("span", "cam", m.track.camelot || "—");
      c.style.setProperty("--cam", camColor(m.track.camelot));
      const t = el("div", "mt");
      t.append(el("b", null, m.track.title), el("small", null, m.key.label + (m.track.artist ? ` · ${m.track.artist}` : "")));
      const pct = m.tempo.pct;
      const tempo = el("span", "mtempo" + (Math.abs(pct) <= 2 ? " easy" : ""),
        `${m.track.bpm ? Math.round(m.track.bpm) : "—"} BPM · ${pct === 0 ? "±0%" : (pct > 0 ? "+" : "") + pct + "%"}${m.tempo.half_double ? " ½×2" : ""}`);
      tempo.title = `Move this track's tempo ${pct > 0 ? "up" : "down"} ${Math.abs(pct)}% to match${m.tempo.half_double ? " (half/double time)" : ""}`;
      li.append(c, t, tempo);
      makeDraggable(li, m.track.path, () => selectTrack(m.track.id, true));
      return li;
    }));
  }
  // Scan asks which: Scan folders (the save folder and the library folders you watch, for new songs - and a fresh
  // try at every song with no tempo and key yet), or Check my crate (no folders: every track you have gets whatever
  // it's missing - tempo, key, waveform, cover, tags and genre).
  const unreadWords = n => `${n} song${n === 1 ? "" : "s"} that ${n === 1 ? "hasn't" : "haven't"} been read for tempo and key yet`;
  const scanBtn = $("#crate-scan"), scanMenu = $("#scan-menu");
  const scanItems = () => [...scanMenu.querySelectorAll("[role=menuitem]")];
  function scanMenuOpen(open, focusFirst) {
    scanMenu.hidden = !open;
    scanBtn.setAttribute("aria-expanded", String(open));
    if (open && focusFirst) scanItems()[0].focus();
  }
  scanBtn.onclick = () => scanMenuOpen(scanMenu.hidden, true);
  scanBtn.addEventListener("keydown", e => { if (e.key === "ArrowDown") { e.preventDefault(); scanMenuOpen(true, true); } });
  scanMenu.addEventListener("keydown", e => {
    const items = scanItems(), at = items.indexOf(document.activeElement);
    if (e.key === "Escape") { e.preventDefault(); scanMenuOpen(false); scanBtn.focus(); }
    else if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); items[(at + (e.key === "ArrowDown" ? 1 : items.length - 1)) % items.length].focus(); }
    else if (e.key === "Tab") scanMenuOpen(false);
  });
  document.addEventListener("pointerdown", e => { if (!scanMenu.hidden && !$("#scan-pick").contains(e.target)) scanMenuOpen(false); });
  scanMenu.addEventListener("click", e => {
    const item = e.target.closest("[data-scan]");
    if (!item) return;
    scanMenuOpen(false);
    (item.dataset.scan === "check" ? checkCrate : scanFolders)();
  });
  async function scanFolders() {
    const r = await call("scan_folders");
    if (!r.ok) return toast(r.error, true);
    const also = [r.library && `your ${r.folders === 1 ? "library folder" : r.folders ? `${r.folders} library folders` : "library"}`,
                  r.reread && `reading ${unreadWords(r.reread)}`].filter(Boolean);
    if (r.running) toast("A scan is already running.");
    else if (!r.started && r.error) toast(r.error + (also.length ? ` Looking in ${also.join(", and ")} instead.` : ""), false, 8000);
    else if (also.length) toast(`Looking through ${r.started ? "the save folder and " : ""}${also.join(", and ")}.`, false, 7000);
  }
  async function checkCrate() {
    const r = await call("crate_check");
    if (!r.ok) return toast(r.error, true);
    showScan({ kind: "check", phase: "tags", done: 0, total: r.tracks, current: "", eta: null });
  }
  $("#scan-cancel").onclick = async e => {
    e.currentTarget.disabled = true;
    e.currentTarget.textContent = "Stopping…";
    await call("scan_cancel");
  };
  // How long is left, said the way you'd say it: seconds under a minute and a half, minutes after, hours if it must.
  const leftWords = s => (s >= 3600 ? `${Math.floor(s / 3600)} h ${Math.round((s % 3600) / 60)} min`
    : s >= 90 ? `${Math.round(s / 60)} min` : `${Math.max(1, Math.round(s))} s`);
  let scanClock = null;
  // How Check my crate went, in one line: "Checked 412 tracks · 37 genres filled · 5 still unknown", then whatever
  // else it found to do.
  function checkWords(s) {
    if (s.failed) return "Checking your crate stopped with an error. Nothing was lost - press Scan to try again.";
    const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
    const parts = [`${s.cancelled ? "Stopped after" : "Checked"} ${plural(s.checked, "track", "tracks")}`,
                   `${plural(s.filled, "genre", "genres")} filled`, `${s.unknown} still unknown`];
    if (s.tags) parts.push(`tags filled on ${plural(s.tags, "track", "tracks")}`);
    if (s.reading) parts.push(`${plural(s.reading, "song", "songs")} to read for tempo and key next`);
    const redo = (s.waves || 0) + (s.covers || 0);
    if (redo) parts.push(`${plural(redo, "waveform or cover", "waveforms and covers")} to try again`);
    let line = parts.join(" · ") + ".";
    if (s.offline) line += ` Apple's catalogue couldn't be reached, so ${plural(s.offline, "song is", "songs are")} left to ask later.`;
    return line;
  }
  $("#crate-open").onclick = () => call("open_folder", state.store);
  function showScan(s) {
    const bar = $("#scan-bar");
    scanning = !!(s && !s.finished);                   // a scan lands dozens at once: no pulse for those
    bar.classList.toggle("fx-busy", scanning);
    window.YCFX?.sweep($("#crate-list"), scanning);
    const G = window.gsap, fill = $("#scan-fill"), time = $("#scan-time"), stop = $("#scan-cancel");
    if (!s || s.finished) {
      bar.hidden = true;
      if (scanClock) { scanClock.kill(); scanClock = null; }
      if (!s) return;
      if (s.kind === "check") return toast(checkWords(s), !!s.failed, 10000);
      const n = s.kind === "read" ? s.total : (s.added ?? s.total), songs = `${n} song${n === 1 ? "" : "s"}`;
      if (s.kind === "read") {
        if (s.cancelled) toast(`Stopped. ${s.left} song${s.left === 1 ? "" : "s"} still to read - press Scan to carry on.`, false, 8000);
        else if (n) toast(`${songs} read for tempo and key.`);
      } else if (s.cancelled) toast(`Scan stopped: ${songs} added to the crate, the rest left for next time.`, false, 8000);
      else toast(n ? `Scan finished: ${n} track${n === 1 ? "" : "s"} added to the crate` : "Scan finished: nothing new in the save folder");
      return;
    }
    bar.hidden = false;
    stop.disabled = false; stop.textContent = "Cancel";
    const where = s.folder || (s.kind === "read" ? "your crate" : "the save folder");
    $("#scan-text").textContent = s.kind === "check"
      ? `${s.phase === "ask" ? "Asking Apple's catalogue for genres" : "Checking your crate"} · ${Math.min(s.done + 1, s.total)} of ${s.total}${s.current ? ` · ${s.current}` : ""}`
      : s.total ? `Reading ${where} · ${s.done + 1} of ${s.total} · ${s.current}` : "Looking for audio files…";
    // The bar eases to where it is (GSAP), and the time left counts down between the app's updates.
    const part = s.total ? s.done / s.total : 0;
    if (G && !REDUCED) { fill.style.transition = "none"; G.to(fill, { scaleX: part, duration: 0.5, ease: "power2.out", overwrite: true }); }
    else fill.style.transform = `scaleX(${part})`;
    if (scanClock) { scanClock.kill(); scanClock = null; }
    const more = s.kind === "read" && s.folders_left > 1 && s.eta_all ? ` in this folder · ${leftWords(s.eta_all)} in all` : "";
    const say = left => { const text = `${leftWords(left)} left${more}`; if (time.textContent !== text) time.textContent = text; };
    if (s.eta == null) time.textContent = s.total ? "Working out how long…" : "";
    else if (G) { const clock = { left: s.eta }; say(clock.left); scanClock = G.to(clock, { left: 0, duration: Math.max(1, s.eta), ease: "none", onUpdate: () => say(clock.left) }); }
    else say(s.eta);
  }

  // ── QR codes ───────────────────────────────────────────────────────────
  // Every square of a code is drawn the same whole number of screen pixels wide. Scaled to fit its box,
  // a dense code on a Windows screen at 100% drew some squares two pixels wide and some three, and phones
  // couldn't read it; a Mac's Retina screen has twice the pixels and hid the problem. Any code also opens
  // full screen when asked: Full screen under each one, or a click on the code.
  // Where it sits: at 100% or 200% the browser puts an SVG on whole pixels by itself, and nudging it
  // with a transform undoes that and blends every edge. At 125% or 150% it doesn't, so there - and only
  // there - the code is nudged onto the grid, and again once whatever was moving has stopped.
  let qrSettle = 0;
  function fitQR(holder, settled) {
    const svg = holder && holder.querySelector("svg");
    if (!svg) return;
    const n = Number((svg.getAttribute("viewBox") || "").trim().split(/[\s,]+/)[2]);
    const cs = getComputedStyle(holder);
    const avail = Math.min(holder.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight),
                           holder.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom));
    if (!n || !(avail > 0)) return;                         // hidden for now: fitted when it shows
    const dpr = window.devicePixelRatio || 1;
    const px = Math.max(1, Math.floor(avail * dpr / n));   // screen pixels per square
    svg.style.width = svg.style.height = `${px * n / dpr}px`;
    svg.style.transform = "";
    if (!(dpr % 1)) return;
    const r = svg.getBoundingClientRect();
    const fx = (Math.round(r.left * dpr) - r.left * dpr) / dpr, fy = (Math.round(r.top * dpr) - r.top * dpr) / dpr;
    if (fx || fy) svg.style.transform = `translate(${fx}px, ${fy}px)`;
    if (!settled) { clearTimeout(qrSettle); qrSettle = setTimeout(() => fitAllQR(), 1000); }
  }
  const fitAllQR = () => ["#remote-qr", "#booth-qr", "#alerts-qr", "#bv-qr-img", "#qr-big-code"].forEach(s => fitQR($(s), true));
  let qrFrame = 0;
  const fitAllSoon = () => { if (!qrFrame) qrFrame = requestAnimationFrame(() => { qrFrame = 0; fitAllQR(); }); };
  addEventListener("resize", fitAllSoon);                 // also fires moving to a screen with other scaling
  // Scaled by a fraction, a page scrolls in part-pixels too, which moves a code off the grid again.
  addEventListener("scroll", () => { if ((window.devicePixelRatio || 1) % 1) fitAllSoon(); }, { capture: true, passive: true });
  $("#boothview").addEventListener("animationend", e => { if (e.target === $("#boothview")) fitAllQR(); });

  let bigQR = null;                                       // which code is up big: "remote", "booth" or "pair"
  function showBigQR(kind, holder, title, sub) {
    if (!holder || !holder.querySelector("svg")) return;
    bigQR = kind;
    $("#qr-big-code").innerHTML = holder.innerHTML;      // the same SVG, made by segno in remote.py from our own URL
    $("#qr-big-title").textContent = title;
    $("#qr-big-sub").textContent = sub || "";
    $("#qr-big-sub").hidden = !sub;
    $("#qr-big").hidden = false;
    requestAnimationFrame(() => fitQR($("#qr-big-code")));
  }
  function hideBigQR(kind) {
    if (kind && bigQR !== kind) return;
    bigQR = null;
    $("#qr-big").hidden = true;
    $("#qr-big-code").replaceChildren();
  }
  function showBigPair() {
    const p = alertsInfo && alertsInfo.pairing;
    if (p) showBigQR("pair", $("#alerts-qr"), "Pair a phone",
                     `Scan it with the phone's camera, on the same Wi-Fi - or type ${p.code} into DJ Alerts.`);
  }
  $("#qr-big").addEventListener("click", e => { if (e.target === $("#qr-big") || e.target.closest("#qr-big-close")) hideBigQR(); });
  addEventListener("keydown", e => {
    if (e.key === "Escape" && !$("#qr-big").hidden) { e.preventDefault(); e.stopImmediatePropagation(); hideBigQR(); }
  }, true);
  const openBig = {
    remote: () => showBigQR("remote", $("#remote-qr"), "Your phone · private",
      "Scan it with your own phone, on the same Wi-Fi as this computer."),
    booth: () => showBigQR("booth", $("#booth-qr"), "Booth link · public",
      "Anyone who scans this can ask you for a song. Nothing downloads until you approve it."),
    view: () => showBigQR("booth", $("#bv-qr-img"), "Scan to ask for a song", "Point your phone's camera at the code."),
    pair: showBigPair,
  };
  [["#remote-qr", "remote"], ["#booth-qr", "booth"], ["#bv-qr-img", "view"], ["#alerts-qr", "pair"]].forEach(([s, kind]) => {
    $(s).addEventListener("click", openBig[kind]);
    $(s).title = "Click for full screen";
  });
  document.querySelectorAll(".qr-max").forEach(b => b.addEventListener("click", openBig[b.dataset.qr]));

  // ── phone remote ───────────────────────────────────────────────────────
  let remoteInfo = null, remoteWhere = 0;
  function renderRemote() {
    const on = !!state.settings.remote_enabled;
    $("#remote-on").checked = on;
    $("#phone-state").textContent = on ? (remoteInfo && remoteInfo.links && remoteInfo.links.length ? "On" : "Starting") : "Off";
    $("#phone-state").classList.toggle("on", on);
    const links = (on && remoteInfo && remoteInfo.links) || [];
    const err = on && remoteInfo && remoteInfo.error;
    $("#remote-err").hidden = !err;
    $("#remote-err").textContent = err || "";
    $("#remote-fw").hidden = !(on && state.platform === "windows");
    // The code, or a placeholder the same size: the row keeps its shape either way.
    $("#remote-link").hidden = !links.length;
    $("#remote-qr").hidden = !links.length;
    $("#remote-off").hidden = !!links.length;
    if (!links.length) {
      $("#remote-off").querySelector("span").textContent = on ? "Starting…" : "Off";
      return;
    }
    remoteWhere = Math.min(remoteWhere, links.length - 1);
    const link = links[remoteWhere];
    $("#remote-qr").innerHTML = link.qr || "";        // SVG made by segno in remote.py from our own URL
    fitQR($("#remote-qr"));
    $("#remote-addr").textContent = link.address;
    $("#remote-addr").title = link.label;
    const where = $("#remote-where");
    where.hidden = links.length < 2;
    where.replaceChildren(...links.map((l, i) => {
      const b = el("button", i === remoteWhere ? "on" : null, l.label);
      b.type = "button";
      b.onclick = () => { remoteWhere = i; renderRemote(); };
      return b;
    }));
  }
  async function refreshRemote() {
    remoteInfo = state.settings.remote_enabled ? await call("remote_info") : null;
    renderRemote();
  }
  $("#remote-on").addEventListener("change", async e => {
    state.settings = await call("set_setting", "remote_enabled", e.target.checked);
    await refreshRemote();
  });
  $("#remote-reset").onclick = async () => {
    remoteInfo = await call("remote_new_key");
    renderRemote();
    toast("Phones unlinked. Scan the new code to link one again.");
  };

  // ── rekordbox ─────────────────────────────────────────────────────────
  function renderRekordbox() {
    const i = rbInfo;
    if (!i) return;
    $("#rb-on").checked = i.enabled;
    const p = $("#rb-path");
    p.textContent = "\u200e" + i.path;
    p.title = i.path;
    const st = $("#rb-status");
    st.className = "rb-status " + (!i.enabled ? "off" : i.error ? "err" : "on");
    st.replaceChildren();
    if (!i.enabled) st.append(el("span", null, "Off · rekordbox's copy stops updating"));
    else if (i.error) st.append(el("span", null, `Couldn't write the file: ${i.error}`));
    else {
      st.append(el("span", "dot live"), el("span", null, `In sync · ${i.tracks} track${i.tracks === 1 ? "" : "s"}${i.phone ? ` · ${i.phone} from phone` : ""}`));
      if (i.written) st.append(el("span", "rb-when", `updated ${ago(i.written)}`));
    }
  }
  async function refreshRekordbox() {
    rbInfo = await call("rekordbox_info");
    renderRekordbox();
    renderHomeSoon();
  }
  const refreshRekordboxSoon = () => {
    clearTimeout(rbTimer);
    rbTimer = setTimeout(() => { refreshRekordbox().catch(() => {}); refreshSerato().catch(() => {}); }, 2600);
  };
  $("#rb-on").addEventListener("change", async e => {
    state.settings = await call("set_setting", "rekordbox_enabled", e.target.checked);
    await refreshRekordbox();
  });
  $("#rb-show").onclick = () => call("rekordbox_reveal");
  $("#rb-copy").onclick = async () => {
    if (!rbInfo) return;
    try { await navigator.clipboard.writeText(rbInfo.path); toast("Path copied. Paste it into rekordbox's file box."); }
    catch (err) { toast("Couldn't copy. Select the path and copy it instead.", true); }
  };

  // ── you already have this one ──────────────────────────────────────────
  // YouTube never returns the same title twice, so a crate quietly collects the same track under
  // three names. The backend matches on the words rather than the string; this just says so.
  async function flagDuplicate(info) {
    if (!info || info.collection || info.store) return;   // the shop edition marks each result itself
    const cand = info.candidates && info.candidates[state.pick];
    const title = (info.source === "songs" && cand ? cand.title : info.title) || "";
    const artist = (info.source === "songs" && cand ? cand.artist : info.artist) || "";
    if (!title) return;
    let have = null;
    try { have = await call("already_have", title, artist); } catch (e) { return; }
    if (!have || state.preview !== info) return;
    const note = el("div", "dupe");
    const when = have.added ? new Date(have.added * 1000).toLocaleDateString(undefined,
                   { day: "numeric", month: "short" }) : "";
    note.append(el("b", null, "Already in your crate"),
                el("span", null, `${have.title}${have.artist ? " \u00b7 " + have.artist : ""}${when ? " \u00b7 added " + when : ""}`));
    previewBody.prepend(note);
  }

  // ── before you go ──────────────────────────────────────────────────────────────────
  // Every one of these was already knowable; none of them was ever asked all at once, at home,
  // with time to do something about the answer. The booth link check opens a real link and fetches
  // it from the public internet, which is slow and is the whole point.
  const PF_WORD = { ok: "ready", warn: "worth a look", fail: "needs fixing", off: "off" };
  // Where each check is fixed. ffmpeg and the internet have nowhere in the app to send you.
  const PF_FIX = { licence: "settings:activation", folder: "settings:general", crate: "crate", phone: "phone",
                   booth: "phone", rekordbox: "djsoft", serato: "djsoft", health: "crate" };
  // The crate narrowed to a given set of tracks, the way a smart crate narrows it.
  function showOnly(ids, name) {
    state.store = "crate";
    document.querySelectorAll("#crate-tabs button").forEach(x => x.classList.toggle("on", x.dataset.store === "crate"));
    document.querySelectorAll("#smart-list .smart-row.on").forEach(r => r.classList.remove("on"));
    crateFilterIds = { name, ids, own: true };
    renderCrate();
    goToSection("crate");
  }
  function renderPreflight(res) {
    const list = $("#pf-list");
    list.replaceChildren(...res.checks.map(c => {
      const row = el("div", "pf-row " + c.state);
      const detail = el("span", "pf-detail", c.detail);
      if ((c.state === "warn" || c.state === "fail") && PF_FIX[c.key]) {
        const fix = el("button", "btn-text pf-fix", "Fix it →");
        fix.type = "button";
        fix.onclick = () => (c.key === "health" && c.ids && c.ids.length
          ? showOnly(c.ids, "Tracks that need attention") : goToSection(PF_FIX[c.key]));
        detail.append(" ", fix);
      }
      row.append(el("span", "pf-dot"), el("b", null, c.title), detail,
                 el("span", "pf-state", PF_WORD[c.state] || c.state));
      return row;
    }));
    list.hidden = false;
    const bad = res.checks.filter(c => c.state === "fail");
    const warn = res.checks.filter(c => c.state === "warn");
    // The line that was telling you what the button costs now tells you what it found. It is the
    // same row of pixels either way, so the space is only ever spent on an answer.
    const sub = $("#pf-sub");
    sub.textContent = res.worst === "ok"
      ? `All good — you're ready. Checked in ${res.seconds} seconds.`
      : res.worst === "warn"
      ? `${warn.length} thing${warn.length === 1 ? "" : "s"} worth a look before you leave.`
      : `${bad.length} thing${bad.length === 1 ? "" : "s"} to fix before tonight.`;
    sub.className = "pf-hint " + res.worst;

    // Everything passed: fold it up, because there is nothing to act on. Anything wrong stays open.
    const card = $("#preflight");
    const toggle = $("#pf-toggle");
    toggle.hidden = false;
    const fold = (shut) => {
      card.classList.toggle("shut", shut);
      toggle.textContent = shut ? "show the checks" : "hide the checks";
      toggle.title = shut ? "Show all ten checks" : "Fold the checks away";
    };
    fold(res.worst === "ok");
    toggle.onclick = () => fold(!card.classList.contains("shut"));
  }

  $("#pf-run").onclick = async () => {
    if (window.YCMore) YCMore.mark("ready");
    const btn = $("#pf-run");
    if (btn.disabled) return;
    btn.disabled = true;
    btn.classList.add("working");
    btn.textContent = "Checking…";
    $("#pf-list").hidden = true;
    $("#preflight").classList.remove("shut");
    let answered = false;
    try {
      renderPreflight(await call("preflight"));
      answered = true;
    } catch (err) {
      toast("Couldn't finish the checks.", true);
    } finally {
      btn.disabled = false;
      btn.classList.remove("working");
      // Once the line above is carrying a verdict, the button is offering a second opinion.
      btn.textContent = answered ? "Check again" : "Check I’m ready";
      $("#preflight").classList.remove("running");
      const pill = document.querySelector('#dash-actions [data-act="ready"]');
      if (pill) pill.classList.remove("busy");
    }
  };

  // ── booth mode ───────────────────────────────────────────────────────────────────────
  // The public link. Everything it brings in is held, so the only state worth showing is: is it up,
  // what is the code, and how many people are waiting on an answer.
  let boothInfo = null;
  function renderBooth() {
    const i = boothInfo;
    const live = !!(i && i.on && i.link);
    $("#booth-on").checked = !!(i && i.on);
    $("#booth-linkbox").hidden = !live;
    $("#booth-qr").hidden = !live;
    $("#booth-live").hidden = !live;
    $("#booth-off").hidden = live;
    $("#booth-off").querySelector("span").textContent = i && i.on ? "Opening…" : "Off";
    $("#booth-off").classList.toggle("working", !!(i && i.on && !i.link));
    // The error shows while it's off (it couldn't start) and while it's on but unreachable (it
    // started, and goes nowhere) - the second one is the case that used to hand out a dead QR.
    // An error is why it wouldn't start. A warning is that it started and isn't answering - the code
    // is still on screen in that case, because the check can be wrong and losing the link is worse.
    const err = $("#booth-err");
    const message = (i && (i.error || i.warning)) || "";
    err.hidden = !message;
    err.textContent = message;
    err.classList.toggle("warn", !!(i && !i.error && i.warning));
    if (!i || !i.on || !i.link) return;
    const qr = $("#booth-qr");
    if (qr.dataset.link !== i.link) { qr.dataset.link = i.link; qr.innerHTML = i.qr || ""; }
    fitQR(qr);
    // The whole link has to be on screen - the code after the # is part of it, and a link read off the
    // screen without it opens nothing. So: the address in full, then the code beneath it, dimmed, both
    // selectable. Copy link takes the lot.
    const a = $("#booth-addr");
    const [addr, code] = [i.link.split("#")[0], i.link.split("#k=")[1] || ""];
    a.replaceChildren(el("span", "u-addr", "‎" + addr.replace(/^https?:\/\//, "")),
                      el("span", "u-code", "‎#k=" + code));
    a.title = i.link;
  }
  // While the link is open, keep asking: a tunnel can stop answering at any moment, and the person
  // holding the QR code is the last to find out.
  let boothTimer = 0;
  function watchBooth(on) {
    clearInterval(boothTimer);
    boothTimer = on ? setInterval(() => refreshBooth().catch(() => {}), 20000) : 0;
  }
  async function refreshBooth() {
    boothInfo = await call("booth_info");
    watchBooth(!!(boothInfo && boothInfo.on));
    if (state.settings) applyWall(state.settings.wallpaper);   // the link opening or closing dims or restores the smoke
    paintDashBooth();
    renderBooth();
    renderBoothBanner();
  }
  function renderBoothBanner() {
    // The app should never be quietly reachable from the internet. While the link is up it says so,
    // everywhere, with the way to close it one click away.
    document.documentElement.classList.toggle("booth-public", !!(boothInfo && boothInfo.on));
    const n = boothInfo && boothInfo.held || 0;
    const pill = $("#home-held");
    if (pill) {
      pill.hidden = !n;
      pill.textContent = `${n} request${n === 1 ? "" : "s"} waiting on you`;
    }
  }
  $("#booth-on").addEventListener("change", async e => {
    const on = e.target.checked;
    e.target.disabled = true;
    if (on) {
      toast("Opening the public link…");
      $("#booth-off").querySelector("span").textContent = "Opening…";
      $("#booth-off").classList.add("working");   // lit while it is proved, which takes a while
    }
    state.settings = await call("set_setting", "booth_mode", on);
    await refreshBooth();
    e.target.disabled = false;
    if (on && !(boothInfo && boothInfo.on)) toast(boothInfo && boothInfo.error || "Couldn't open the public link.", true);
    else if (on) toast("Public link open. Every request it brings in waits for you.");
    else toast("Public link closed. The old code no longer works.");
  });
  $("#booth-copy").onclick = async () => {
    if (!boothInfo || !boothInfo.link) return;
    try { await navigator.clipboard.writeText(boothInfo.link); toast("Link copied - anyone you send it to can request a song."); }
    catch (err) { toast("Couldn't copy it.", true); }
  };
  $("#booth-reset").onclick = async () => {
    boothInfo = await call("booth_new_key");
    renderBooth(); renderBoothBanner();
    toast("New code. Everyone on the old link has been cut off.");
  };
  $("#booth-close").onclick = async () => {
    state.settings = await call("set_setting", "booth_mode", false);
    await refreshBooth();
    toast("Public link closed.");
  };

  // ── request alerts ─────────────────────────────────────────────────────────────────────
  // Your own phone, paired with a code that works once, for ten minutes. After that it hears about
  // every request the booth link brings in, wherever it is, and can answer it.
  let alertsInfo = null, alertsTimer = 0;
  function renderAlerts() {
    const i = alertsInfo || { phones: [], pairing: null };
    const p = i.pairing;
    const qr = $("#alerts-qr");
    qr.hidden = !p;
    $("#alerts-off").hidden = !!p;
    if (p && qr.dataset.url !== p.url) { qr.dataset.url = p.url; qr.innerHTML = p.qr || ""; }   // SVG made by segno from our own URL
    if (p) fitQR(qr);
    if (!p) { qr.dataset.url = ""; hideBigQR("pair"); }  // ran out, cancelled, or a phone paired
    $("#alerts-off").querySelector("span").textContent = i.phones.length ? `${i.phones.length} paired` : "No code";
    $("#alerts-pair").textContent = p ? "Cancel" : i.phones.length ? "Pair another" : "Pair a phone";
    // The same code as the QR, to type: DJ Alerts already on an iPhone's Home Screen can't be handed a new
    // QR, but it can be given this.
    $("#alerts-code").hidden = !p;
    if (p) {
      $("#alerts-code-text").textContent = p.code;
      $("#alerts-code-note").textContent = `DJ Alerts already on your Home Screen? Open it and type this in. `
        + `Works once, until ${new Date(p.expires * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}.`;
    }
    $("#alerts-phones").replaceChildren(...(i.phones.length ? i.phones.map(ph => {
      const row = el("div", "alerts-phone");
      const words = el("div");
      words.append(el("b", null, ph.name),
                   el("small", null, "Paired " + new Date(ph.added * 1000).toLocaleDateString([], { day: "numeric", month: "short" })));
      const test = el("button", null, "Test");
      test.type = "button";
      test.title = "Send a test alert to every paired phone";
      test.onclick = sendTestAlert;
      const rm = el("button", null, "Remove");
      rm.type = "button";
      rm.onclick = () => removePhone(ph);
      row.append(words, test, rm);
      return row;
    }) : [el("p", "alerts-none", "No phone paired yet.")]));
    $("#popup-on").checked = state.settings.request_popup !== false;
    paintBoothPage();
    // The code runs out on its own; the card follows without being asked.
    clearTimeout(alertsTimer);
    if (p) alertsTimer = setTimeout(() => refreshAlerts().catch(() => {}), Math.max(1000, p.expires * 1000 - Date.now() + 500));
  }
  async function refreshAlerts() {
    alertsInfo = await call("alerts_info");
    renderAlerts();
  }
  $("#alerts-pair").onclick = async () => {
    if (alertsInfo && alertsInfo.pairing) {
      alertsInfo = await call("alerts_pair_cancel");
      return renderAlerts();
    }
    const r = await call("alerts_pair");
    if (!r.ok) return toast(r.error || "Couldn't make a pairing code.", true);
    alertsInfo = r;
    renderAlerts();
    if (r.settings) state.settings = r.settings;     // pairing answers through the phone remote, so it's on now
    refreshRemote().catch(() => {});
  };
  async function sendTestAlert(e) {
    const b = e.currentTarget;
    b.disabled = true;
    const r = await call("alerts_test");
    b.disabled = false;
    toast(r.ok ? "Test alert sent. It should be on your phone in a few seconds." : r.error, !r.ok);
  }
  async function removePhone(ph) {
    alertsInfo = await call("alerts_remove", ph.id);
    renderAlerts();
    toast(`${ph.name} removed. It won't get alerts any more.`);
  }
  $("#popup-on").addEventListener("change", async e => {
    state.settings = await call("set_setting", "request_popup", e.target.checked);
    renderAlerts();
  });

  // ── Serato ─────────────────────────────────────────────────────────────
  // Same shape as the rekordbox panel, with one difference the status line has to be honest about:
  // Serato reads its crates at launch, so "written" is not the same as "showing in Serato".
  let srInfo = null, srTimer = 0;
  function renderSerato() {
    const i = srInfo;
    if (!i) return;
    $("#sr-on").checked = i.enabled;
    const p = $("#sr-path");
    p.textContent = "‎" + i.folder;
    p.title = i.folder;
    const st = $("#sr-status");
    st.className = "rb-status " + (i.enabled ? "on" : "off");
    st.replaceChildren();
    if (!i.enabled) return st.append(el("span", null, "Off · your Serato crates stop updating"));
    if (i.waiting || i.serato_open) {
      st.className = "rb-status warn";
      return st.append(el("span", null, "Serato is open · your crates are written the moment you close it"));
    }
    const mine = i.crates[SERATO_CRATE] || { tracks: 0 };
    const reqs = i.crates[SERATO_REQUESTS] || { tracks: 0 };
    st.append(el("span", "dot live"),
              el("span", null, `Crates written · ${mine.tracks} track${mine.tracks === 1 ? "" : "s"}${reqs.tracks ? ` · ${reqs.tracks} request${reqs.tracks === 1 ? "" : "s"}` : ""}`));
    if (mine.written) st.append(el("span", "rb-when", `updated ${ago(mine.written)}`));
    const cued = (i.cues && i.cues.cued) || 0;
    if (cued) st.append(el("span", "rb-when", `hot cues in ${cued} download${cued === 1 ? "" : "s"}`));
    if (i.skipped) st.append(el("span", "rb-when", `${i.skipped} on another drive, left out`));
  }
  const SERATO_CRATE = "Yoshi C's DJ Master", SERATO_REQUESTS = "Song requests";
  async function refreshSerato() {
    srInfo = await call("serato_info");
    renderSerato();
  }
  const refreshSeratoSoon = () => { clearTimeout(srTimer); srTimer = setTimeout(() => refreshSerato().catch(() => {}), 2600); };
  $("#sr-on").addEventListener("change", async e => {
    state.settings = await call("set_setting", "serato_enabled", e.target.checked);
    await refreshSerato();
    if (e.target.checked) {
      toast(srInfo && (srInfo.waiting || srInfo.serato_open)
        ? "Serato is open, so the crates are written the moment you close it."
        : "Serato crates written. Open Serato to see them - it reads crates when it starts.");
    }
  });
  $("#sr-show").onclick = () => call("serato_reveal");
  $("#sr-copy").onclick = async () => {
    if (!srInfo) return;
    try { await navigator.clipboard.writeText(srInfo.folder); toast("Folder path copied."); }
    catch (err) { toast("Couldn't copy. Select the path and copy it instead.", true); }
  };
  document.querySelectorAll(".djsoft-tabs button").forEach(b => (b.onclick = () => {
    document.querySelectorAll(".djsoft-tabs button").forEach(x => {
      x.classList.toggle("on", x === b);
      x.setAttribute("aria-selected", String(x === b));
    });
    document.querySelectorAll("[data-soft-panel]").forEach(p => (p.hidden = p.dataset.softPanel !== b.dataset.soft));
    if (b.dataset.soft === "serato") refreshSerato().catch(() => {});
    if (["virtualdj", "traktor", "engine"].includes(b.dataset.soft)) refreshOtherDj();
    measureSections();
  }));

  // ── VirtualDJ, Traktor, Engine DJ (otherdj.py) ─────────────────────────
  let otherDj = null;
  const whenText = at => {
    if (!at) return "";
    const s = Date.now() / 1000 - at;
    return s < 90 ? "Written just now" : s < 3600 ? `Written ${Math.round(s / 60)} minutes ago` : `Written ${agoText(at).toLowerCase()}`;
  };
  async function refreshOtherDj() {
    const i = otherDj = await call("otherdj_info").catch(() => null);
    if (!i) return;
    const v = i.virtualdj, t = i.traktor, e = i.engine;
    $("#vdj-on").checked = v.enabled; $("#vdj-on").disabled = !v.found && !v.enabled;
    $("#vdj-path").textContent = v.found ? "\u200e" + shortPath(v.folder) : "VirtualDJ isn't on this computer yet";
    $("#vdj-path").title = v.folder;
    $("#vdj-show").hidden = !v.found;
    $("#vdj-status").textContent = v.error ? `Couldn't write them: ${v.error}` : !v.found ? "Install VirtualDJ and open it once, then come back here."
      : v.enabled && v.last ? `${Object.keys(v.last.written).length} playlists, ${Object.values(v.last.written)[0] || 0} tracks in the main one. ${whenText(v.last.at)}.` : v.enabled ? "On - written a moment after anything changes." : "Off.";
    $("#trk-on").checked = t.enabled;
    $("#trk-path").textContent = "\u200e" + shortPath(t.file); $("#trk-path").title = t.file;
    $("#trk-show").hidden = !t.exists;
    $("#trk-status").textContent = t.error ? `Couldn't write it: ${t.error}` : t.enabled && t.last ? `${t.last.tracks} tracks in ${t.last.playlists} playlists. ${whenText(t.last.at)}.`
      : t.enabled ? "On - the file is rewritten a moment after anything changes." : "Off.";
    $("#eng-path").textContent = "\u200e" + shortPath(e.path); $("#eng-path").title = e.path;
    $("#eng-show").hidden = !e.exists;
    $("#eng-status").textContent = e.enabled ? (e.exists ? "The rekordbox file is being kept up to date - point Engine DJ at it." : "The rekordbox file will be written in a moment.")
      : "Turn on Keep rekordbox in sync (the rekordbox tab) first.";
  }
  for (const [id, key] of [["#vdj-on", "virtualdj_enabled"], ["#trk-on", "traktor_enabled"]]) {
    $(id).addEventListener("change", async ev => {
      state.settings = await call("set_setting", key, ev.target.checked);
      setTimeout(refreshOtherDj, 600);
    });
  }
  const copyPath = async text => { try { await navigator.clipboard.writeText(text); toast("Path copied."); } catch (err) { toast("Couldn't copy. Select the path and copy it instead.", true); } };
  $("#trk-copy").onclick = () => otherDj && copyPath(otherDj.traktor.file);
  $("#eng-copy").onclick = () => otherDj && copyPath(otherDj.engine.path);
  for (const [id, which] of [["#vdj-show", "virtualdj"], ["#trk-show", "traktor"], ["#eng-show", "engine"]])
    $(id).onclick = async () => { const r = await call("otherdj_reveal", which); if (r && r.ok === false) toast(r.error, true); };

  const licenceBtn = $("#open-licence");
  if (licenceBtn) licenceBtn.onclick = () => call("open_licence");
  const noticesBtn = $("#open-notices");
  if (noticesBtn) noticesBtn.onclick = () => call("open_notices");

  // ── theme ──────────────────────────────────────────────────────────────
  // Nine accents picked for this background: every one clears WCAG AA against it (the figure the
  // picker shows is the real contrast ratio, worked out the same way). Only the accent changes -
  // the near-black, the greys and the type are the app's identity and stay put.
  const THEMES = [
    ["signal", "Signal red", "#ff4d4d"], ["ember", "Ember", "#ff7a45"], ["amber", "Amber", "#ffb020"],
    ["lime", "Acid lime", "#c4f06a"], ["mint", "Mint", "#49e3a6"], ["aqua", "Aqua", "#4dd8e0"],
    ["sky", "Sky", "#6aa9ff"], ["violet", "Violet", "#c084fc"], ["rose", "Rose", "#ff6fae"],
  ];
  const hexRgb = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
  const luminance = hex => {
    const [r, g, b] = hexRgb(hex).map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  };
  const contrastOnBg = hex => (luminance(hex) + 0.05) / (luminance("#0a0808") + 0.05);
  const validHex = v => /^#[0-9a-f]{6}$/i.test(String(v || "").trim());

  function applyAccent(hex) {
    if (!validHex(hex)) return;
    hex = hex.toLowerCase();
    const [r, g, b] = hexRgb(hex);
    document.documentElement.style.setProperty("--signal-rgb", `${r} ${g} ${b}`);
    if (window.bgAccent) window.bgAccent(r / 255, g / 255, b / 255);   // the smoke follows the theme
    const dot = $("#accent-dot");
    if (dot) dot.style.background = hex;
    const pick = $("#accent-pick");
    if (pick) pick.value = hex;
    const hexIn = $("#accent-hex");
    if (hexIn && hexIn !== document.activeElement) hexIn.value = hex;
    const note = $("#accent-contrast");
    if (note) {
      const ratio = contrastOnBg(hex);
      note.textContent = `${ratio.toFixed(1)}:1 on the background`;
      note.classList.toggle("poor", ratio < 4.5);
      note.title = ratio < 4.5 ? "Below the 4.5:1 readability standard - pick something lighter."
                               : "Comfortably readable (WCAG AA is 4.5:1).";
    }
    document.querySelectorAll(".swatch").forEach(s => s.classList.toggle("on", s.dataset.hex === hex));
  }

  // Picking a colour sweeps it across the app from left to right instead of swapping it in one frame.
  // View Transitions do the work: the browser photographs the app, applies the colour, and wipes from one
  // to the other. Where they aren't supported (macOS before 15) the colour simply changes, as before.
  function sweepTo(change) {
    if (REDUCED || !document.startViewTransition) return change();
    const root = document.documentElement;
    root.classList.add("sweep");
    const vt = document.startViewTransition(change);
    vt.finished.finally(() => root.classList.remove("sweep"));
  }
  async function saveAccent(hex, theme) {
    sweepTo(() => applyAccent(hex));
    state.settings = await call("set_setting", "accent", hex);
    state.settings = await call("set_setting", "theme", theme || "custom");
  }

  let pendingTheme = null;                    // chosen during setup, saved once the account exists

  function swatchRow(box, onPick) {
    if (!box) return;
    box.replaceChildren(...THEMES.map(([id, name, hex]) => {
      const b = el("button", "swatch", null);
      b.type = "button";
      b.dataset.hex = hex;
      b.style.setProperty("--c", hex);
      b.title = `${name} · ${contrastOnBg(hex).toFixed(1)}:1 on the background`;
      b.append(el("i"), el("span", null, name));
      b.onclick = () => onPick(hex, id);
      return b;
    }));
  }

  function buildThemes() {
    const box = $("#swatches");
    if (!box) return;
    swatchRow(box, (hex, id) => saveAccent(hex, id));
    // First run: the same colours on the setup card. Nothing can be saved until there's an account,
    // so the pick is applied straight away and written the moment sign-up succeeds.
    swatchRow($("#setup-swatches"), (hex, id) => {
      pendingTheme = [hex, id];
      applyAccent(hex);
      document.querySelectorAll("#setup-swatches .swatch").forEach(s => s.classList.toggle("on", s.dataset.hex === hex));
    });
    $("#accent-pick").addEventListener("input", e => applyAccent(e.target.value));
    $("#accent-pick").addEventListener("change", e => saveAccent(e.target.value, "custom"));
    $("#accent-hex").addEventListener("input", e => {
      const v = e.target.value.trim();
      if (validHex(v)) applyAccent(v);
    });
    $("#accent-hex").addEventListener("change", e => {
      const v = e.target.value.trim();
      if (validHex(v)) saveAccent(v, "custom");
      else applyAccent(state.settings.accent || "#ff4d4d");
    });
    $("#accent-reset").onclick = () => saveAccent("#ff4d4d", "signal");
  }
  buildThemes();

  // ── settings & account ────────────────────────────────────────────────
  // The wallpaper's brightness (Settings > Theme): 0 is off - bg.js stops drawing it - and 100 is full. Set from the
  // boot answer too, so the smoke never shows brighter than chosen, even for a frame.
  function applyWall(v) {
    const n = Math.max(0, Math.min(100, Number.isFinite(Number(v)) && v !== null && v !== "" ? Number(v) : 100));
    // With the booth link open the DJ is at a gig, in the dark: the smoke drops to a quarter at most, so the brightest
    // thing on the laptop is the music, not the wallpaper. The slider keeps the DJ's own setting for the rest of the time.
    const shown = state.settings && state.settings.booth_mode ? Math.min(n, 25) : n;
    document.documentElement.classList.toggle("gig", !!(state.settings && state.settings.booth_mode));   // glass.css: no blur mid-set
    document.documentElement.style.setProperty("--wall", String(shown / 100));
    document.documentElement.classList.toggle("wall-off", shown === 0);
    const r = $("#wall-dim"), o = $("#wall-val");
    if (r && document.activeElement !== r) r.value = String(n);
    if (o) o.textContent = n ? `${n}%` : "Off";
  }
  $("#wall-dim").addEventListener("input", e => { document.documentElement.classList.add("wall-live"); applyWall(e.target.value); });
  $("#wall-dim").addEventListener("change", async e => {
    state.settings = await call("set_setting", "wallpaper", Number(e.target.value));
    document.documentElement.classList.remove("wall-live");
  });

  function renderSettings() {
    renderShortcuts();
    const s = state.settings;
    applyAccent(s.accent || "#ff4d4d");
    applyWall(s.wallpaper);
    if (window.YCMore) { YCMore.ready(); YCMore.apply(s); }
    const p = $("#output-dir");
    p.textContent = "‎" + (s.output_dir || "");
    p.title = s.output_dir || "";
    $("#names-with-key").checked = !!s.names_with_key;
    $("#notify-done").checked = !!s.notify_done;
    $("#update-check").checked = s.update_check !== false;
    $("#requests-download-only").checked = !!s.requests_download_only;
    const tidy = $("#crate-tidy");
    if (tidy) { tidy.setAttribute("aria-pressed", String(!!s.tidy_names)); tidy.textContent = s.tidy_names ? "Tidy names ✓" : "Tidy names"; }
    document.querySelectorAll("#intro-bars [data-bars]").forEach(b => {
      const on = Number(b.dataset.bars) === (Number(s.intro_bars) || 16);
      b.classList.toggle("on", on);
      b.setAttribute("aria-checked", String(on));
    });
    renderPurchaseDirs(s);
    renderLibrary(s);
    $("#names-note").textContent = s.names_with_key ? "Artist - Title - 128 BPM - A minor.wav" : "Artist - Title.wav";
    paintSoftware();
  }
  // Your DJ software (Settings > General): its name wherever the app mentions it - the side menu, the home tile, the
  // request pop-up - and its own tab under DJ software. Until it's picked, it's worked out from the two sync switches.
  const SOFT_NAME = { rekordbox: "rekordbox", serato: "Serato", both: "rekordbox + Serato", other: "DJ software" };
  let softShown = null;
  function djSoftware(s = state.settings || {}) {
    if (SOFT_NAME[s.dj_software]) return s.dj_software;
    const rb = s.rekordbox_enabled !== false, sr = !!s.serato_enabled;
    return rb && sr ? "both" : sr ? "serato" : rb ? "rekordbox" : "other";
  }
  function paintSoftware() {
    const soft = djSoftware(), name = SOFT_NAME[soft];
    document.querySelectorAll("#soft-pick [data-pick]").forEach(b => {
      b.classList.toggle("on", b.dataset.pick === soft);
      b.setAttribute("aria-checked", String(b.dataset.pick === soft));
    });
    const rail = document.querySelector('.rail-item[data-target="djsoft"] .rail-name');
    if (rail) { rail.textContent = soft === "both" ? "DJ software" : name; nameRail(); }    // "rekordbox + Serato" ran onto two lines
    const tile = $("#tile-rb")?.closest(".tile")?.querySelector(".label");
    if (tile) tile.textContent = name;
    const pop = $("#popup-name");
    if (pop) pop.textContent = soft === "other" ? "your DJ software" : soft === "both" ? "rekordbox or Serato" : name;
    // Its own setup tab, when the pick first shows or changes - never pulling someone off the tab they chose.
    if (soft !== softShown) {
      softShown = soft;
      const tab = document.querySelector(`.djsoft-tabs [data-soft="${soft === "serato" ? "serato" : "rekordbox"}"]`);
      if (tab && soft !== "other" && !tab.classList.contains("on")) tab.click();
    }
  }
  document.querySelectorAll("#soft-pick [data-pick]").forEach(b => (b.onclick = async () => {
    state.settings = await call("set_setting", "dj_software", b.dataset.pick);
    renderSettings();
    // Its sync may have just been switched on: the DJ software page and the home tile catch up.
    refreshRekordbox().catch(() => {});
    refreshSerato().catch(() => {});
  }));
  $("#output-change").onclick = async () => { state.settings = await call("pick_folder"); renderSettings(); };
  $("#names-with-key").addEventListener("change", async e => { state.settings = await call("set_setting", "names_with_key", e.target.checked); renderSettings(); });
  $("#notify-done").addEventListener("change", async e => { state.settings = await call("set_setting", "notify_done", e.target.checked); renderSettings(); });
  $("#crate-tidy").addEventListener("click", async () => {
    const on = !(state.settings && state.settings.tidy_names);
    state.settings = await call("set_setting", "tidy_names", on);
    renderSettings();
    const s = await call("get_state");                   // the names come from the crate's own listing
    if (s && s.crate) { syncCrate(s.crate); syncRequests(s.requests); }
    toast(on ? "Names tidied here and in your DJ software's library file. Your files are untouched." : "Original names back.");
  });
  $("#requests-download-only").addEventListener("change", async e => { state.settings = await call("set_setting", "requests_download_only", e.target.checked); renderSettings(); });
  document.querySelectorAll("#intro-bars [data-bars]").forEach(b => (b.onclick = async () => {
    state.settings = await call("set_setting", "intro_bars", Number(b.dataset.bars));
    renderSettings();
  }));
  // ── your music library ─────────────────────────────────────────────────
  function renderLibrary(s) {
    const box = $("#library-dirs");
    const dirs = s.library_dirs || [];
    box.replaceChildren(...(dirs.length ? dirs.map(d => {
      const chip = el("span", "pdir");
      chip.append(el("span", "pdir-path", d));
      const x = el("button", "pdir-x", "×");
      x.type = "button";
      x.title = "Stop looking in this folder (what's in the crate stays)";
      x.onclick = async () => { state.settings = await call("remove_library_folder", d); renderLibrary(state.settings); };
      chip.append(x);
      return chip;
    }) : [el("span", "pdir-none", "No folders yet.")]));
    $("#library-serato").checked = !!s.library_serato;
    const rb = s.library_rekordbox_xml || "";
    $("#library-rb").textContent = rb ? "\u200e" + rb : "Not set";
    $("#library-rb").classList.toggle("off", !rb);
    $("#library-rb-clear").hidden = !rb;
    $("#library-downloads").hidden = dirs.some(d => /[\\/]Downloads$/.test(d));
  }
  const libraryAdded = () => toast("Looking in it now - new songs come into the crate in a moment, and their tempo and key follow in the background.", false, 7000);
  $("#library-add").onclick = async () => {
    const before = (state.settings.library_dirs || []).length;
    state.settings = await call("add_library_folder");
    renderLibrary(state.settings);
    if ((state.settings.library_dirs || []).length > before) libraryAdded();
  };
  $("#library-downloads").onclick = async () => { state.settings = await call("add_library_folder", "downloads"); renderLibrary(state.settings); libraryAdded(); };
  $("#library-look").onclick = async () => {
    const r = await call("library_look_now");
    toast(r && r.reread ? `Looking for new songs, and reading ${unreadWords(r.reread)}.` : "Looking for new songs…", false, 7000);
  };
  $("#library-serato").addEventListener("change", async e => { state.settings = await call("set_setting", "library_serato", e.target.checked); if (e.target.checked) libraryAdded(); });
  $("#library-rb-pick").onclick = async () => { state.settings = await call("pick_rekordbox_xml"); renderLibrary(state.settings); if (state.settings.library_rekordbox_xml) libraryAdded(); };
  $("#library-rb-clear").onclick = async () => { state.settings = await call("pick_rekordbox_xml", true); renderLibrary(state.settings); };

  // ── prepare my purchases ───────────────────────────────────────────────
  function renderPurchaseDirs(s) {
    const box = $("#purchase-dirs");
    const dirs = s.purchase_dirs || [];
    box.replaceChildren(...(dirs.length ? dirs.map(d => {
      const chip = el("span", "pdir");
      chip.append(el("span", "pdir-path", d));
      const x = el("button", "pdir-x", "×");
      x.type = "button";
      x.title = "Stop watching this folder";
      x.onclick = async () => { state.settings = await call("remove_purchase_folder", d); renderPurchaseDirs(state.settings); };
      chip.append(x);
      return chip;
    }) : [el("span", "pdir-none", "No folders yet.")]));
    $("#purchase-move").checked = s.purchase_move !== false;
  }
  $("#purchase-add").onclick = async () => {
    const before = (state.settings.purchase_dirs || []).length;
    state.settings = await call("add_purchase_folder");
    renderPurchaseDirs(state.settings);
    if ((state.settings.purchase_dirs || []).length > before)
      toast("Watching it. Tracks that land there from now on are prepared and put in your crate by themselves.", false, 7000);
  };
  $("#purchase-move").addEventListener("change", async e => {
    state.settings = await call("set_setting", "purchase_move", e.target.checked);
  });

  // ── backups ────────────────────────────────────────────────────────────
  // "Today", "Yesterday" or "Mon 21 Sep" by the calendar - a copy from 11 pm is not "today" at 1 am.
  function dayLabel(ts) {
    const d = new Date(ts * 1000), now = new Date();
    const days = Math.round((new Date(now.getFullYear(), now.getMonth(), now.getDate())
                            - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 86400000);
    return days === 0 ? "Today" : days === 1 ? "Yesterday"
      : d.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" });
  }
  function renderBackups(list) {
    const box = $("#backup-rows");
    if (!Array.isArray(list)) return;
    if (!list.length) return box.replaceChildren(el("span", "pdir-none", "No copies yet - the first is made a few seconds after you sign in."));
    box.replaceChildren(...list.slice(0, 7).map(b => {
      const row = el("div", "bk-row");
      const day = dayLabel(b.when || 0);
      const time = new Date((b.when || 0) * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      row.append(el("b", null, `${day} · ${time}`),
                 el("span", "bk-what", [b.label, `${b.tracks} track${b.tracks === 1 ? "" : "s"}`,
                   b.requests ? `${b.requests} request${b.requests === 1 ? "" : "s"}` : "",
                   b.smart ? `${b.smart} smart crate${b.smart === 1 ? "" : "s"}` : ""].filter(Boolean).join(" · ")));
      // Two clicks, like every other thing here that replaces what you have.
      const go = el("button", "btn-text bk-restore", "Restore");
      go.type = "button";
      let armed = 0;
      const disarm = () => { clearTimeout(armed); armed = 0; go.classList.remove("arm"); go.textContent = "Restore"; };
      go.onclick = async () => {
        if (!armed) {
          go.classList.add("arm");
          go.textContent = "Sure? Now is saved first";
          armed = setTimeout(disarm, 5000);
          return;
        }
        disarm();
        go.disabled = true;
        const r = await call("backup_restore", b.id);
        go.disabled = false;
        if (!r || !r.ok) return toast((r && r.error) || "Couldn't restore that copy.", true);
        await refreshAll();
        renderBackups(r.backups);
        toast(`Restored: your crate is back to how it was ${day === "Today" ? "earlier today" : day === "Yesterday" ? "yesterday" : "on " + day} at ${time}. How it was a moment ago is at the top of the list.`, false, 7000);
      };
      row.append(go);
      return row;
    }));
  }
  const refreshBackups = () => call("backups").then(renderBackups).catch(() => {});

  // ── what changed ───────────────────────────────────────────────────────
  // The safety net's page (changes.py): every change with its Undo, and what's in the holding folder.
  const fmtBytes = n => (n >= 1073741824 ? `${(n / 1073741824).toFixed(1)} GB` : n >= 1048576 ? `${Math.round(n / 1048576)} MB` : n > 0 ? "under 1 MB" : "nothing");
  function renderChanges(data) {
    const box = $("#change-rows");
    if (!data || !Array.isArray(data.items)) return;
    document.querySelectorAll(".trash-name").forEach(x => { x.textContent = data.trash || trashName(); });
    if (!data.items.length) box.replaceChildren(el("span", "pdir-none", "Nothing yet. Deleting a track, clearing the requests or scanning a folder will show up here."));
    else box.replaceChildren(...data.items.slice(0, 60).map(c => {
      const row = el("div", "bk-row ch-row" + (c.undone ? " undone" : ""));
      const when = new Date(c.at * 1000);
      const what = el("span", "bk-what ch-what");
      what.append(el("b", null, c.label));
      const more = [c.detail, c.held ? `${c.held} file${c.held === 1 ? "" : "s"} held · ${fmtBytes(c.held_bytes)} · ${c.days_left} day${c.days_left === 1 ? "" : "s"} left` : ""].filter(Boolean).join(" ");
      if (more) what.append(el("small", null, more));
      row.append(el("span", "ch-when", `${dayLabel(c.at)} · ${when.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`), what);
      if (c.undone) row.append(el("span", "ch-done", "Undone"));
      else if (c.can_undo) {
        const go = el("button", "btn-outline ch-undo", "Undo");
        go.type = "button";
        go.onclick = async () => {
          go.disabled = true;
          const r = await call("change_undo", c.id);
          if (!r || !r.ok) { go.disabled = false; return toast((r && r.error) || "Couldn't undo that.", true); }
          if (r.crate) { syncLibrary(r); renderSmart(r.smart); refreshRekordboxSoon(); }
          renderChanges(r);
          toast(r.lost ? `Undone - ${r.back - r.lost} back with their files; ${r.lost} listed again but the file wasn't found.` : `Undone: ${c.label.charAt(0).toLowerCase() + c.label.slice(1)}.`, !!r.lost, 7000);
        };
        row.append(go);
      }
      return row;
    }));
    $("#change-held").textContent = data.held ? `Holding folder: ${data.held} file${data.held === 1 ? "" : "s"}, ${fmtBytes(data.held_bytes)}. Each goes to the ${data.trash} after ${data.days} days.` : "Holding folder: empty.";
    $("#holding-show").hidden = $("#holding-empty").hidden = !data.held;
  }
  const refreshChanges = () => call("changes_list").then(renderChanges).catch(() => {});
  $("#holding-show").onclick = async () => { const r = await call("holding_reveal"); if (r && r.ok === false) toast(r.error, true); };
  {
    const go = $("#holding-empty");
    let armed = 0;
    const disarm = () => { clearTimeout(armed); armed = 0; go.classList.remove("arm"); go.textContent = "Empty it now"; };
    go.onclick = async () => {
      if (!armed) { go.classList.add("arm"); go.textContent = `To the ${trashName()} - sure?`; armed = setTimeout(disarm, 5000); return; }
      disarm();
      const r = await call("holding_empty");
      renderChanges(r);
      toast(`${r.binned} held file${r.binned === 1 ? "" : "s"} moved to the ${trashName()}.`);
    };
  }
  $("#crate-history").onclick = () => openSettings("changes");
  $("#backup-now").onclick = async () => { renderBackups(await call("backup_now")); toast("Backed up."); };
  $("#backup-show").onclick = () => call("backup_reveal");

  // ── library clean-up ───────────────────────────────────────────────────
  // A report first, and nothing changes until a button on it is pressed. Removing a double is the same
  // delete as anywhere else in the crate: to the bin, with Undo - and never a file another entry still plays
  // (app.py: two entries can be one file, the same path spelt two ways; binning that lost 1310 tracks, 8 Oct).
  // Long jobs show a progress bar the app keeps up to date (onCleanProgress).
  let cleanBar = null;
  function progressBar(label) {
    const wrap = el("div", "clean-progress indeterminate");
    const top = el("div", "clean-progress-top");
    const name = el("span", "clean-progress-label", label), count = el("span", "clean-progress-count", "");
    top.append(name, count);
    const track = el("div", "clean-progress-track"), fill = el("div", "clean-progress-fill");
    track.append(fill);
    track.setAttribute("role", "progressbar");
    track.setAttribute("aria-label", label);
    wrap.append(top, track);
    cleanBar = { wrap, name, count, fill, track };
    return wrap;
  }
  function onCleanProgress(p) {
    if (!cleanBar || !p || p.done === true) return;
    if (p.label) cleanBar.name.textContent = p.label + "…";
    if (p.total) {
      const pct = Math.max(0, Math.min(1, p.done / p.total));
      cleanBar.wrap.classList.remove("indeterminate");
      cleanBar.fill.style.transform = `scaleX(${pct})`;
      cleanBar.count.textContent = `${p.done.toLocaleString()} of ${p.total.toLocaleString()}`;
      cleanBar.track.setAttribute("aria-valuenow", String(Math.round(pct * 100)));
    } else {
      cleanBar.wrap.classList.add("indeterminate");
      cleanBar.count.textContent = p.done ? `${p.done.toLocaleString()} files looked at` : "";
    }
  }
  async function openClean() {
    const box = $("#clean");
    if (!box.hidden) { box.hidden = true; return; }
    box.hidden = false;
    await refreshClean();
  }
  async function refreshClean() {
    const box = $("#clean");
    const top = el("div", "clean-top");
    top.append(el("span", "clean-title", "Clean up"), btn("Close ×", () => { box.hidden = true; }));
    box.replaceChildren(top, progressBar("Looking through your crate…"));
    const r = await call("library_report");
    cleanBar = null;
    if (!r || r.ok === false) { box.replaceChildren(el("div", "clean-wait", (r && r.error) || "Couldn't read the crate.")); return; }
    renderClean(r);
  }
  function cleanGroup(title, note, rows, actions) {
    const g = el("div", "clean-group");
    const head = el("div", "clean-head");
    head.append(el("span", "label", title), el("span", "clean-note", note));
    g.append(head);
    const acts = (actions || []).filter(Boolean);
    if (acts.length) { const row = el("div", "clean-acts"); row.append(...acts); g.append(row); }
    g.append(...rows);
    return g;
  }
  function cleanRow(t, extra) {
    const row = el("div", "clean-row");
    row.dataset.id = t.id;
    const who = el("div", "clean-who");
    who.append(el("b", null, t.title), el("small", null, [t.artist, t.folder, t.path.split(/[\\/]/).pop()].filter(Boolean).join(" · ")));
    row.append(who, ...extra);
    return row;
  }
  function btn(label, fn, cls = "btn-text") { const b = el("button", cls, label); b.type = "button"; b.onclick = fn; return b; }
  // A group-wide button that asks once ("— sure?") before it acts, and shows a progress bar under its row while it works.
  function bulkButton(label, ask, cls, run) {
    const b = btn(label, null, cls);
    let armed = 0;
    b.onclick = async () => {
      if (ask && !armed) {
        b.textContent = ask;
        armed = setTimeout(() => { armed = 0; b.textContent = label; }, 5000);
        return;
      }
      clearTimeout(armed); armed = 0;
      const row = b.closest(".clean-acts");
      row.querySelectorAll("button").forEach(x => (x.disabled = true));
      const bar = progressBar("Working…");
      row.after(bar);
      try { await run(b); } finally {
        bar.remove(); cleanBar = null;
        row.querySelectorAll("button").forEach(x => (x.disabled = false));
        b.textContent = label;
      }
    };
    return b;
  }
  const gone = ids => ids.forEach(id => $("#clean").querySelector(`.clean-row[data-id="${CSS.escape(id)}"]`)?.classList.add("gone"));
  function renderClean(r) {
    const box = $("#clean");
    const parts = [];
    const close = btn("Close ×", () => { box.hidden = true; });
    const top = el("div", "clean-top");
    const total = r.doubles.length + r.missing.length + r.unread.length;
    top.append(el("span", "clean-title", total ? "Clean up" : "Nothing to clean up - the crate's in order."), close);
    parts.push(top);
    if (r.doubles.length) parts.push(cleanGroup(`The same track twice · ${r.doubles.length}`, "The first of each is the better copy (lossless, then larger). One file listed twice loses only its extra listing.",
      r.doubles.flatMap(group => group.map((t, i) => cleanRow(t, i === 0 ? [el("span", "chip", "Keep")]
        : t.same_file ? [el("small", "clean-found", "Same file, listed twice"), btn("Remove this listing", async e => {
          e.target.disabled = true;
          const res = await call("crate_remove", t.id, false);
          if (res && res.ok === false) return toast(res.error, true);
          if (res && res.crate) syncLibrary(res);
          e.target.closest(".clean-row").classList.add("gone");
          toast(`The extra listing of “${t.title}” is gone - the file stays, under the first one.`, false, 6000);
        })]
        : [btn("Remove this copy", async e => {
          e.target.disabled = true;
          const res = await call("crate_remove", t.id, true);
          if (res && res.ok === false) return toast(res.error, true);
          if (res && res.crate) syncLibrary(res);
          e.target.closest(".clean-row").classList.add("gone");
          toast(`“${t.title}” (the extra copy) is deleted - kept for 30 days in case you want it back.`, false, 6000);
        })]))), [deleteAllDoubles(r.doubles)]));
    if (r.missing.length) {
      const found = r.missing.filter(t => t.found), links = r.can_download ? r.missing.filter(t => t.link && !t.found) : [];
      parts.push(cleanGroup(`File moved or gone · ${r.missing.length}`,
        `Found by name in your folders where it could be.${found.length < r.missing.length ? ` Deleted ones are back if you restore the folder from a backup - Time Machine on a Mac, File History on Windows - then open Clean up again.` : ""}`,
        r.missing.map(t => cleanRow(t, t.found ? [el("small", "clean-found", `Found at ${t.found}`), btn("Point it there", async e => {
          const res = await call("relink_track", t.id, t.found);
          if (!res.ok) return toast(res.error, true);
          if (res.crate) syncCrate(res.crate);
          e.target.closest(".clean-row").classList.add("gone");
          refreshRekordboxSoon();
        })] : [el("small", "clean-found", t.link && r.can_download ? "Not found - it can download again" : "Not found in your folders, Music or Downloads")])),
        [found.length && bulkButton(`Copy back ${found.length} found ${found.length === 1 ? "file" : "files"}`, null, "btn-pill small", async () => {
          const res = await call("copy_back_found", found.map(t => ({ id: t.id, found: t.found })));
          if (res && res.crate) syncCrate(res.crate);
          refreshRekordboxSoon();
          toast(res && res.failed ? `${res.copied} copied back, ${res.failed} couldn't be. ${res.error || ""}` : `${res.copied} file${res.copied === 1 ? "" : "s"} copied back to where your crate, rekordbox and Serato expect ${res.copied === 1 ? "it" : "them"}.`, !!(res && res.failed), 9000);
          await refreshClean();
        }),
        links.length && bulkButton(`Download again · ${links.length}`, `Download ${links.length} again — sure?`, "btn-pill small", async () => {
          const res = await call("download_missing", links.map(t => t.id));
          if (!res || !res.ok) return toast((res && res.error) || "Couldn't queue them.", true);
          gone(links.map(t => t.id));
          toast(`${res.queued} download${res.queued === 1 ? "" : "s"} queued from the links they came from. Each takes the place of its missing track as it lands.`, false, 9000);
        }),
        bulkButton(`Take all ${r.missing.length} out of the crate`, `Take ${r.missing.length} out — sure?`, "btn-pill small danger", async () => {
          const ids = r.missing.map(t => t.id);
          const res = await call("crate_remove_many", ids, false, "missing track");
          if (!res) return toast("Couldn't take them out.", true);
          syncLibrary(res); renderSmart(res.smart); refreshRekordboxSoon();
          gone(ids);
          toast(`${res.removed} missing track${res.removed === 1 ? "" : "s"} taken out of the crate. Today's crate backup in Settings still has them.`, false, 9000);
        })]));
    }
    if (r.unread.length) parts.push(cleanGroup(`Never read for tempo and key · ${r.unread.length}`, "Reading takes a few seconds each, in the background.",
      r.unread.map(t => cleanRow(t, [btn("Read it now", async e => {
        e.target.disabled = true;
        const res = await call("reanalyse_track", t.id);
        if (!res.ok) return toast(res.error, true);
        e.target.textContent = "Reading…";
      })]))));
    box.replaceChildren(...parts);
  }
  // Every extra copy at once: the better copy of each stays (the first in its group), the rest go to the bin
  // exactly as "Remove this copy" sends them - held a few seconds so Undo puts them all back. One file listed
  // twice loses only its extra listing; the app checks the file itself, whatever this list says.
  function deleteAllDoubles(groups) {
    const extras = groups.flatMap(group => group.slice(1));
    const label = `Delete all duplicates · ${extras.length}`;
    return bulkButton(label, `Delete ${extras.length} extra ${extras.length === 1 ? "copy" : "copies"} — sure?`, "btn-pill small danger clean-all", async b => {
      const ids = extras.map(t => t.id);
      const res = await call("crate_remove_many", ids, true, "duplicate");
      if (!res) return toast("Couldn't delete the duplicates.", true);
      syncLibrary(res);
      renderSmart(res.smart);
      refreshRekordboxSoon();
      gone(ids);
      b.hidden = true;
      const kept = res.kept_files ? ` ${res.kept_files} ${res.kept_files === 1 ? "was" : "were"} the same file listed twice - only the listing went.` : "";
      // A few seconds to change your mind - the files only go to the bin once the app's hold runs out.
      toastWithAction(`${res.removed} duplicate${res.removed === 1 ? "" : "s"} removed; the better copy of each is kept.${kept}`, "Undo", async () => {
        const back = await call("restore_tracks", ids);
        if (back && back.crate) { syncLibrary(back); renderSmart(back.smart); refreshRekordboxSoon(); }
        $("#clean").querySelectorAll(".clean-row.gone").forEach(x => ids.includes(x.dataset.id) && x.classList.remove("gone"));
        b.hidden = false;
        toast(back && back.late ? `${back.restored} put back; ${back.late} are in the holding folder now - Settings, What changed puts them back.` : "All of them are back in your crate.", !!(back && back.late));
      }, 8000);
    });
  }
  $("#crate-clean").onclick = openClean;

  $("#update-check").addEventListener("change", async e => {
    state.settings = await call("set_setting", "update_check", e.target.checked);
    if (!e.target.checked) $("#update-note").hidden = true;
    renderSettings();
  });
  function formError(id, msg) { const e = $(id); e.textContent = msg || ""; e.hidden = !msg; }
  $("#name-form").addEventListener("submit", async e => {
    e.preventDefault();
    const r = await call("change_name", $("#name-pass").value, $("#new-name").value);
    $("#name-pass").value = "";
    if (!r.ok) return formError("#name-error", r.error);
    formError("#name-error", "");
    $("#new-name").value = "";
    state.dj = r.dj;
    $("#dj-name").textContent = r.dj;
    setWelcome(r.dj);
    toast(`DJ name changed to ${r.dj}`);
  });
  $("#pass-form").addEventListener("submit", async e => {
    e.preventDefault();
    const r = await call("change_password", $("#pass-current").value, $("#pass-new").value, $("#pass-confirm").value);
    ["#pass-current", "#pass-new", "#pass-confirm"].forEach(id => ($(id).value = ""));
    if (!r.ok) return formError("#pass-error", r.error);
    formError("#pass-error", "");
    toast("Password changed. Use the new one next time DJ Master opens.");
  });

  // ── chime ──────────────────────────────────────────────────────────────
  let audioCtx = null;
  addEventListener("pointerdown", () => {
    if (audioCtx) return;
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (err) { audioCtx = null; }
  }, { once: true, capture: true });
  function chime() {
    if (!audioCtx) return;
    audioCtx.resume && audioCtx.resume();
    const now = audioCtx.currentTime;
    [[659.3, 0], [987.8, 0.14]].forEach(([freq, at]) => {
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = "triangle";
      o.frequency.value = freq;
      g.gain.setValueAtTime(0, now + at);
      g.gain.linearRampToValueAtTime(0.14, now + at + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, now + at + 0.8);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(now + at); o.stop(now + at + 0.9);
    });
  }
  addEventListener("focus", () => { if (api) api.set_focus(true); if (loaded && state.settings.remote_enabled && !document.documentElement.classList.contains("locked")) refreshRemote().catch(() => {}); });
  addEventListener("blur", () => api && api.set_focus(false));

  // ── A gift from Yoshi C ────────────────────────────────────────────────
  // Free months given on Yoshi C's admin page arrive with the app's next key (onGift), and are shown once - after
  // the app is unlocked, never over the key or password screen. Closing the card is what remembers it.
  let giftShown = null;
  const giftReady = () => introDone && !document.documentElement.classList.contains("locked") && $("#trial").hidden;
  function showGift(g) {
    if (!g || giftShown === g.id) return;
    if (!giftReady()) { setTimeout(() => showGift(g), 1500); return; }
    giftShown = g.id;
    const from = g.from || "Yoshi C";
    const APPS = { djmaster: "DJ Master", stemsplitter: "Stem Splitter", all: "DJ Master and Stem Splitter" };
    const span = `${g.months} month${g.months === 1 ? "" : "s"}`;
    const wrap = el("div", "gift");
    wrap.setAttribute("role", "dialog"); wrap.setAttribute("aria-modal", "true"); wrap.setAttribute("aria-labelledby", "gift-line");
    const card = el("div", "gift-card");
    const bow = el("span", "gift-bow", "✦"); bow.setAttribute("aria-hidden", "true");
    const line = el("p", "gift-line", `You've received ${span} of ${APPS[g.plan] || "the app"} for free.`); line.id = "gift-line";
    card.append(bow, el("p", "gift-kicker", `A gift from ${from}`), line);
    if (g.note) card.append(el("p", "gift-note", `“${g.note}”`));
    const sign = el("p", "gift-sign"); sign.append("Sincerely,", el("br"), el("span", null, from));
    card.append(sign);
    // A date, always: free months run for months, even where a test run dates keys to the second.
    const until = String(g.until || "").includes("T") ? new Date(g.until).toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" }) : fmtDay(g.until);
    if (g.until) card.append(el("p", "gift-until", `Free until ${until}`));
    const ok = el("button", "btn-pill gift-ok", `Thanks, ${from}`); ok.type = "button";
    const close = () => {
      wrap.classList.remove("show"); setTimeout(() => wrap.remove(), 450);
      if (api) call("gift_seen", g.id);
    };
    ok.onclick = close;
    wrap.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); close(); } });
    card.append(ok);
    wrap.append(card);
    document.body.append(wrap);
    requestAnimationFrame(() => { wrap.classList.add("show"); ok.focus(); });
  }

  // ── the Set page ───────────────────────────────────────────────────────
  // A night, planned: tracks in an order, drawn as a line of energy and tempo, with any jump that will clash
  // marked. Sets are kept by the app (settings.json, and in every backup) and go to rekordbox and Serato as
  // playlists, in a Sets folder, a moment after they change.
  let sets = [], setId = null, setSaveTimer = 0, pagesTimer = 0;
  const currentSet = () => sets.find(x => x.id === setId) || null;
  const inSet = id => { const cur = currentSet(); return !!(cur && cur.tracks.includes(id)); };
  const energyOf = t => t.energy || t.energy_auto || null;
  // One track into the next: do the keys sit together, and is the tempo within the pitch fader's 8%?
  function hop(a, b) {
    if (!a || !b || a.gone || b.gone) return null;
    const rel = relation(a.camelot, b.camelot);
    const pct = a.bpm && b.bpm ? (b.bpm - a.bpm) / a.bpm * 100 : null;
    const keyText = !camelot(a.camelot) || !camelot(b.camelot) ? "key not read" : rel === 0 ? "same key" : rel === 1 ? "keys sit together" : rel === 2 ? "an energy lift" : "key jump";
    const keyBad = keyText === "key jump";
    const tempoBad = pct != null && Math.abs(pct) > 8;
    const tempoText = pct == null ? "tempo not read" : Math.abs(pct) < 0.05 ? "same tempo" : `${pct > 0 ? "+" : "−"}${Math.abs(pct).toFixed(1)}%${tempoBad ? " - past the fader" : ""}`;
    return { bad: keyBad || tempoBad, text: `${keyText} · ${tempoText}` };
  }
  function saveSetSoon() {
    clearTimeout(setSaveTimer);
    setSaveTimer = setTimeout(async () => {
      const cur = currentSet();
      if (!cur) return;
      const r = await call("set_save", cur);
      if (r && r.sets) { const mine = currentSet(); sets = r.sets.map(x => (mine && x.id === mine.id ? mine : x)); paintSetPick(); }
      refreshRekordboxSoon();
    }, 450);
  }
  async function newSet(name) {
    const day = new Date().toLocaleDateString([], { weekday: "long" });
    let fresh = name || `${day}'s set`;
    for (let n = 2; sets.some(x => x.name.toLowerCase() === fresh.toLowerCase()); n++) fresh = `${name || day + "'s set"} ${n}`;
    const r = await call("set_save", { name: fresh, minutes: 60, tracks: [] });
    if (!r || !r.sets) return null;
    sets = r.sets; setId = r.id;
    renderSet();
    return currentSet();
  }
  async function addToSet(ids) {
    ids = (ids || []).filter(Boolean);
    if (!ids.length) return;
    const cur = currentSet() || await newSet();
    if (!cur) return;
    const fresh = ids.filter(id => !cur.tracks.includes(id));
    cur.tracks.push(...fresh);
    saveSetSoon();
    renderSet();
    const skipped = ids.length - fresh.length;
    toastWithAction(fresh.length ? `${fresh.length} track${fresh.length === 1 ? "" : "s"} added to “${cur.name}”${skipped ? ` (${skipped} already in it)` : ""}.` : "Already in your set.",
      "Show the set", () => goToSection("set"), 6000);
  }
  function paintSetPick() {
    const pick = $("#set-pick");
    pick.hidden = sets.length < 2;
    pick.replaceChildren(...sets.map(x => { const o = document.createElement("option"); o.value = x.id; o.textContent = `${x.name} · ${x.tracks.length}`; o.selected = x.id === setId; return o; }));
    $("#set-delete").hidden = !currentSet();
  }
  function setChart(tracks) {
    const real = tracks.filter(t => !t.gone);
    const box = $("#set-chart");
    if (real.length < 2) { box.replaceChildren(el("p", "set-chart-none", real.length ? "Add another track and the night starts to draw itself." : "")); gfAfterRender(); return; }
    const cur = currentSet(), place = new Map(tracks.map((t, i) => [t, i]));    // each drawn track's place in the set
    const W = 640, Hh = 96, pad = 14;
    const total = real.reduce((n, t) => n + (t.length || 210), 0);
    let at = 0;
    const xs = real.map(t => { const x = pad + (at + (t.length || 210) / 2) / total * (W - pad * 2); at += t.length || 210; return x; });
    const bpms = real.map(t => t.bpm).filter(Boolean), lo = Math.min(...bpms), hi = Math.max(...bpms);
    const yE = e => Hh - pad - ((e || 5) - 1) / 9 * (Hh - pad * 2);
    const yB = b => (hi - lo < 0.5 ? Hh / 2 : Hh - pad - (b - lo) / (hi - lo) * (Hh - pad * 2));
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${Hh}`); svg.setAttribute("preserveAspectRatio", "none"); svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", "The set's energy and tempo, track by track");
    const line = (pts, cls) => { const p = document.createElementNS(SVG_NS, "polyline"); p.setAttribute("points", pts.map(q => q.join(",")).join(" ")); p.setAttribute("class", cls); svg.append(p); };
    if (bpms.length === real.length) line(real.map((t, i) => [xs[i].toFixed(1), yB(t.bpm).toFixed(1)]), "set-line tempo");
    line(real.map((t, i) => [xs[i].toFixed(1), yE(energyOf(t)).toFixed(1)]), "set-line energy");
    // The dots and the jump markers are drawn in the SVG; over them sit buttons, one per point, that open the fix box.
    const hits = el("div", "gf-hits");
    real.forEach((t, i) => {
      const at = place.get(t), hin = at ? gfHop(cur, tracks[at - 1], t) : null, hout = gfHop(cur, t, tracks[at + 1]);
      if (i && hin && hin.bad) {             // a jump between two tracks that sit next to each other in the set
        const mid = (xs[i - 1] + xs[i]) / 2, mark = document.createElementNS(SVG_NS, "line"), x = mid.toFixed(1);
        mark.setAttribute("x1", x); mark.setAttribute("x2", x); mark.setAttribute("y1", 4); mark.setAttribute("y2", Hh - 4); mark.setAttribute("class", "set-jump");
        svg.append(mark);
        hits.append(gfPoint("gf-jp", mid / W * 100, Hh / 2, `jump:${hin.pair}`,
          `Jump from track ${at} to track ${at + 1}: ${gfWhat(hin)}`,
          [`${at} → ${at + 1}`, `${tracks[at - 1].title || "Untitled"} into ${t.title || "Untitled"}`, gfWhat(hin, true)],
          { pick: at }));
      }
      const dot = document.createElementNS(SVG_NS, "circle");
      dot.setAttribute("cx", xs[i].toFixed(1)); dot.setAttribute("cy", yE(energyOf(t)).toFixed(1)); dot.setAttribute("r", 4.5);
      dot.setAttribute("fill", camColor(t.camelot)); dot.setAttribute("class", "set-dot");
      svg.append(dot);
      const bpm = t.bpm ? `${Math.round(t.bpm * 10) / 10} BPM` : "tempo not read", cam = t.camelot || "key not read";
      const wrong = [hin && hin.bad ? `${gfWhat(hin)} from track ${at}` : "", hout && hout.bad ? `${gfWhat(hout)} into track ${at + 2}` : ""].filter(Boolean);
      const meant = (hin && hin.ok) || (hout && hout.ok);
      const p = gfPoint("gf-pt" + (wrong.length ? " iffy" : ""), xs[i] / W * 100, yE(energyOf(t)), `dot:${t.id}`,
        `Track ${at + 1}, ${t.title || "Untitled"}, ${bpm}, ${cam}: ${wrong.length ? wrong.join("; ") : meant ? "a jump left as it is" : "sits well"}`,
        [`Track ${at + 1}`, t.title || "Untitled", `${bpm} · ${cam}${energyOf(t) ? ` · energy ${energyOf(t)}` : ""}`,
         wrong.length ? gfCap(wrong.join("; ")) : meant ? "A jump left as it is" : "Sits well"],
        { index: at, focus: "dot" });
      if (wrong.length) p.dataset.iffy = "1";
      hits.append(p);
    });
    const plot = el("div", "gf-plot");
    plot.append(svg, hits);
    const key = el("p", "set-key");
    key.append(el("span", "k-energy", "Energy"), el("span", "k-tempo", bpms.length === real.length ? `Tempo ${Math.round(lo)}–${Math.round(hi)} BPM` : "Tempo (some not read)"), el("span", "k-jump", "A jump to look at"),
               el("span", "k-click", "Click a point to fix it"));
    box.replaceChildren(plot, key);
    gfAfterRender();
  }

  // ── fixing the set from its graph ──────────────────────────────────────
  // Every dot, every jump marker and every iffy change in the list opens one small box anchored to it: what's wrong
  // in plain words, and a fix a click away - a better track in its place (set_fixes asks the crate), a better
  // place for it, a track to bridge the gap, out of the set, or "leave it", kept with the set as ok_jumps so a
  // jump meant that way stops counting. Each fix redraws the set and offers one Undo.
  let gf = null;                                 // the box that's open: {pop, anchor, key, index, id, setId, focus}
  const gfCap = s => s ? s[0].toUpperCase() + s.slice(1) : s;
  const gfBpm = b => b ? String(Math.round(b * 10) / 10) : "?";
  // hop(), plus what's off and whether this jump has been left as it is (then it doesn't count).
  function gfHop(cur, a, b) {
    const h = hop(a, b);
    if (!h) return null;
    const keyBad = !!(camelot(a.camelot) && camelot(b.camelot)) && relation(a.camelot, b.camelot) == null;
    const pct = a.bpm && b.bpm ? (b.bpm - a.bpm) / a.bpm * 100 : null;
    const pair = `${a.id}>${b.id}`;
    const ok = h.bad && !!(cur && (cur.ok_jumps || []).includes(pair));
    return { ...h, raw: h.bad, bad: h.bad && !ok, ok, keyBad, tempoBad: pct != null && Math.abs(pct) > 8, pct, pair };
  }
  const gfWhat = (h, cap) => { const s = h.keyBad && h.tempoBad ? "key jump and tempo past the fader" : h.keyBad ? "key jump" : h.tempoBad ? "tempo past the fader" : "sits well"; return cap ? gfCap(s) : s; };
  const gfCount = cur => { const ts = cur.tracks.map(id => state.crate.get(id) || { id, gone: true }); let n = 0; for (let i = 1; i < ts.length; i++) n += !!(gfHop(cur, ts[i - 1], ts[i]) || {}).bad; return n; };
  function gfPoint(cls, xPct, y, key, label, tip, o) {
    const b = el("button", cls);
    b.type = "button";
    b.style.left = `${xPct.toFixed(2)}%`; b.style.top = `${y.toFixed(1)}px`;
    b.dataset.gf = key;
    b.setAttribute("aria-label", label);
    b.setAttribute("aria-haspopup", "dialog");
    const show = () => { if (!gf) gfTip(b, tip); };
    b.addEventListener("pointerenter", show); b.addEventListener("focus", show);
    b.addEventListener("pointerleave", gfTipHide); b.addEventListener("blur", gfTipHide);
    b.onclick = () => (gf && gf.key === key ? gfClose(true) : gfOpen({ ...(o.pick != null ? gfPickAt(o.pick) : o), anchor: b, key }));
    return b;
  }
  // A change in the list: the same box as the jump on the graph, when there's something to look at.
  function gfHopRow(h, i) {
    if (!h.raw) return el("div", "set-hop", h.text);
    const b = el("button", "set-hop gf-hop " + (h.bad ? "bad" : "ok"), h.text + (h.ok ? " · left as it is" : ""));
    b.type = "button";
    b.dataset.gf = `row:${h.pair}`;
    b.setAttribute("aria-haspopup", "dialog");
    b.setAttribute("aria-label", `Change from track ${i} to track ${i + 1}: ${gfWhat(h)}${h.ok ? ", left as it is" : ""}. Show fixes`);
    b.onclick = () => (gf && gf.key === b.dataset.gf ? gfClose(true) : gfOpen({ ...gfPickAt(i), anchor: b, key: b.dataset.gf }));
    return b;
  }
  // A jump has two tracks: the box is about the one that's out of place - the one before it when that one's own
  // change in was iffy too and the one after sits well with what follows it, otherwise the one after.
  function gfPickAt(at) {
    const cur = currentSet(), t = i => (cur && cur.tracks[i] ? state.crate.get(cur.tracks[i]) || { id: cur.tracks[i], gone: true } : null);
    const before = gfHop(cur, t(at - 2), t(at - 1)), after = gfHop(cur, t(at), t(at + 1));
    return before && before.raw && !(after && after.raw) ? { index: at - 1, focus: "out" } : { index: at, focus: "in" };
  }
  // The small label that follows the pointer (or the keyboard) over the graph.
  let gfTipEl = null;
  function gfTip(anchor, lines) {
    if (!gfTipEl) { gfTipEl = el("div", "gf-tip"); gfTipEl.setAttribute("aria-hidden", "true"); document.body.append(gfTipEl); }
    gfTipEl.replaceChildren(el("span", "gf-label", lines[0]), el("b", null, lines[1]), el("span", null, lines[2]));
    if (lines[3]) gfTipEl.append(el("span", "gf-tip-say" + (anchor.dataset.iffy || anchor.classList.contains("gf-jp") ? " bad" : ""), lines[3]));
    gfTipEl.hidden = false;
    const r = anchor.getBoundingClientRect(), w = gfTipEl.offsetWidth, h = gfTipEl.offsetHeight;
    const left = Math.max(8, Math.min(innerWidth - w - 8, r.left + r.width / 2 - w / 2));
    const top = r.top - h - 10 < 8 ? r.bottom + 10 : r.top - h - 10;
    gfTipEl.style.left = `${left}px`; gfTipEl.style.top = `${top}px`;
  }
  function gfTipHide() { if (gfTipEl) gfTipEl.hidden = true; }

  async function gfOpen(o) {
    gfClose(false);
    gfTipHide();
    const cur = currentSet();
    if (!cur || !cur.tracks[o.index]) return;
    const pop = el("div", "gf-pop");
    pop.setAttribute("role", "dialog");
    pop.tabIndex = -1;
    const t = state.crate.get(cur.tracks[o.index]) || {};
    pop.setAttribute("aria-label", `Fix track ${o.index + 1}, ${t.title || "Untitled"}`);
    const wait = el("p", "gf-wait");
    wait.append(el("span", "spinner"), "Looking through your crate…");
    pop.append(gfHead(o.index, t), wait);
    pop.addEventListener("keydown", e => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); gfClose(true); } });
    document.body.append(pop);
    gf = { ...o, pop, id: cur.tracks[o.index], setId: cur.id, snap: cur.tracks.join("\n") };
    o.anchor.setAttribute("aria-expanded", "true");
    o.anchor.classList.add("gf-on");
    document.addEventListener("pointerdown", gfOutside, true);
    document.addEventListener("keydown", gfEsc, true);
    addEventListener("scroll", gfPlace, true);
    addEventListener("resize", gfPlace);
    gfPlace();
    pop.focus({ preventScroll: true });
    const r = await call("set_fixes", cur.tracks.slice(), o.index, (cur.ok_jumps || []).slice()).catch(() => null);
    if (!gf || gf.pop !== pop) return;
    if (!r || !r.ok) { wait.replaceChildren((r && r.error) || "Couldn't look just now."); return gfPlace(); }
    pop.replaceChildren(...gfBody(r, o, t));
    gfPlace();
    const first = pop.querySelector(".gf-opt, .gf-act");
    (first || pop).focus({ preventScroll: true });
  }
  function gfHead(index, t) {
    const head = el("div", "gf-head");
    const x = el("button", "gf-x", "×");
    x.type = "button"; x.setAttribute("aria-label", "Close");
    x.onclick = () => gfClose(true);
    head.append(el("span", "gf-label", [`Track ${index + 1}`, t.camelot, t.bpm ? `${gfBpm(t.bpm)} BPM` : ""].filter(Boolean).join(" · ")), x);
    const title = el("b", "gf-title", t.title || "Untitled");
    const wrap = el("div", "gf-top");
    wrap.append(head, title);
    return wrap;
  }
  function gfOption(c, extra, run) {
    const b = el("button", "gf-opt");
    b.type = "button";
    const cam = el("span", "cam", c.camelot || "—");
    cam.style.setProperty("--cam", camColor(c.camelot));
    const words = el("span", "gf-opt-t");
    words.append(el("b", null, c.title || "Untitled"), el("small", null, c.why));
    if (extra) words.append(el("span", "gf-clears" + (c.fixed ? " fixed" : ""), extra));
    b.append(cam, words);
    b.title = `${c.title}${c.artist ? " - " + c.artist : ""}`;
    b.onclick = run;
    return b;
  }
  function gfBody(r, o, t) {
    const out = [gfHead(r.index, t)];
    const sides = (o.focus === "dot" ? ["in", "out"] : [o.focus]).filter(s => r.hops[s] && r.hops[s].bad);
    const say = el("div", "gf-say");
    for (const s of sides) {
      const h = r.hops[s], other = s === "in" ? r.index : r.index + 2;
      const p = el("p");
      p.append(el("span", "gf-label", s === "in" ? `From track ${other}` : `Into track ${other}`));
      p.append(el("span", null, h.say.join(" ")));
      if (h.ok) p.append(el("span", "gf-meant", "Left as it is, so it isn't counted."));
      say.append(p);
    }
    if (!sides.length) say.append(el("p", null, "Sits well with the tracks either side."));
    out.push(say);
    const sec = (label, ...kids) => { const s = el("div", "gf-sec"); s.append(el("span", "gf-label", label), ...kids); out.push(s); };
    if (r.swaps.length) sec("Swap in a better track", ...r.swaps.map(c => gfOption(c, "", () => gfFix(r, cur => { cur.tracks[r.index] = c.id; },
      `“${c.title}” in for “${t.title}”.`))));
    else if (sides.length) sec("Swap in a better track", el("p", "gf-none", "Nothing in your crate sits with both tracks either side."));
    if (r.move) {
      const b = el("button", "gf-act");
      b.type = "button";
      b.append(el("span", null, r.move.where), el("small", null, `${r.move.now} → ${r.move.then} jump${r.move.then === 1 ? "" : "s"}`));
      b.onclick = () => gfFix(r, cur => { const [id] = cur.tracks.splice(r.index, 1); cur.tracks.splice(r.move.to, 0, id); }, `“${t.title}” moved.`);
      sec("Move it", b);
    }
    const side = sides.find(s => r.bridges[s] && r.bridges[s].length);
    if (side) {
      const at = side === "in" ? r.index : r.index + 1;
      sec(`Insert a bridge · between ${at} and ${at + 1}`, ...r.bridges[side].map(c => gfOption(c, c.clears + (c.left === 2 ? ". Counts as two jumps" : ""),
        () => gfFix(r, cur => { cur.tracks.splice(at, 0, c.id); }, `“${c.title}” put in as a bridge.`))));
    }
    const acts = el("div", "gf-acts");
    const act = (label, cls, run) => { const b = el("button", "gf-act " + cls, label); b.type = "button"; b.onclick = run; acts.append(b); };
    act("Remove it", "gf-remove", () => gfFix(r, cur => { cur.tracks.splice(r.index, 1); }, `“${t.title}” taken out of the set.`));
    const open = sides.filter(s => !r.hops[s].ok), meant = sides.filter(s => r.hops[s].ok);
    if (open.length) act("Leave it", "gf-leave", () => gfFix(r, cur => { cur.ok_jumps = [...(cur.ok_jumps || []), ...open.map(s => r.hops[s].pair)]; },
      open.length > 1 ? "Both jumps left as they are. They won't count." : "Left as it is. It won't count as a jump."));
    else if (meant.length) act("Count it again", "gf-leave", () => gfFix(r, cur => { const gone = new Set(meant.map(s => r.hops[s].pair)); cur.ok_jumps = (cur.ok_jumps || []).filter(p => !gone.has(p)); },
      "Counted as a jump again."));
    out.push(acts);
    return out;
  }
  // One fix: checked against the set as it is now, applied, saved, redrawn - and one Undo.
  function gfFix(r, change, said) {
    const cur = currentSet(), g = gf;
    if (!g || !cur || cur.id !== g.setId || cur.tracks.join("\n") !== g.snap || cur.tracks[r.index] !== r.id) {
      gfClose(false);
      return toast("The set changed while this was open. Click the point again.", true);
    }
    const before = { tracks: cur.tracks.slice(), ok: (cur.ok_jumps || []).slice() };
    change(cur);
    cur.tracks = cur.tracks.filter((id, i, all) => all.indexOf(id) === i);           // a track plays once in a set
    const have = new Set(cur.tracks);
    cur.ok_jumps = [...new Set(cur.ok_jumps || [])].filter(p => { const [a, b] = p.split(">"); return have.has(a) && have.has(b); });
    const near = cur.tracks.includes(r.id) ? r.id : cur.tracks[Math.min(r.index, cur.tracks.length - 1)];
    const back = near ? `dot:${near}` : null;              // the same track, or the one now in its place
    gfClose(false);
    saveSetSoon();
    renderSet();
    gfRefocus(back);
    const n = gfCount(cur);
    toastWithAction(`${said} ${n ? `${n} jump${n === 1 ? "" : "s"} to look at.` : "Every change sits well."}`, "Undo", () => {
      const s = sets.find(x => x.id === g.setId);
      if (!s) return;
      s.tracks = before.tracks; s.ok_jumps = before.ok;
      if (s === currentSet()) saveSetSoon(); else call("set_save", s).catch(() => {});
      renderSet();
      gfRefocus(`dot:${r.id}`);
    }, 10000);
  }
  function gfRefocus(key) {
    const to = (key && document.querySelector(`[data-gf="${CSS.escape(key)}"]`)) || $("#set-chart .gf-pt");
    if (to) to.focus({ preventScroll: true });
  }
  function gfClose(refocus) {
    if (!gf) return;
    const g = gf;
    gf = null;
    g.pop.remove();
    document.removeEventListener("pointerdown", gfOutside, true);
    document.removeEventListener("keydown", gfEsc, true);
    removeEventListener("scroll", gfPlace, true);
    removeEventListener("resize", gfPlace);
    const a = g.anchor.isConnected ? g.anchor : document.querySelector(`[data-gf="${CSS.escape(g.key)}"]`);
    if (a) { a.setAttribute("aria-expanded", "false"); a.classList.remove("gf-on"); }
    if (refocus && a) a.focus({ preventScroll: true });
  }
  function gfOutside(e) { if (gf && !gf.pop.contains(e.target) && !gf.anchor.contains(e.target)) gfClose(false); }
  function gfEsc(e) { if (gf && e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); gfClose(true); } }
  // The set redrew under an open box: follow its point to the new drawing - or, if the set itself changed (what the
  // box suggests was worked out for the set as it was), close it.
  function gfAfterRender() {
    if (!gf) return;
    const cur = currentSet();
    if (!cur || cur.id !== gf.setId || cur.tracks.join("\n") !== gf.snap) return gfClose(false);
    if (gf.anchor.isConnected) return;
    const a = document.querySelector(`[data-gf="${CSS.escape(gf.key)}"]`);
    if (!a) return gfClose(false);
    gf.anchor = a;
    a.setAttribute("aria-expanded", "true"); a.classList.add("gf-on");
    gfPlace();
  }
  function gfPlace() {
    if (!gf) return;
    const a = gf.anchor, p = gf.pop;
    if (!a.isConnected) return;
    const r = a.getBoundingClientRect(), w = p.offsetWidth, h = p.offsetHeight;
    const cx = a.classList.contains("gf-hop") ? r.left + Math.min(r.width / 2, 220) : r.left + r.width / 2;
    const left = Math.max(12, Math.min(innerWidth - w - 12, cx - w / 2));
    const below = r.bottom + 10, above = r.top - 10 - h;
    const up = below + h > innerHeight - 12 && above >= 12;
    p.style.left = `${left}px`;
    p.style.top = `${up ? above : Math.max(12, Math.min(below, innerHeight - h - 12))}px`;
    p.classList.toggle("up", up);
  }
  function songKey(title) {
    return String(title || "").toLowerCase()
      .replace(/[([{][^)\]}]*[)\]}]/g, " ")              // (Official Video), [Remastered], {DJ edit}
      .replace(/\b(feat|ft|featuring)\b.*$/, " ")
      .replace(/[^a-z0-9ऀ-ॿ]+/g, " ").trim();   // Devanagari titles keep their letters
  }
  let nextFor = null;
  async function setNext(tracks) {
    const box = $("#set-next");
    const last = [...tracks].reverse().find(t => !t.gone);
    if (!last) { box.hidden = true; return; }
    const stamp = nextFor = last.id + ":" + tracks.length;
    const hits = await call("crate_mixes", last.id);
    if (stamp !== nextFor) return;
    const have = new Set(tracks.map(t => t.id));
    // One idea per song: a crate with the same song in five folders offered it five times in a row, and offered the
    // song that's already in the set. Same song = the same title once brackets, "feat." and punctuation are gone.
    const seen = new Set(tracks.map(t => songKey(t.title)));
    const ideas = (hits || []).filter(m => {
      if (have.has(m.track.id) || !state.crate.has(m.track.id)) return false;
      const k = songKey(m.track.title);
      if (!k || seen.has(k)) return false;
      seen.add(k);
      return true;
    }).slice(0, 6);
    box.hidden = !ideas.length;
    if (!ideas.length) return;
    box.replaceChildren(el("span", "label", `After “${last.title}”`), ...ideas.map(m => {
      const b = el("button", "set-idea");
      b.type = "button";
      const cam = el("span", "cam", m.track.camelot || "—");
      cam.style.setProperty("--cam", camColor(m.track.camelot));
      b.append(cam, el("span", "t", m.track.title), el("span", "n", `${m.tempo.pct > 0 ? "+" : m.tempo.pct < 0 ? "−" : ""}${Math.abs(m.tempo.pct).toFixed(1)}%`));
      b.title = `Add ${m.track.title}${m.track.artist ? " - " + m.track.artist : ""}`;
      b.onclick = () => addToSet([m.track.id]);
      return b;
    }));
  }
  // ── what the set leans on, and more of it ─────────────────────────────
  // "Mostly Rawstyle (7 of 10)", worked out from each track's genre, and tracks from the crate that fit it: its own
  // niche first, then the ones next to it, in the set's tempo and with a key that sits with the last track. One
  // click adds one. The chips switch to another niche the set holds, or one next to it; Find more asks Apple's
  // catalogue, and the answer opens where a search does - so getting one works the way it always has.
  const setNiche = {};                          // set id -> a niche picked by hand, while the app is open
  let genreFor = null, genreTimer = 0;
  const genreSoon = () => { clearTimeout(genreTimer); genreTimer = setTimeout(() => { const cur = currentSet(); if (cur) setGenre(cur); }, 1500); };
  async function setGenre(cur) {
    const box = $("#set-genre");
    const ids = cur.tracks.filter(id => state.crate.has(id) && !state.crate.get(id).missing);
    if (!ids.length) { genreFor = null; box.hidden = true; return; }
    const stamp = genreFor = `${cur.id}:${ids.join(",")}:${setNiche[cur.id] || ""}:${ids.map(id => nicheKey(state.crate.get(id))).join(",")}:${state.crate.size}`;
    if (box.dataset.stamp === stamp) return;    // nothing that decides it has changed
    const r = await call("set_picks", ids, setNiche[cur.id] || null).catch(() => null);
    if (stamp !== genreFor || !r || !r.ok) return;
    box.dataset.stamp = stamp;
    box.hidden = false;
    box.replaceChildren(...genreBlock(r, {
      what: "This set",
      add: id => addToSet([id]),
      choose: k => { setNiche[cur.id] = k; setGenre(cur); },
      ids,
    }));
    measureSections();
  }
  function genreBlock(r, o) {
    const head = el("p", "sg-say");
    head.append(el("span", "label", "Genre"));
    if (!r.niche) {
      head.append(el("span", null, r.total && !r.known ? "No genre worked out for these tracks yet - it comes in on its own as they're read." : "No genre to go on yet."));
      return [head];
    }
    const top = r.found[0], byHand = !top || top.k !== r.niche;
    const say = el("span");
    if (byHand) say.append("Suggesting ", el("b", null, r.full), r.count ? ` · ${r.count} of ${r.total} in it already` : ` · none in it yet`);
    else say.append(`${o.what} is ${r.count * 2 >= r.total ? "mostly" : "leaning"} `, el("b", null, r.full), ` (${r.count} of ${r.total})`);
    if (r.bpm) say.append(` · ${r.bpm} BPM`);
    head.append(say);
    // The niches it holds, then the ones next to the one picked: a click suggests from that one instead.
    const chips = el("div", "sg-chips");
    chips.setAttribute("role", "group");
    chips.setAttribute("aria-label", "Suggest from");
    const seen = new Set();
    for (const c of [...r.found.map(f => ({ k: f.k, name: f.name, n: f.count })), ...r.near.map(x => ({ k: x.k, name: x.name }))]) {
      if (seen.has(c.k) || seen.size >= 7) continue;
      seen.add(c.k);
      const b = el("button", "sg-chip" + (c.k === r.niche ? " on" : ""), c.name);
      b.type = "button";
      b.setAttribute("aria-pressed", String(c.k === r.niche));
      b.title = c.n ? `${c.n} in it - suggest ${nicheName(c.k, true) || c.name}` : `Next to ${r.full} - suggest ${nicheName(c.k, true) || c.name}`;
      if (c.n) b.append(el("span", "n", String(c.n)));
      b.onclick = () => { if (c.k !== r.niche) o.choose(c.k); };
      chips.append(b);
    }
    const picks = el("div", "sg-picks");
    for (const p of r.picks) {
      const b = el("button", "set-idea");
      b.type = "button";
      const cam = el("span", "cam", p.camelot || "—");
      cam.style.setProperty("--cam", camColor(p.camelot));
      b.append(cam, el("span", "t", p.title), el("span", "n", p.bpm ? String(Math.round(p.bpm)) : "—"));
      b.title = `Add ${p.title}${p.artist ? " - " + p.artist : ""} · ${p.why}`;
      b.onclick = () => { b.disabled = true; o.add(p.id); };
      picks.append(b);
    }
    if (!r.picks.length) picks.append(el("span", "sg-none", `Nothing else in your crate reads as ${r.full}.`));
    const more = el("button", "btn-text sg-more", `Find more ${r.name}`);
    more.type = "button";
    more.title = shop() ? `${r.full} from Apple's catalogue, with where to buy each` : `${r.full} from Apple's catalogue, ready to get`;
    more.onclick = () => findMore(r.niche, o.ids, more);
    picks.append(more);
    return [head, chips, picks];
  }
  async function findMore(k, ids, b) {
    const was = b.textContent;
    b.disabled = true; b.textContent = "Looking…";
    const r = await call("set_find_more", k, ids).catch(() => null);
    b.disabled = false; b.textContent = was;
    if (!r || !r.ok) return toast((r && r.error) || "Couldn't look just now.", true);
    state.preview = r.info; state.pick = 0; state.selected = null; state.showAllVersions = false;
    renderPreview();
    const sec = $("#preview").closest("section");
    if (sec && sec.id) goToSection(sec.id);
  }
  function renderSet() {
    paintSetPick();
    sbRefresh();
    const cur = currentSet();
    $("#set-empty").hidden = !!cur;
    $("#set-body").hidden = !cur;
    if (!cur) return measureSections();
    if (document.activeElement !== $("#set-name")) $("#set-name").value = cur.name;
    fitName();
    if (document.activeElement !== $("#set-minutes")) $("#set-minutes").value = cur.minutes || "";
    const tracks = cur.tracks.map(id => state.crate.get(id) || { id, gone: true, title: "No longer in your crate" });
    const real = tracks.filter(t => !t.gone);
    const secs = real.reduce((n, t) => n + (t.length || 0), 0), mins = Math.round(secs / 60);
    let jumps = 0;
    const rows = [];
    tracks.forEach((t, i) => {
      if (i) {
        const h = gfHop(cur, tracks[i - 1], t);
        if (h) { jumps += h.bad; rows.push(gfHopRow(h, i)); }
      }
      const row = el("div", "set-row" + (t.gone ? " gone" : ""));
      row.setAttribute("role", "listitem");
      const who = el("div", "ct");
      const words = el("div", "ct-t");
      words.append(el("b", null, t.title || "Untitled"), el("small", null, t.gone ? "Take it out, or put the track back from What changed" : [t.artist, nicheName(nicheKey(t))].filter(Boolean).join(" · ")));
      if (t.gone) who.append(el("span", "cart blank"), words);
      else {
        const play = el("button", "cplay" + (playing.id === t.id ? " on" : ""));
        play.type = "button"; play.title = "Listen"; play.setAttribute("aria-label", `Listen to ${t.title}`);
        play.onclick = () => playTrack(t.id);
        who.append(keptCover("set:" + t.id, t, "cart"), words, play);
      }
      const cam = el("span", "cam", t.camelot || "—");
      cam.style.setProperty("--cam", camColor(t.camelot));
      const acts = el("span", "set-acts");
      const btn = (label, title, fn, off) => { const b = el("button", "set-btn", label); b.type = "button"; b.title = title; b.setAttribute("aria-label", title); b.disabled = !!off; b.onclick = fn; return b; };
      const move = d => { const ids = currentSet().tracks, j = i + d; [ids[i], ids[j]] = [ids[j], ids[i]]; saveSetSoon(); renderSet(); };
      acts.append(btn("↑", "Move up", () => move(-1), i === 0), btn("↓", "Move down", () => move(1), i === tracks.length - 1),
                  btn("×", "Take out of the set", () => { currentSet().tracks.splice(i, 1); saveSetSoon(); renderSet(); }));
      row.append(el("span", "set-n", String(i + 1)), who, el("span", "cn", t.bpm ? String(Math.round(t.bpm * 10) / 10) : "—"), cam,
                 el("span", "set-en", energyOf(t) ? `E${energyOf(t)}` : ""), el("span", "cl", t.gone ? "" : fmtLen(t.length)), acts);
      rows.push(row);
    });
    if (!tracks.length) rows.push(el("p", "set-none", "Nothing in this set yet. Search below, or add tracks from the crate."));
    $("#set-list").replaceChildren(...rows);
    const slot = cur.minutes || 0;
    const over = slot && mins > slot;
    $("#set-sum").textContent = [`${tracks.length} track${tracks.length === 1 ? "" : "s"}`, slot ? `about ${mins} min of ${slot}` : `about ${mins} min`,
      jumps ? `${jumps} jump${jumps === 1 ? "" : "s"} to look at` : real.length > 1 ? "every change sits well" : ""].filter(Boolean).join(" · ");
    $("#set-sum").classList.toggle("over", !!over);
    setChart(tracks);
    setNext(tracks);
    setGenre(cur);
    const rb = state.settings.rekordbox_enabled, se = state.settings.serato_enabled;
    $("#set-where").textContent = rb || se
      ? `In ${[rb ? "rekordbox" : "", se ? "Serato" : ""].filter(Boolean).join(" and ")} as “${cur.name}”, under Yoshi C's DJ Master › Sets, a moment after you change it${rb ? " (press reload in rekordbox)" : ""}.`
      : "Turn on DJ software sync and this set appears there as a playlist, in this order.";
    measureSections();
  }
  const nameIt = () => { const n = $("#set-name"); n.focus(); n.select(); };
  $("#set-start").onclick = () => newSet().then(nameIt);
  // New set on a set that's still empty would only make a second empty one: name the one you have instead.
  $("#set-new").onclick = () => { const cur = currentSet(); if (cur && !cur.tracks.length) return nameIt(); newSet().then(nameIt); };
  const fitName = () => { const n = $("#set-name"); n.size = Math.max(6, Math.min(40, (n.value || n.placeholder).length + 1)); };
  $("#set-name").addEventListener("input", fitName);
  $("#set-pick").onchange = e => { setId = e.target.value; renderSet(); };
  $("#set-name").addEventListener("input", e => { const cur = currentSet(); if (cur) { cur.name = e.target.value; saveSetSoon(); } });
  $("#set-name").addEventListener("change", renderSet);
  $("#set-minutes").addEventListener("input", e => { const cur = currentSet(); if (cur) { cur.minutes = +e.target.value || 0; saveSetSoon(); renderSet(); } });
  {
    const del = $("#set-delete");
    let armed = 0;
    const disarm = () => { clearTimeout(armed); armed = 0; del.classList.remove("arm"); del.textContent = "Delete this set"; };
    del.onclick = async () => {
      if (!armed) { del.classList.add("arm"); del.textContent = "Delete it — sure?"; armed = setTimeout(disarm, 5000); return; }
      disarm();
      const gone = currentSet();
      const r = await call("set_delete", setId);
      sets = (r && r.sets) || []; setId = sets.length ? sets[sets.length - 1].id : null;
      renderSet(); refreshRekordboxSoon();
      if (gone) toast(`“${gone.name}” deleted. Settings, What changed can bring it back.`);
    };
    // the box that adds a track by name
    const box = $("#set-search"), found = $("#set-found");
    let hits = [];
    const draw = () => {
      const q = box.value.trim().toLowerCase(), cur = currentSet();
      hits = q && cur ? [...state.crate.values()].filter(t => !t.missing && !cur.tracks.includes(t.id) && `${t.title} ${t.artist}`.toLowerCase().includes(q)).slice(0, 8) : [];
      found.hidden = !q;
      found.replaceChildren(...(hits.length ? hits.map(t => {
        const b = el("button", "set-hit");
        b.type = "button";
        const cam = el("span", "cam", t.camelot || "—");
        cam.style.setProperty("--cam", camColor(t.camelot));
        b.append(el("span", "t", `${t.title}${t.artist ? " - " + t.artist : ""}`), el("span", "n", t.bpm ? String(Math.round(t.bpm * 10) / 10) : "—"), cam);
        b.onclick = () => { addToSet([t.id]); box.value = ""; draw(); box.focus(); };
        return b;
      }) : [el("span", "set-nohit", "Nothing in your crate by that name.")]));
    };
    box.addEventListener("input", draw);
    box.addEventListener("keydown", e => { if (e.key === "Enter" && hits[0]) { e.preventDefault(); addToSet([hits[0].id]); box.value = ""; draw(); } if (e.key === "Escape") { box.value = ""; draw(); } });
  }
  // ── Add tracks by genre, and a set built to a length ───────────────────
  // Add tracks: the crate narrowed by genre (a parent opens its niches: Hardstyle › Rawstyle, Euphoric…), by tempo,
  // and to what mixes with the set's last track, with a count on every chip. Build a set: the slot, what to draw on
  // and the shape of the night go to setbuilder.py, and the answer is shown here first - nothing is kept until Save
  // as new set or Replace this set is pressed. `var`, not `let`: renderSet() can ask before this block has run.
  var sbOpen = "", sbAddPick = null, sbBuildPick = null, sbFrom = "", sbShape = "warmup", sbSeed = 0, sbResult = null, sbAsk = 0;
  const SB_SHAPES = [["warmup", "Warm up → peak", "warm-up"], ["peak", "Peak all the way", "peak"], ["peakcool", "Peak then cool down", "peak and cool-down"]];
  const sbWithin = (k, key) => (key === "?" ? !k : !!k && (k === key || k.startsWith(key + "/")));
  const sbLive = () => [...state.crate.values()].filter(t => !t.missing);
  // Tracks per chip: every niche, every parent (its niches and the tracks only known by the parent), and "?".
  function sbCounts(list) {
    const n = new Map();
    const up = k => n.set(k, (n.get(k) || 0) + 1);
    for (const t of list) {
      const k = nicheKey(t);
      if (!k) { up("?"); continue; }
      up(k);
      if (k.includes("/")) up(k.split("/")[0]);
    }
    return n;
  }
  // Parent chips, then a row of niche chips under each parent that's open. Several can be on at once.
  function sbGenres(pick, counts, redraw, noUnknown) {
    const box = el("div", "sb-genres");
    const row = el("div", "sb-row");
    row.append(el("span", "sb-lab", "Genre"));
    const chip = (key, name, n, on, part, fn, title) => {
      const b = el("button", "sg-chip" + (on ? " on" : part ? " part" : ""), name);
      b.type = "button";
      b.setAttribute("aria-pressed", String(!!on));
      if (title) b.title = title;
      b.append(el("span", "n", String(n || 0)));
      b.onclick = fn;
      return b;
    };
    const parents = genreTree.filter(p => counts.get(p.k)).sort((a, b) => counts.get(b.k) - counts.get(a.k));
    for (const p of parents) {
      const subsOn = p.subs.some(s => pick.keys.has(s.k));
      row.append(chip(p.k, p.name, counts.get(p.k), pick.keys.has(p.k), subsOn, () => {
        if (pick.keys.has(p.k) || subsOn) { pick.keys.delete(p.k); p.subs.forEach(s => pick.keys.delete(s.k)); pick.open.delete(p.k); }
        else { pick.keys.add(p.k); pick.open.add(p.k); }
        redraw();
      }, `All ${p.name}`));
    }
    if (counts.get("?") && !noUnknown) row.append(chip("?", "Unknown genre", counts.get("?"), pick.keys.has("?"), false, () => {
      pick.keys.has("?") ? pick.keys.delete("?") : pick.keys.add("?"); redraw();
    }, "Tracks the app hasn't worked a genre out for yet"));
    if (!parents.length && !counts.get("?")) row.append(el("span", "sg-none", "Nothing to pick from."));
    box.append(row);
    for (const p of parents) {
      if (!pick.open.has(p.k)) continue;
      const subs = p.subs.filter(s => counts.get(s.k));
      if (!subs.length) continue;
      const line = el("div", "sb-row sb-subs");
      line.setAttribute("aria-label", `${p.name}, narrowed`);
      for (const s of subs) line.append(chip(s.k, s.name, counts.get(s.k), pick.keys.has(s.k), false, () => {
        pick.keys.delete(p.k);                       // a niche narrows its parent
        pick.keys.has(s.k) ? pick.keys.delete(s.k) : pick.keys.add(s.k);
        redraw();
      }, s.full));
      box.append(line);
    }
    return box;
  }
  const sbLast = cur => [...(cur ? cur.tracks : [])].reverse().map(id => state.crate.get(id)).find(t => t && !t.missing) || null;
  const sbMixes = (last, t) => relation(last.camelot, t.camelot) != null && (!last.bpm || !t.bpm || Math.abs(t.bpm / last.bpm - 1) * 100 <= 8);
  function sbPanels() {
    $("#sb-add").hidden = sbOpen !== "add";
    $("#sb-build").hidden = sbOpen !== "build";
    $("#sb-open-add").setAttribute("aria-expanded", String(sbOpen === "add"));
    $("#sb-open-build").setAttribute("aria-expanded", String(sbOpen === "build"));
    $("#sb-open-add").classList.toggle("on", sbOpen === "add");
    $("#sb-open-build").classList.toggle("on", sbOpen === "build");
  }
  function sbRefresh() {
    if (!currentSet()) { sbOpen = ""; sbPanels(); return; }
    if (sbOpen === "add") sbDrawAdd();
    if (sbOpen === "build") sbDrawBuild();
  }
  // ── Add tracks
  function sbDrawAdd() {
    const panel = $("#sb-add"), cur = currentSet();
    if (!cur) return;
    sbAddPick = sbAddPick || { keys: new Set(), open: new Set() };
    if (!panel.dataset.built) {
      panel.dataset.built = "1";
      const tempo = el("div", "sb-row sb-tempo");
      const num = (id, label) => { const i = el("input", "sb-num"); i.type = "number"; i.min = "40"; i.max = "300"; i.step = "1"; i.id = id; i.placeholder = "—"; i.setAttribute("aria-label", label); i.addEventListener("input", sbDrawAdd); return i; };
      const mix = el("button", "sg-chip sb-mix", "Mixes with the last track");
      mix.type = "button"; mix.setAttribute("aria-pressed", "false");
      mix.title = "A key that sits with the set's last track, and a tempo within the fader of it";
      mix.onclick = () => { const on = mix.getAttribute("aria-pressed") !== "true"; mix.setAttribute("aria-pressed", String(on)); mix.classList.toggle("on", on); sbDrawAdd(); };
      tempo.append(el("span", "sb-lab", "Tempo"), num("sb-lo", "Lowest BPM"), el("span", "sb-dash", "–"), num("sb-hi", "Highest BPM"), el("span", "sb-unit", "BPM"), mix);
      panel.append(el("div", "sb-genre-slot"), tempo, el("p", "sb-say"), el("div", "sb-hits"));
    }
    const lo = parseFloat($("#sb-lo").value), hi = parseFloat($("#sb-hi").value);
    const mixBtn = panel.querySelector(".sb-mix"), last = sbLast(cur);
    mixBtn.disabled = !last;
    const mixOn = !!last && mixBtn.getAttribute("aria-pressed") === "true";
    const have = new Set(cur.tracks);
    const base = sbLive().filter(t => !have.has(t.id)
      && (!(lo > 0) || (t.bpm && t.bpm >= lo - 0.05)) && (!(hi > 0) || (t.bpm && t.bpm <= hi + 0.05))
      && (!mixOn || sbMixes(last, t)));
    const pick = sbAddPick;
    panel.querySelector(".sb-genre-slot").replaceChildren(sbGenres(pick, sbCounts(base), sbDrawAdd));
    const keys = [...pick.keys];
    const hits = keys.length ? base.filter(t => keys.some(k => sbWithin(nicheKey(t), k))) : base;
    if (mixOn) hits.sort((a, b) => (relation(last.camelot, a.camelot) - relation(last.camelot, b.camelot)) || (Math.abs((a.bpm || 0) - last.bpm) - Math.abs((b.bpm || 0) - last.bpm)));
    else hits.sort((a, b) => ((a.bpm || 999) - (b.bpm || 999)) || String(a.title).localeCompare(String(b.title)));
    const shown = hits.slice(0, 40);
    const say = panel.querySelector(".sb-say");
    say.replaceChildren(el("span", null, `${hits.length} track${hits.length === 1 ? "" : "s"}${hits.length > shown.length ? ` · the first ${shown.length} shown` : ""}${mixOn ? ` · mixing with “${last.title}”` : ""}`));
    if (shown.length > 1 && shown.length === hits.length) {
      const all = el("button", "btn-text sb-all", `Add all ${shown.length}`);
      all.type = "button";
      all.onclick = () => addToSet(shown.map(t => t.id));
      say.append(all);
    }
    panel.querySelector(".sb-hits").replaceChildren(...(shown.length ? shown.map(t => {
      const b = el("button", "set-hit");
      b.type = "button";
      const cam = el("span", "cam", t.camelot || "—");
      cam.style.setProperty("--cam", camColor(t.camelot));
      b.append(el("span", "t", `${t.title}${t.artist ? " - " + t.artist : ""}`), el("span", "n", t.bpm ? String(Math.round(t.bpm * 10) / 10) : "—"), cam);
      b.title = [`Add ${t.title}`, nicheName(nicheKey(t), true), energyOf(t) ? `energy ${energyOf(t)}` : ""].filter(Boolean).join(" · ");
      b.onclick = () => addToSet([t.id]);
      return b;
    }) : [el("span", "set-nohit", keys.length || lo || hi || mixOn ? "Nothing in your crate fits all of that." : "Everything in your crate is in this set.")]));
    measureSections();
  }
  // ── Build a set
  function sbDrawBuild() {
    const panel = $("#sb-build"), cur = currentSet();
    if (!cur) return;
    sbBuildPick = sbBuildPick || { keys: new Set(), open: new Set() };
    const known = cur.tracks.some(id => nicheKey(state.crate.get(id)));
    if (!sbFrom) sbFrom = known ? "match" : "all";
    if (sbFrom === "match" && !cur.tracks.length) sbFrom = "all";
    if (!panel.dataset.built) {
      panel.dataset.built = "1";
      const len = el("div", "sb-row");
      const mins = el("input", "sb-num");
      mins.type = "number"; mins.min = "10"; mins.max = "720"; mins.step = "5"; mins.id = "sb-minutes";
      mins.setAttribute("aria-label", "How long the set should run, in minutes");
      len.append(el("span", "sb-lab", "Length"), mins, el("span", "sb-unit", "min"));
      const go = el("button", "btn-pill small sb-go", "Build it");
      go.type = "button";
      go.onclick = () => sbBuild(0);
      panel.append(len, el("div", "sb-row sb-from"), el("div", "sb-genre-slot"), el("div", "sb-row sb-shape"), el("div", "sb-row sb-act"), el("div", "sb-out"));
      panel.querySelector(".sb-act").append(go);
    }
    const mins = $("#sb-minutes");
    if (panel.dataset.for !== cur.id) { panel.dataset.for = cur.id; delete mins.dataset.touched; }
    if (document.activeElement !== mins && !mins.dataset.touched) mins.value = cur.minutes || 60;
    mins.oninput = () => { mins.dataset.touched = "1"; };
    const choice = (label, on, fn, title, off) => {
      const b = el("button", "sg-chip" + (on ? " on" : ""), label);
      b.type = "button"; b.setAttribute("aria-pressed", String(on)); b.disabled = !!off;
      if (title) b.title = title;
      b.onclick = fn;
      return b;
    };
    const from = panel.querySelector(".sb-from");
    from.replaceChildren(el("span", "sb-lab", "From"),
      choice("Like this set", sbFrom === "match", () => { sbFrom = "match"; sbDrawBuild(); }, "The genres this set already leans on", !known),
      choice("Genres I pick", sbFrom === "pick", () => { sbFrom = "pick"; sbDrawBuild(); }),
      choice("Whole crate", sbFrom === "all", () => { sbFrom = "all"; sbDrawBuild(); }));
    panel.querySelector(".sb-genre-slot").replaceChildren(...(sbFrom === "pick" ? [sbGenres(sbBuildPick, sbCounts(sbLive().filter(t => t.bpm)), sbDrawBuild, true)] : []));
    panel.querySelector(".sb-shape").replaceChildren(el("span", "sb-lab", "Shape"),
      ...SB_SHAPES.map(([k, name]) => choice(name, sbShape === k, () => { sbShape = k; sbDrawBuild(); })));
    sbDrawResult();
    measureSections();
  }
  async function sbBuild(seed) {
    const cur = currentSet(), go = $("#sb-build .sb-go");
    if (!cur) return;
    sbSeed = seed;
    const ask = ++sbAsk;
    go.disabled = true; go.textContent = "Building…";
    const keys = [...(sbBuildPick ? sbBuildPick.keys : [])].filter(k => k !== "?");
    const r = await call("set_build", { set: cur.id, minutes: +$("#sb-minutes").value || cur.minutes || 60, from: sbFrom, genres: keys, shape: sbShape, seed })
      .catch(() => null);
    if (ask !== sbAsk) return;
    go.disabled = false; go.textContent = "Build it";
    if (!r || !r.ok) { sbResult = null; sbDrawResult(); return toast((r && r.error) || "Couldn't build a set just now.", true); }
    sbResult = r;
    sbDrawResult();
  }
  // The night as a line, as the set's own chart draws it: energy, tempo, and any change to look at.
  function sbChart(tracks) {
    const W = 640, Hh = 80, pad = 12;
    const total = tracks.reduce((n, t) => n + (t.length || 210), 0) || 1;
    let at = 0;
    const xs = tracks.map(t => { const x = pad + (at + (t.length || 210) / 2) / total * (W - pad * 2); at += t.length || 210; return x; });
    const bpms = tracks.map(t => t.bpm).filter(Boolean), lo = Math.min(...bpms), hi = Math.max(...bpms);
    const yE = e => Hh - pad - ((e || 5) - 1) / 9 * (Hh - pad * 2);
    const yB = b => (hi - lo < 0.5 ? Hh / 2 : Hh - pad - (b - lo) / (hi - lo) * (Hh - pad * 2));
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${Hh}`); svg.setAttribute("preserveAspectRatio", "none"); svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", "The built set's energy and tempo, track by track");
    const line = (pts, cls) => { const p = document.createElementNS(SVG_NS, "polyline"); p.setAttribute("points", pts.join(" ")); p.setAttribute("class", cls); svg.append(p); };
    if (bpms.length === tracks.length) line(tracks.map((t, i) => `${xs[i].toFixed(1)},${yB(t.bpm).toFixed(1)}`), "set-line tempo");
    line(tracks.map((t, i) => `${xs[i].toFixed(1)},${yE(energyOf(t)).toFixed(1)}`), "set-line energy");
    tracks.forEach((t, i) => {
      if (i && hop(tracks[i - 1], t)?.bad) {
        const m = document.createElementNS(SVG_NS, "line"), x = ((xs[i - 1] + xs[i]) / 2).toFixed(1);
        m.setAttribute("x1", x); m.setAttribute("x2", x); m.setAttribute("y1", 4); m.setAttribute("y2", Hh - 4); m.setAttribute("class", "set-jump");
        svg.append(m);
      }
      const dot = document.createElementNS(SVG_NS, "circle");
      dot.setAttribute("cx", xs[i].toFixed(1)); dot.setAttribute("cy", yE(energyOf(t)).toFixed(1)); dot.setAttribute("r", 4);
      dot.setAttribute("fill", camColor(t.camelot)); dot.setAttribute("class", "set-dot");
      const tip = document.createElementNS(SVG_NS, "title");
      tip.textContent = `${i + 1}. ${t.title} · ${t.camelot || "?"} · ${t.bpm ? Math.round(t.bpm * 10) / 10 : "?"} BPM · energy ${energyOf(t) || "?"}`;
      dot.append(tip);
      svg.append(dot);
    });
    const wrap = el("div", "set-chart sb-chart");
    const key = el("p", "set-key");
    key.append(el("span", "k-energy", "Energy"), el("span", "k-tempo", bpms.length ? `Tempo ${Math.round(lo)}–${Math.round(hi)} BPM` : "Tempo"), el("span", "k-jump", "A jump to look at"));
    wrap.append(svg, key);
    return wrap;
  }
  function sbDrawResult() {
    const out = $("#sb-build .sb-out"), cur = currentSet();
    if (!out) return;
    const r = sbResult;
    const tracks = r ? r.ids.map(id => state.crate.get(id)).filter(t => t && !t.missing) : [];
    if (!r || !cur || !tracks.length) { out.replaceChildren(); return; }
    const secs = tracks.reduce((n, t) => n + (t.length || 210), 0);
    const jumps = tracks.reduce((n, t, i) => n + (i && hop(tracks[i - 1], t)?.bad ? 1 : 0), 0);
    const shape = SB_SHAPES.find(s => s[0] === r.shape) || SB_SHAPES[0];
    const say = el("p", "sb-say");
    say.append(el("b", null, `${tracks.length} tracks · ${Math.round(secs / 60)} min of ${r.minutes}`),
      ` · ${r.names || "the whole crate"} · ${shape[1]} · ${jumps ? `${jumps} jump${jumps === 1 ? "" : "s"} to look at` : "every change sits well"}`);
    const guessed = tracks.filter(t => !(t.length > 0)).length;
    if (guessed) say.append(` · ${guessed} length${guessed === 1 ? "" : "s"} not read, counted as 3½ min`);
    const parts = [say];
    if (r.note) parts.push(el("p", "sb-note", r.note));
    parts.push(sbChart(tracks));
    const list = el("ol", "sb-list");
    tracks.forEach((t, i) => {
      const li = el("li", "sb-li" + (i && hop(tracks[i - 1], t)?.bad ? " bad" : ""));
      const cam = el("span", "cam", t.camelot || "—");
      cam.style.setProperty("--cam", camColor(t.camelot));
      const words = el("span", "sb-t");
      words.append(el("b", null, t.title || "Untitled"), el("small", null, [t.artist, nicheName(nicheKey(t))].filter(Boolean).join(" · ")));
      li.append(el("span", "set-n", String(i + 1)), words, el("span", "sb-m", t.bpm ? String(Math.round(t.bpm * 10) / 10) : "—"), cam,
                el("span", "sb-m", energyOf(t) ? `E${energyOf(t)}` : ""), el("span", "sb-m", fmtLen(t.length)));
      if (i) li.title = hop(tracks[i - 1], t)?.text || "";
      list.append(li);
    });
    parts.push(list);
    const acts = el("div", "sb-row sb-keep");
    const again = el("button", "btn-text", "Try another");
    again.type = "button"; again.title = "The same choices, worked out another way";
    again.onclick = () => sbBuild(sbSeed + 1);
    const save = el("button", "btn-pill small", "Save as new set");
    save.type = "button";
    save.onclick = () => sbKeep(false, tracks, r);
    const swap = el("button", "btn-outline small", cur.tracks.length ? "Replace this set" : "Use in this set");
    swap.type = "button";
    swap.title = cur.tracks.length ? `Put these in place of the ${cur.tracks.length} track${cur.tracks.length === 1 ? "" : "s"} in “${cur.name}”. Undo brings them back.` : `Put these in “${cur.name}”`;
    swap.onclick = () => sbKeep(true, tracks, r);
    acts.append(save, swap, again);
    parts.push(acts);
    out.replaceChildren(...parts);
  }
  async function sbKeep(replace, tracks, r) {
    const ids = tracks.map(t => t.id), cur = currentSet();
    if (!cur) return;
    if (replace) {
      clearTimeout(setSaveTimer);
      await call("set_save", cur).catch(() => null);         // a rename still on its way goes first
      const res = await call("set_replace", cur.id, ids, r.minutes).catch(() => null);
      if (!res || !res.ok) return toast((res && res.error) || "Couldn't change the set just now.", true);
      sets = res.sets; setId = res.id || cur.id;
      sbResult = null; sbOpen = ""; sbPanels();
      renderSet(); refreshRekordboxSoon();
      if (res.change) toastWithAction(`“${cur.name}” rebuilt: ${ids.length} tracks.`, "Undo", async () => {
        const u = await call("change_undo", res.change).catch(() => null);
        if (u && u.sets) { sets = u.sets; renderSet(); refreshRekordboxSoon(); toast(`“${cur.name}” is back as it was.`); }
      }, 10000);
      else toast(`${ids.length} tracks in “${cur.name}”.`);
      return;
    }
    const shape = (SB_SHAPES.find(s => s[0] === r.shape) || SB_SHAPES[0])[2];
    const stem = `${r.names || "Crate"} ${shape}`.slice(0, 54);
    let name = stem;
    for (let n = 2; sets.some(x => x.name.toLowerCase() === name.toLowerCase()); n++) name = `${stem} ${n}`;
    const res = await call("set_save", { name, minutes: r.minutes, tracks: ids }).catch(() => null);
    if (!res || !res.sets) return toast("Couldn't save the set just now.", true);
    sets = res.sets; setId = res.id;
    sbResult = null; sbOpen = ""; sbPanels();
    renderSet(); refreshRekordboxSoon();
    toast(`Saved as “${name}”.`);
  }
  $("#sb-open-add").onclick = () => { sbOpen = sbOpen === "add" ? "" : "add"; sbPanels(); sbRefresh(); };
  $("#sb-open-build").onclick = () => { sbOpen = sbOpen === "build" ? "" : "build"; sbPanels(); sbRefresh(); };
  $("#sb-start").onclick = () => newSet().then(cur => { if (!cur) return; sbOpen = "build"; sbPanels(); sbRefresh(); });
  // ── Gigs: the client's songs before the night ───────────────────────────────────────────────────────────
  // Kept on the licence server (the client's link has to work while this computer is off), so the page asks for
  // them when it's first looked at, and again when "Check for changes" is pressed. Without a subscription key the
  // page says so and nothing is asked.
  let gigs = null, gigOpen = {};
  const gigDownloadTracks = new Map();
  async function gigFlushSetSaves() {
    if (typeof flushSetSaves === "function") return flushSetSaves();
    clearTimeout(setSaveTimer);
    const cur = currentSet();
    if (!cur) return true;
    const r = await call("set_save", cur).catch(() => null);
    if (!r?.sets) { toast("Couldn't save your current set. Try again.", true); return false; }
    return true;
  }
  const gigDay = (d) => { if (!d) return "No date yet"; const x = new Date(d + "T12:00:00"); return isNaN(x) ? d : x.toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" }); };
  function renderGigs(r) {
    const list = $("#gig-list"), err = $("#gigs-err");
    if (!list) return;
    const locked = !!(r && r.off), failed = !!(r && !r.ok && !locked);
    $("#gigs-off").hidden = !locked;
    if (locked) gigsLocked(r);
    err.hidden = !failed; err.textContent = failed ? r.error : "";
    $("#gig-new").hidden = locked;
    $("#gigs-refresh").hidden = locked;
    $("#gigs-start").hidden = locked;
    if (!r || !r.ok) { if (locked) list.replaceChildren(); return; }
    gigs = r.gigs;
    list.replaceChildren(...(gigs.length ? gigs.map(gigCard) : [gigsEmpty()]));
  }
  // Locked: why gigs need a subscription key, and where to put one. `why` is from app.py's _gigs.
  function gigsLocked(r) {
    $("#gigs-off-why").textContent = "Gigs live on DJ Master's licence server, not on this computer, so your client's link keeps working while your computer is off. That's why they need a subscription key.";
    $("#gigs-off-do").textContent = r.why === "server"
      ? "Gigs aren't switched on for this copy yet. Nothing is wrong with it - everything else works as normal, and gigs turn on with an update."
      : r.why === "trial"
        ? "You're on the free trial, which has no key. Paste a subscription key in Settings, under Activation, and gigs open here straight away."
        : "The key on this computer isn't a subscription key. Paste a subscription key in Settings, under Activation, and gigs open here straight away.";
    const go = $("#gigs-off-go"), btn = (cls, text, run) => { const b = el("button", cls, text); b.type = "button"; b.onclick = run; return b; };
    go.replaceChildren();
    // "server": nothing the DJ can do here, so no button that suggests there is.
    if (r.why !== "server") go.append(btn("btn-outline small", "Enter a subscription key", () => { $("#lic-key-form").hidden = false; openSettings("activation", "#lic-key"); }));
    if (r.site) go.append(btn("btn-text", "See plans", () => call("open_site", "/pricing/")));
  }
  function gigsEmpty() {
    const box = el("div", "gig-empty");
    const go = el("button", "btn-outline small", "Make your first gig"); go.type = "button"; go.onclick = focusNewGig;
    box.append(el("b", null, "No gigs yet"),
      el("p", null, "Start with New gig above: whose night it is and the date. Then copy the link it gives you and send it to your client."), go);
    return box;
  }
  function focusNewGig() {
    const form = $("#gig-new");
    if (form.hidden) return;
    if ($("#main").contains(form)) window.YCS.into(form, "center");      // switches to Gigs first with pro.css
    else form.scrollIntoView({ block: "center", behavior: REDUCED ? "auto" : "smooth" });
    $("#gig-title").focus({ preventScroll: true });
    form.classList.remove("lit"); void form.offsetWidth; form.classList.add("lit");
  }
  function gigCard(g) {
    const card = el("div", "gig" + (g.closed ? " closed" : ""));
    const top = el("div", "gig-top"), words = el("div", "gig-words");
    words.append(el("b", "gig-name", g.title), el("span", "gig-when", gigDay(g.date)));
    const counts = el("span", "gig-counts");
    counts.append(el("b", null, String(g.must)), " must play · ", el("b", null, String(g.never)), " do not play" + (g.closed ? " · closed" : ""));
    top.append(words, counts);
    const acts = el("div", "gig-acts"), songs = el("div", "gig-songs"); songs.hidden = true;
    const btn = (cls, text, run) => { const b = el("button", cls, text); b.type = "button"; b.onclick = () => run(b); return b; };
    acts.append(
      btn("btn-pill small", "Copy their link", async () => { try { await navigator.clipboard.writeText(g.link); toast("Link copied. Send it to them - they add their songs on their phone."); } catch { toast("Couldn't copy it: " + g.link, true, 9000); } }),
      btn("btn-outline small", "See their songs", async (b) => { if (!songs.hidden) { songs.hidden = true; b.textContent = "See their songs"; gigOpen[g.id] = false; return; } b.disabled = true; const r = await call("gig_get", g.id).catch(() => null); b.disabled = false;
        if (!r || !r.ok) return toast((r && r.error) || "Couldn't fetch their songs.", true); gigSongs(songs, r.gig); songs.hidden = false; b.textContent = "Hide their songs"; gigOpen[g.id] = true; }),
      btn("btn-text", g.closed ? "Open the list again" : "Close the list", async () => { const r = await call("gig_close", g.id, !g.closed).catch(() => null); if (!r || !r.ok) return toast((r && r.error) || "That didn't go through.", true);
        toast(g.closed ? "Open again - they can change their songs." : "Closed - they can still read it, but not change it."); loadGigs(); }),
      btn("btn-text gig-del", "Delete", async (b) => { if (b.dataset.sure !== "1") { b.dataset.sure = "1"; b.textContent = "Delete it and its songs?"; setTimeout(() => { b.dataset.sure = ""; b.textContent = "Delete"; }, 4000); return; }
        const r = await call("gig_delete", g.id).catch(() => null); if (!r || !r.ok) return toast((r && r.error) || "That didn't go through.", true); toast("Gig deleted. Their link no longer works."); loadGigs(); }));
    card.append(top, acts, songs);
    if (gigOpen[g.id]) acts.children[1].click();
    return card;
  }
  function gigSongs(box, gig) {
    async function queueMust(download, songId = null) {
        if (!await gigFlushSetSaves()) return;
        download.disabled = true;
        const r = await (songId === null ? call("gig_download", gig.id) : call("gig_download", gig.id, songId)).catch(() => null);
        download.disabled = false;
        if (!r?.ok) return toast(r?.error || "Couldn't queue their songs. Try again.", true);
        sets = r.sets;
        const target = sets.find(s => s.id === r.set);
        for (const id of gigDownloadTracks.get(r.set) || []) if (target && !target.tracks.includes(id)) target.tracks.push(id);
        setId = r.set; renderSet(); refreshRekordboxSoon();
        toast(`“${r.name}”: ${r.have} already in your crate, ${r.queued} queued${r.waiting ? `, ${r.waiting} already downloading` : ""}. Downloads join the set as they finish.`, false, 9000);
      if (songId !== null) { download.disabled = true; download.textContent = "Queued"; }
    }

    const row = (s, must) => { const li = el("li", "gsong" + (must ? (s.track ? " have" : " want") : ""));
      const words = el("div", "gsong-words"); words.append(el("b", null, s.title)); if (s.artist) words.append(el("span", null, s.artist)); if (s.note) words.append(el("small", null, s.note));
      li.append(words);
      if (must) { const side = el("div", "gsong-side");
        if (s.track) side.append(el("span", "gsong-ok", "In your crate"), el("span", "gsong-facts", [s.track.bpm ? s.track.bpm + " BPM" : "", s.track.camelot || ""].filter(Boolean).join(" · ")));
        else {
          side.append(el("span", "gsong-no", "Not in your crate"));
          if (boot.fetch === true) {
            const download = el("button", "btn-outline small", "Download to crate");
            download.type = "button";
            download.onclick = () => queueMust(download, s.id);
            side.append(download);
          } else (s.buy || []).slice(0, 3).forEach(x => { const a = el("button", "btn-text", x.name); a.type = "button"; a.onclick = () => call("open_shop", x.url); side.append(a); });
        }
        li.append(side); }
      return li; };
    const must = el("ul", "gsongs"), never = el("ul", "gsongs");
    must.append(...gig.must.map(s => row(s, true))); never.append(...gig.never.map(s => row(s, false)));
    const tools = el("div", "gig-tools");
    const make = el("button", "btn-pill small", `Make it a set (${gig.have})`); make.type = "button"; make.disabled = !gig.have;
    make.onclick = async () => { const r = await call("gig_to_set", gig.id).catch(() => null); if (!r || !r.ok) return toast((r && r.error) || "That didn't go through.", true);
      sets = r.sets; setId = r.set; renderSet(); toast(`“${gig.title}” is a set of ${r.count} track${r.count === 1 ? "" : "s"}${r.missing ? ` - ${r.missing} still to find` : ""}.`); };
    const dnp = el("button", "btn-outline small", "Add these to my do-not-play list"); dnp.type = "button"; dnp.hidden = !gig.never.length;
    dnp.onclick = async () => { const r = await call("gig_dnp", gig.id).catch(() => null); if (!r || !r.ok) return toast((r && r.error) || "That didn't go through.", true);
      toast(r.added ? `${r.added} added - the request page will turn those down on the night.` : "They were all on it already."); };
    tools.append(make, dnp);
    if (boot.fetch === true) {
      const download = el("button", "btn-outline small", gig.missing ? `Download missing must-plays (${gig.missing})` : "Save must haves set");
      download.type = "button"; download.disabled = !gig.must.length;
      download.onclick = () => queueMust(download);
      tools.append(download);
    }
    // What their must-plays lean on, and tracks from the crate in the same niche - each goes into the gig's set.
    const genre = el("div", "set-genre gig-genre"); genre.hidden = true;
    const ids = gig.must.filter(s => s.track).map(s => s.track.id);
    if (ids.length) gigGenre(genre, gig, ids, null);
    box.replaceChildren(
      el("p", "gsongs-h", `Must play · ${gig.have} in your crate${gig.missing ? `, ${gig.missing} to find` : ""}`), gig.must.length ? must : el("p", "gig-none", "They haven't added any yet."),
      genre,
      el("p", "gsongs-h", "Do not play"), gig.never.length ? never : el("p", "gig-none", "Nothing on it."), tools);
  }
  async function gigGenre(box, gig, ids, niche) {
    const r = await call("set_picks", ids, niche).catch(() => null);
    if (!r || !r.ok || !r.niche) { box.hidden = true; return; }
    box.hidden = false;
    box.replaceChildren(...genreBlock(r, { what: "Their must-play list", add: id => addToGigSet(gig, id), choose: k => gigGenre(box, gig, ids, k), ids }));
  }
  // Into the gig's own set (Make it a set), made first if it isn't there yet.
  async function addToGigSet(gig, id) {
    let mine = sets.find(x => x.id === "gig-" + gig.id);
    if (!mine) {
      const r = await call("gig_to_set", gig.id).catch(() => null);
      if (!r || !r.ok) return toast((r && r.error) || "That didn't go through.", true);
      sets = r.sets; mine = sets.find(x => x.id === r.set);
      if (!mine) return;
    }
    setId = mine.id;
    addToSet([id]);
  }
  // Only the latest request may render: activation can change access while an older request is pending.
  let gigsRequest = 0;
  async function loadGigs() {
    const request = ++gigsRequest;
    const r = await call("gigs_list").catch(() => null);
    if (request !== gigsRequest) return;
    renderGigs(r || { ok: false, error: "Couldn't reach your gigs just now - check the internet and try again." });
  }
  (function gigsPage() {
    const sec = document.getElementById("gigs"); if (!sec) return;
    let asked = false;
    new IntersectionObserver((es) => { if (es.some(e => e.isIntersecting) && !asked) { asked = true; loadGigs(); } }, { threshold: 0.15 }).observe(sec);
    $("#gigs-refresh").addEventListener("click", () => { loadGigs().then(() => toast("Up to date.")); });
    $("#gigs-start").addEventListener("click", focusNewGig);
    $("#gig-new").addEventListener("submit", async (e) => { e.preventDefault(); const title = $("#gig-title").value.trim(); if (!title) return;
      const b = e.target.querySelector("button"); b.disabled = true; const r = await call("gig_create", title, $("#gig-date").value).catch(() => null); b.disabled = false;
      if (!r || !r.ok) return toast((r && r.error) || "That didn't go through.", true);
      e.target.reset(); toast("Gig made. Copy their link and send it to them."); loadGigs(); });
  })();

  function loadSets() {
    return call("sets_list").then(list => {
      if (!Array.isArray(list)) return;
      sets = list;
      if (!currentSet()) setId = sets.length ? sets[sets.length - 1].id : null;
      renderSet();
    }).catch(() => {});
  }

  // ── Insights ───────────────────────────────────────────────────────────
  // The crate read back: how many tracks sit in each key, where the tempos bunch up, and the gaps worth filling.
  // Every number is already in the crate - nothing is measured for this.
  function renderInsights() {
    const all = [...state.crate.values()].filter(t => !t.missing);
    const gone = state.crate.size - all.length;
    const box = $("#ins");
    // Say why this is fewer than the crate count in the top bar: the tracks whose files have gone aren't counted.
    // A crate of 3,369 read here as "from the 2,568 tracks in your crate" with no reason given.
    $("#ins-note").textContent = !all.length ? "" : gone
      ? `From the ${all.length.toLocaleString("en")} tracks whose files are here. ${gone.toLocaleString("en")} more ${gone === 1 ? "is" : "are"} missing - Clean up finds ${gone === 1 ? "it" : "them"}.`
      : `From the ${all.length.toLocaleString("en")} track${all.length === 1 ? "" : "s"} in your crate`;
    if (!all.length) { box.replaceChildren(el("p", "ins-none", "Nothing to read yet. Once there are tracks in your crate, this page shows which keys and tempos you have plenty of, and where the gaps are.")); return; }
    const tile = (cls, label) => { const t = el("div", "ins-tile " + cls); t.append(el("span", "label", label)); return t; };
    // keys
    const keyCount = {};
    all.forEach(t => { const c = camelot(t.camelot); if (c) keyCount[c.n + c.l] = (keyCount[c.n + c.l] || 0) + 1; });
    const most = Math.max(1, ...Object.values(keyCount));
    const keys = tile("t-keys", "Tracks in each key");
    // The Camelot wheel, each key shaded by how many tracks it holds (glass redesign: it was a 24-cell grid). Same
    // geometry as the crate's wheel (drawWheel); a tap opens the crate filtered to that key, as the grid did.
    const NS = "http://www.w3.org/2000/svg";
    const grid = document.createElementNS(NS, "svg");
    grid.setAttribute("viewBox", "-118 -118 236 236");
    grid.setAttribute("class", "ins-wheel");
    grid.setAttribute("role", "group");
    grid.setAttribute("aria-label", "Tracks in each key, on the Camelot wheel");
    const arcP = (r0, r1, a0, a1) => {
      const pt = (r, a) => [r * Math.sin(a), -r * Math.cos(a)];
      const [x0, y0] = pt(r1, a0), [x1, y1] = pt(r1, a1), [x2, y2] = pt(r0, a1), [x3, y3] = pt(r0, a0);
      return `M${x0} ${y0}A${r1} ${r1} 0 0 1 ${x1} ${y1}L${x2} ${y2}A${r0} ${r0} 0 0 0 ${x3} ${y3}Z`;
    };
    for (let n = 1; n <= 12; n++) [["B", 76, 114], ["A", 38, 74]].forEach(([l, r0, r1]) => {
      const code = n + l, c = keyCount[code] || 0;
      const a0 = ((n - 1) / 12) * Math.PI * 2 - Math.PI / 12 + 0.014, a1 = (n / 12) * Math.PI * 2 - Math.PI / 12 - 0.014;
      const seg = document.createElementNS(NS, "path");
      seg.setAttribute("d", arcP(r0, r1, a0, a1));
      seg.setAttribute("class", "iw-seg" + (c ? "" : " none"));
      seg.style.setProperty("--c", camColor(code));
      seg.style.setProperty("--fill", String(c ? 0.22 + 0.78 * c / most : 0.05));
      seg.setAttribute("tabindex", "0"); seg.setAttribute("role", "button");
      seg.setAttribute("aria-label", `${c} track${c === 1 ? "" : "s"} in ${code} - show them`);
      const ttl = document.createElementNS(NS, "title"); ttl.textContent = `${code}: ${c} track${c === 1 ? "" : "s"}`; seg.append(ttl);
      const go = () => { keySelect.value = code; keySelect.dispatchEvent(new Event("change")); goToSection("crate"); };
      seg.addEventListener("click", go);
      seg.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
      grid.append(seg);
      const mid = (a0 + a1) / 2, rt = (r0 + r1) / 2;
      [[code, -4, "iw-code"], [String(c), 8, "iw-n"]].forEach(([txt, dy, cls]) => {
        const t = document.createElementNS(NS, "text");
        t.setAttribute("x", (rt * Math.sin(mid)).toFixed(1)); t.setAttribute("y", (-rt * Math.cos(mid) + dy).toFixed(1));
        t.setAttribute("class", cls); t.textContent = txt; grid.append(t);
      });
    });
    const hub = document.createElementNS(NS, "text");
    hub.setAttribute("y", "5"); hub.setAttribute("class", "iw-hub"); hub.textContent = all.length.toLocaleString("en");
    grid.append(hub);
    keys.append(grid);
    // tempo
    const withBpm = all.filter(t => t.bpm);
    const tempo = tile("t-tempo", "Tempo");
    if (withBpm.length) {
      const step = 5, lo = Math.floor(Math.min(...withBpm.map(t => t.bpm)) / step) * step, hi = Math.ceil((Math.max(...withBpm.map(t => t.bpm)) + 0.01) / step) * step;
      const n = Math.max(1, Math.min(40, (hi - lo) / step)), bins = new Array(n).fill(0);
      withBpm.forEach(t => { bins[Math.min(n - 1, Math.floor((t.bpm - lo) / step))]++; });
      const top = Math.max(...bins), peak = bins.indexOf(top);
      const bars = el("div", "ins-bars");
      bins.forEach((c, i) => { const b = el("i"); b.style.height = `${Math.max(c ? 6 : 1, c / top * 100)}%`; b.title = `${lo + i * step}–${lo + (i + 1) * step} BPM: ${c}`; if (i === peak) b.className = "peak"; bars.append(b); });
      const ends = el("div", "ins-ends"); ends.append(el("span", null, String(lo)), el("span", null, String(hi)));
      tempo.append(bars, ends, el("p", "ins-say", `Most between ${lo + peak * step} and ${lo + (peak + 1) * step} BPM`));
    } else tempo.append(el("p", "ins-say", "No tempos read yet."));
    // energy
    const energy = tile("t-energy", "Energy");
    const eb = new Array(10).fill(0);
    all.forEach(t => { const e = energyOf(t); if (e) eb[Math.max(1, Math.min(10, e)) - 1]++; });
    if (eb.some(Boolean)) {
      const top = Math.max(...eb), bars = el("div", "ins-bars");
      eb.forEach((c, i) => { const b = el("i"); b.style.height = `${Math.max(c ? 6 : 1, c / top * 100)}%`; b.title = `Energy ${i + 1}: ${c}`; bars.append(b); });
      const ends = el("div", "ins-ends"); ends.append(el("span", null, "1"), el("span", null, "10"));
      energy.append(bars, ends);
    } else energy.append(el("p", "ins-say", "No energy readings yet."));
    // the numbers
    const num = (label, n, say, go) => { const t = tile("t-num", label); t.append(el("span", "fig", n.toLocaleString("en")), el("p", "ins-say", say)); if (go && n) { t.classList.add("t-go"); t.tabIndex = 0; t.setAttribute("role", "button"); t.onclick = go; t.onkeydown = e => { if (e.key === "Enter") go(); }; } return t; };
    const month = Date.now() / 1000 - 30 * 86400;
    // Every tile that counts a problem opens the crate showing exactly those tracks - a number with nowhere to go
    // ("95 poor-quality copies") only worried the DJ. Each track's row says what's wrong and has the fix on it.
    const lowT = all.filter(t => { const i = healthIssue(t); return i && i.low; }), badT = all.filter(t => { const i = healthIssue(t); return i && !i.low; });
    const nocueT = all.filter(t => t.bpm && !(t.cues || []).length), recentT = all.filter(t => (t.added || 0) > month);
    const low = lowT.length, bad = badT.length, nocue = nocueT.length;
    const unread = all.filter(t => !t.bpm).length;
    const only = (list, name) => () => showOnly(list.map(t => t.id), name);
    const tiles = [keys, tempo, energy,
      num("Added this month", recentT.length, "in the last 30 days - show them", only(recentT, "Added this month")),
      num("Poor-quality copies", low, low ? "worth replacing before a big room - show them" : "none found", only(lowT, "Poor-quality copies")),
      num("Not read yet", unread, unread ? "no tempo or key - Clean up reads them" : "every track has its tempo and key", () => { goToSection("crate"); setTimeout(() => $("#crate-clean").click(), 400); })];
    if (bad) tiles.push(num("Won't play through", bad, "broken or cut short - show them to get them again", only(badT, "Won't play through")));
    if (nocue) tiles.push(num("No hot cues", nocue, "read, but no sections found - show them", only(nocueT, "No hot cues")));
    // the gaps: a key with far fewer tracks than the keys that mix with it
    const gaps = [];
    if (all.length >= 40) {
      for (const l of ["A", "B"]) for (let n = 1; n <= 12; n++) {
        const code = n + l, mine = keyCount[code] || 0;
        const near = [((n % 12) + 1) + l, (((n + 10) % 12) + 1) + l, n + (l === "A" ? "B" : "A")];
        const around = near.reduce((sum, k) => sum + (keyCount[k] || 0), 0) / 3;
        if (around >= 6 && mine < around * 0.35) gaps.push({ code, mine, around: Math.round(around), near, miss: around - mine });
      }
      gaps.sort((a, b) => b.miss - a.miss);
    }
    const gapBox = el("div", "ins-gaps");
    if (gaps.length) {
      gapBox.append(el("span", "label", "Gaps worth filling"));
      gaps.slice(0, 3).forEach(g => {
        const row = el("div", "ins-gap");
        const cam = el("span", "cam", g.code); cam.style.setProperty("--cam", camColor(g.code));
        const say = el("div", "t");
        say.append(el("b", null, `Only ${g.mine} track${g.mine === 1 ? "" : "s"} in ${g.code}`), el("small", null, `The keys that mix with it (${g.near.join(", ")}) hold about ${g.around} each, so a set passing through has little to land on.`));
        const go = el("button", "btn-outline small", g.mine ? "Show them" : "Show its neighbours");
        go.type = "button";
        go.onclick = () => { keySelect.value = g.mine ? g.code : g.near[0]; keySelect.dispatchEvent(new Event("change")); goToSection("crate"); };
        row.append(cam, say, go);
        gapBox.append(row);
      });
    } else gapBox.append(el("span", "label", "Gaps worth filling"), el("p", "ins-say", all.length < 40 ? "With 40 tracks or more, this shows the keys you're thin in next to the ones you have plenty of." : "None stand out: no key is far behind the keys that mix with it."));
    const grid2 = el("div", "ins-grid");
    grid2.append(...tiles);
    box.replaceChildren(grid2, gapBox);
  }
  function pagesSoon() {
    clearTimeout(pagesTimer);
    pagesTimer = setTimeout(() => { renderInsights(); if (currentSet()) renderSet(); if (window.YCMore) YCMore.refresh(); measureSections(); }, 350);
  }
  // The crate can draw before this part of the file has run: only from here on does a redraw refresh these pages.
  var pagesReady = true;
  pagesSoon();

  // ── the request page's settings (Phone › The request page) ─────────────
  function paintBoothPage() {
    const st = state.settings, set = (id, v) => { const n = $(id); if (document.activeElement !== n) n.value = v; };
    set("#booth-title", st.booth_title || ""); set("#booth-note", st.booth_note || "");
    set("#booth-limit", st.booth_limit == null ? 5 : st.booth_limit);
    set("#booth-dnp", (st.do_not_play || []).join("\n"));
    $("#booth-votes").checked = st.booth_votes !== false;
    $("#booth-closed").checked = !!st.booth_closed;
  }
  {
    const keep = (id, key, read) => $(id).addEventListener("change", async e => { state.settings = await call("set_setting", key, read(e.target)); paintBoothPage(); });
    keep("#booth-title", "booth_title", n => n.value); keep("#booth-note", "booth_note", n => n.value);
    keep("#booth-limit", "booth_limit", n => n.value); keep("#booth-dnp", "do_not_play", n => n.value);
    keep("#booth-votes", "booth_votes", n => n.checked);
    $("#booth-closed").addEventListener("change", async e => {
      state.settings = await call("set_setting", "booth_closed", e.target.checked);
      toast(e.target.checked ? "Requests are closed. The page says so, and takes no more." : "Requests are open again.");
    });
    $("#booth-card").onclick = async () => {
      const r = await call("booth_card");
      if (!r || !r.ok) return toast((r && r.error) || "Couldn't make the card.", true);
      toast("The card is open in your browser - print it from there, four to a page.", false, 7000);
    };
  }

  // ── rail, guide, window chrome ────────────────────────────────────────
  const main = $("#main");
  const sections = ["get", "queue", "crate", "set", "gigs", "insights", "phone", "djsoft", "guide"].map(id => document.getElementById(id));
  let sectionTops = [];
  function measureSections() { sectionTops = sections.map(s => s.offsetTop); }
  addEventListener("resize", measureSections);
  let railRaf = 0;
  main.addEventListener("scroll", () => {
    if (railRaf) return;
    railRaf = requestAnimationFrame(() => {
      railRaf = 0;
      if (!sectionTops.length) measureSections();
      // The section crossing a line 40% down the page is the one you're on - measured now, not from tops stored
      // earlier (they go stale as the page fills in), and not 140px down, which left the section above lit.
      const line = main.getBoundingClientRect().top + main.clientHeight * 0.4;
      let current = sections[0].id;
      const view = window.YCS && window.YCS.view;   // pro.css: one section at a time, so the one showing is the one you're on
      if (view) current = view.id;
      else {
        sections.forEach(s => { if (s.getBoundingClientRect().top <= line) current = s.id; });
        if (main.scrollTop + main.clientHeight >= main.scrollHeight - 4) current = sections[sections.length - 1].id;
      }
      document.querySelectorAll(".rail-item").forEach(a => a.classList.toggle("active", a.dataset.target === current));
    });
  }, { passive: true });
  // In a narrow window the side menu is icons only: each one says its name on the pointer (Settings carries its
  // own, with its shortcut). Only the words this edition shows: a name can hold both - [data-fetch] and [data-shop],
  // one of them hidden - and textContent reads the hidden one too ("DownloadsRequests"). Said again once get_boot
  // has told us which edition this is, and when the DJ software's name changes.
  function nameRail() {
    const hidden = shop() ? "[data-fetch]" : "[data-shop]";
    document.querySelectorAll(".rail-item[data-target]").forEach(a => {
      const name = a.querySelector(".rail-name")?.cloneNode(true);
      name?.querySelectorAll(hidden).forEach(n => n.remove());
      a.title = (name?.textContent || "").trim();
    });
  }
  nameRail();
  document.querySelectorAll(".rail-item").forEach(a => a.addEventListener("click", e => {
    e.preventDefault();
    if (a.dataset.page === "settings") return openSettings();
    closeSettings();
    window.YCS.to(a.dataset.target);
  }));

  // ── Settings: a page of its own ───────────────────────────────────────
  // Settings outgrew a section, so it's a page beside the main one, in the same place: the main page is only
  // hidden underneath (dj.css: .views), never taken out of the layout, so it comes back exactly where it was.
  // In by the faders at the foot of the rail or in the top bar, Ctrl+, or the command bar; out by Back, Esc,
  // or any section on the rail.
  const spage = $("#settings");
  let settingsOpen = false, settingsGroup = "general";
  function pickGroup(name, scrollTop = true) {
    const tabs = [...document.querySelectorAll("#sp-nav [role=tab]")];
    const tab = tabs.find(t => t.dataset.group === name) || tabs[0];
    settingsGroup = tab.dataset.group;
    tabs.forEach(t => { const on = t === tab; t.setAttribute("aria-selected", String(on)); t.tabIndex = on ? 0 : -1; });
    document.querySelectorAll(".sp-group").forEach(g => { g.hidden = true; });
    void spage.offsetWidth;                  // shown again from hidden, so its cards rise in again
    document.getElementById(`sp-${settingsGroup}`).hidden = false;
    if (settingsGroup === "changes") refreshChanges();
    const nav = $("#sp-nav");
    nav.style.setProperty("--ind-y", `${tab.offsetTop}px`);
    nav.style.setProperty("--ind-h", `${tab.offsetHeight}px`);
    if (scrollTop) { spage.style.scrollBehavior = "auto"; spage.scrollTop = 0; spage.style.scrollBehavior = ""; }
    return tab;
  }
  function openSettings(group, focusSel) {
    if (document.documentElement.classList.contains("locked")) return;
    const was = settingsOpen;
    settingsOpen = true;
    if (palOpen) closePalette();
    document.documentElement.classList.add("on-settings");
    document.querySelectorAll(".rail-item").forEach(a => a.classList.toggle("active", a.dataset.page === "settings"));
    $("#settings-btn").setAttribute("aria-expanded", "true");
    const tab = pickGroup(group || settingsGroup, !was || !!group);
    setTimeout(() => {
      const f = focusSel && $(focusSel);
      if (f) { f.scrollIntoView({ block: "center", behavior: REDUCED ? "auto" : "smooth" }); f.focus({ preventScroll: true }); }
      else if (!was) tab.focus({ preventScroll: true });
    }, REDUCED ? 0 : 380);
  }
  function closeSettings() {
    if (!settingsOpen) return;
    settingsOpen = false;
    document.documentElement.classList.remove("on-settings");
    $("#settings-btn").setAttribute("aria-expanded", "false");
    if (spage.contains(document.activeElement)) document.activeElement.blur();
    measureSections();
    main.dispatchEvent(new Event("scroll"));     // the rail lights the section you're back on
  }
  $("#settings-btn").addEventListener("click", () => (settingsOpen ? closeSettings() : openSettings()));
  $("#settings-back").addEventListener("click", closeSettings);
  document.querySelectorAll("#sp-nav [role=tab]").forEach(t => t.addEventListener("click", () => pickGroup(t.dataset.group)));
  // The list of groups answers the arrow keys, as a list of tabs does (and keeps them from the crate).
  $("#sp-nav").addEventListener("keydown", e => {
    const tabs = [...document.querySelectorAll("#sp-nav [role=tab]")];
    const at = tabs.findIndex(t => t.dataset.group === settingsGroup);
    const to = { ArrowDown: at + 1, ArrowRight: at + 1, ArrowUp: at - 1, ArrowLeft: at - 1, Home: 0, End: tabs.length - 1 }[e.key];
    if (to == null) return;
    e.preventDefault();
    e.stopPropagation();
    pickGroup(tabs[(to + tabs.length) % tabs.length].dataset.group).focus();
  });
  addEventListener("keydown", e => {
    if (e.key !== "," || !(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey || !introDone) return;
    e.preventDefault();
    settingsOpen ? closeSettings() : openSettings();
  });
  pickGroup("general");

  $("#guide-btn").addEventListener("click", () => {
    closeSettings();
    window.YCS.to("guide");
    const steps = $("#guide-steps");
    steps.classList.remove("guide-flash");
    void steps.offsetWidth;
    setTimeout(() => steps.classList.add("guide-flash"), REDUCED ? 0 : 450);
  });
  const topbar = $(".topbar");
  const setMaximized = on => {
    document.documentElement.classList.toggle("is-maximized", !!on);
    const maxBtn = $('[data-win="max"]');
    if (maxBtn) maxBtn.title = maxBtn.ariaLabel = on ? "Restore" : "Maximise";
  };
  const isMac = () => document.documentElement.classList.contains("platform-mac");
  function dragWindow(e) {
    if (isMac() || e.button !== 0 || e.detail > 1 || !api || e.target.closest("button, a, input, select, textarea, label, details")) return;
    api.win_drag();
  }
  topbar.addEventListener("mousedown", dragWindow);
  gate.addEventListener("mousedown", e => { if (e.target === gate) dragWindow(e); });
  topbar.addEventListener("dblclick", async e => {
    if (isMac() || !api || e.target.closest("button, a, input")) return;
    setMaximized(await api.win_toggle_maximize());
  });
  $("#win-controls").addEventListener("click", async e => {
    const b = e.target.closest("[data-win]");
    if (!b || !api) return;
    if (b.dataset.win === "min") api.win_minimize();
    if (b.dataset.win === "max") setMaximized(await api.win_toggle_maximize());
    if (b.dataset.win === "close") api.win_close();
  });
  $("#resize-handles").addEventListener("mousedown", e => {
    const edge = e.target.dataset && e.target.dataset.edge;
    if (e.button === 0 && edge && api) { e.preventDefault(); api.win_resize(edge); }
  });

  // ── a newer version is out ─────────────────────────────────────────────
  // Shown only when the backend actually found one. Dismissing hides it for this run of the app; it
  // comes back next time the app opens, until the new version is installed.
  let updateSeen = "";
  function showUpdate(info) {
    const box = $("#update-note");
    // A required update can't be dismissed, so a dismissal from earlier in this run doesn't hide it.
    const required = !!(info && info.required);
    if (!info || !info.available || !info.version || (updateSeen === info.version && !required)) { box.hidden = true; return; }
    box.classList.toggle("required", required);
    $("#update-title").textContent = required ? `Version ${info.version} - please update` : `Version ${info.version} is out`;
    const notes = $("#update-notes");
    notes.textContent = required
      ? `${info.notes || "This one isn't optional."} You're on ${state.version || "an older version"}.`
      : info.notes || `You're on ${state.version || ""}`.trim();
    notes.hidden = !notes.textContent;
    // One click where the app can install it itself; the download page where it can't (run from source).
    const install = $("#update-install");
    install.hidden = !info.can_install;
    const get = $("#update-get");
    get.hidden = !info.url || !!info.can_install;
    if (info.url) get.href = info.url;
    $("#update-dismiss").hidden = required;
    box.hidden = false;
  }
  $("#update-install").onclick = async () => {
    const b = $("#update-install");
    b.disabled = true;
    b.textContent = "Starting";
    const r = await call("update_install");
    if (!r.ok) {
      b.disabled = false;
      b.textContent = "Install update";
      toast(r.error, true, 8000);
    }
  };
  // ── what changed in this version ───────────────────────────────────────
  // The other half of the update story: the check above says a new version exists, this says what the
  // one you just installed brought. It comes up once, after signing in, and closing it is the end of it.
  async function showWhatsNew() {
    const n = await call("whats_new");
    if (!n || !n.releases || !n.releases.length) return;
    // One block per release. Skipping a version is normal, so the card covers every one you missed
    // rather than only the newest - the version label appears on each when there's more than one.
    const many = n.releases.length > 1;
    $("#wn-releases").replaceChildren(...n.releases.map((r, i) => {
      const box = el("div", "wn-release");
      const head = el("div", "wn-head");
      head.append(el("span", "label", i === 0 && !many ? `What's new in ${r.version}`
                                                       : `Version ${r.version}`),
                  el("h3", null, r.title || ""));
      const list = el("ul", "wn-list");
      list.append(...r.lines.map(line => el("li", null, line)));
      box.append(head, list);
      return box;
    }));
    $("#wn-sign").textContent = n.sign_off || "";
    const box = $("#whatsnew");
    box.hidden = false;
    requestAnimationFrame(() => box.classList.add("in"));
  }
  // Got it just closes the card. Being shown is what marks it read, back in whats_new - otherwise
  // walking away without pressing anything meant seeing it all over again next time.
  $("#wn-ok").onclick = () => {
    const box = $("#whatsnew");
    box.classList.remove("in");
    setTimeout(() => (box.hidden = true), REDUCED ? 0 : 420);
  };

  $("#update-dismiss").onclick = () => {
    updateSeen = ($("#update-title").textContent.match(/[\d.]+/) || [""])[0];
    $("#update-note").hidden = true;
  };

  // ── python → page ──────────────────────────────────────────────────────
  window.app = {
    onWindowState(s) {
      setMaximized(s.maximized);
      document.documentElement.classList.toggle("is-fullscreen", !!s.fullscreen);
    },
    onJob(job) { if (loaded) renderJob(job); },
    onGigDownload(d) {
      if (!loaded) return;
      if (!gigDownloadTracks.has(d.set)) gigDownloadTracks.set(d.set, new Set());
      gigDownloadTracks.get(d.set).add(d.track);
      for (const s of [sets.find(s => s.id === d.set), typeof setPending !== "undefined" ? setPending.get(d.set) : null]) {
        if (s && !s.tracks.includes(d.track)) s.tracks.push(d.track);
      }
      renderSet(); refreshRekordboxSoon();
      loadGigs();
    },
    onTrack(t) {
      if (!loaded) return;
      const map = t.store === "requests" ? state.requests : state.crate;
      const arrived = !map.has(t.id) && !scanning;
      map.set(t.id, t);
      if (arrived && !REDUCED) landedAt.set(t.id, performance.now() + (window.YCM ? YCM.slot() * 80 : 0));
      if (arrived) window.YCM?.ping(document.getElementById("crate"));
      tickCount = tickCount || (arrived && t.store !== "requests");
      renderCrateNextFrame();
      refreshRekordboxSoon();
      if (state.active === t.id) selectTrack(t.id);
    },
    // A waveform or cover filled in after the track arrived: changed where it sits, without
    // redrawing the list under the pointer of someone about to drag from it.
    onTrackPatch(p) {
      if (!loaded) return;
      const t = (p.store === "requests" ? state.requests : state.crate).get(p.id);
      if (!t) return;
      // Everything the background pass worked out, not only the waveform and cover: a song taken in from a library
      // folder, Serato or rekordbox arrives with names only, and its tempo, key and Camelot code come in here
      // later - with its cues, energy and health. Those change the row's numbers, the filters and Mixes well with,
      // so the list is drawn again (an open row stays open) rather than waiting for the window to reload.
      const { id, store, ...fields } = p;
      Object.assign(t, fields);
      if ("niche" in fields) genreSoon();             // a genre worked out: the set's suggestions may change
      if (["bpm", "key", "camelot", "cues", "energy", "health", "niche"].some(k => k in fields)) {
        renderCrateNextFrame();
        if (state.active === p.id) selectTrack(p.id);
        return;
      }
      const row = document.getElementById("track-" + p.id);
      if (row && "art" in p) row.querySelector(".cart")?.replaceWith(keptCover("row:" + p.id, t, "cart"));
      if (row && "wave" in p) {
        row.querySelector(".cwave")?.remove();
        const wave = waveStrip(t);
        if (wave) row.append(wave);
      }
      if ("art" in p && state.active === p.id) selectTrack(p.id);
    },
    onScan: showScan,
    onCleanProgress,
    onLibrary(d) {
      const from = [d.counts.folders && `${d.counts.folders} from your folders`, d.counts.serato && `${d.counts.serato} from Serato`,
                    d.counts.rekordbox && `${d.counts.rekordbox} from rekordbox`].filter(Boolean).join(", ");
      toast(`${d.added} new song${d.added === 1 ? "" : "s"} in your crate (${from}).${d.reading ? ` Reading tempo and key for ${d.reading} in the background.` : ""}`, false, 9000);
      call("get_state").then(s => { syncCrate(s.crate); }).catch(() => {});
    },
    onPurchases(d) {
      const n = d.added.length, x = d.doubles.length;
      if (n) toast(`${n} new track${n === 1 ? "" : "s"} ready: ${d.added.slice(0, 3).join(", ")}${n > 3 ? ` and ${n - 3} more` : ""}. In your crate, rekordbox and Serato.`, false, 9000);
      if (x) toast(`${x} purchase${x === 1 ? " was" : "s were"} already in your crate, so ${x === 1 ? "it wasn't" : "they weren't"} added again: ${d.doubles.slice(0, 2).join(", ")}.`, false, 9000);
    },
    onDropped(d) {
      if (d.ignored) return toast("Those aren't audio files DJ Master can read - WAV, AIFF, FLAC, MP3 or M4A.", true);
      if (d.added) {
        toast(`${d.added} track${d.added === 1 ? "" : "s"} in your crate. Reading tempo and key now.${d.already ? ` ${d.already} ${d.already === 1 ? "was" : "were"} already there.` : ""}`, false, 7000);
        call("get_state").then(s => { syncCrate(s.crate); }).catch(() => {});
      } else if (d.already) toast(d.already === 1 ? "That one's already in your crate." : `All ${d.already} are already in your crate.`);
    },
    onFromStemSplitter(d) { toast(`“${d.title}” arrived from the Stem Splitter - it's in your crate.`, false, 7000); },
    // Extended intro (make_intro), done or not: the new copy is already in the crate by the time this comes.
    onIntro(d) {
      const buttons = document.querySelectorAll(`.intro-make[data-id="${d.id}"]`);
      if (d.stage) return buttons.forEach(b => { b.disabled = true; b.textContent = `${d.stage}…`; });
      buttons.forEach(b => { b.disabled = false; b.textContent = "Extended intro →"; });
      if (!d.ok) return toast(d.error, true, 8000);
      toast(`“${d.title}” is in your crate, next to the original.`, false, 7000);
    },
    onUpdate: showUpdate,
    onGift: g => showGift(g),
    // A subscription renewed, lapsed, or was paid again while the key screen was up.
    onLicence(l) {
      const before = boot && boot.licence;
      const accessChanged = !before || !!before.ok !== !!l.ok || before.sub !== l.sub;
      if (boot) boot.licence = l;
      renderActivation();
      if (!l.ok && (l.local_trial || l.ended)) { hideTrial(); return showLocked(); }   // ran out: time for a key
      if (loaded && l.ok && accessChanged) loadGigs();
      if (l.ok && l.held) toast("Your subscription has ended. DJ Master will lock once this download or booth set is done - renew on the website to keep going.", true, 12000);
      if (l.ok && !$("#activate-form").hidden && !$("#gate").hidden) {
        showLocked();                                 // paid again: on to the sign-in
        toast("Subscription renewed - welcome back.");
      }
    },
    // Install update, as it goes: downloading, checked, closing to install - or why it stopped, with
    // the download page offered instead.
    onUpdateProgress(d) {
      const b = $("#update-install"), notes = $("#update-notes");
      if (d.error) {
        b.disabled = false;
        b.textContent = "Install update";
        $("#update-get").hidden = !$("#update-get").getAttribute("href") || $("#update-get").getAttribute("href") === "#";
        notes.textContent = d.error;
        notes.hidden = false;
        $("#update-dismiss").hidden = $("#update-note").classList.contains("required");
        return toast(d.error, true, 9000);
      }
      b.disabled = true;
      b.textContent = d.installing ? "Installing" : d.pct != null ? `${d.pct}%` : "Starting";
      notes.textContent = d.text || "";
      notes.hidden = !notes.textContent;
      $("#update-dismiss").hidden = true;
    },
    onBoothRequest(job) {
      renderJob(job);
      refreshBooth().catch(() => {});
      chime();
      // In booth view the request is already in front of you - sending you to Downloads for it
      // is telling you to go somewhere you are standing.
      toast(boothOpen ? `New request: “${job.title}” - it's on screen now.`
                      : `New request: “${job.title}” - approve it in Downloads.`, false, 9000);
    },
    onAlerts(info) {
      alertsInfo = info;
      renderAlerts();
      if (info.paired) {
        chime();
        toast(`Alerts are on for ${info.paired}. A test alert is on its way to it.`, false, 7000);
      }
    },
    // Turned down somewhere else - the phone, or the pop-up over rekordbox.
    onJobGone(d) {
      if (!loaded) return;
      state.jobs.delete(d.id);
      const row = document.getElementById("job-" + d.id);
      if (row && !row.dataset.leaving) removeJobNode(row);
      drawBooth();
      renderHomeSoon();
      refreshBooth().catch(() => {});
    },
    onBoothChanged() { refreshBooth().catch(() => {}); },
    // "Open" on the pop-up: straight to the requests - booth view while the link is open.
    onOpenRequests() {
      if (!loaded || document.documentElement.classList.contains("locked")) return;
      if (boothInfo && boothInfo.on) openBooth();
      else goToSection("queue");
    },
    onQueueFinished(d) {
      chime();
      toast(`${d.message} Took ${d.minutes} min.`, false, 7000);
    },
    onDragOutEnded() { setTimeout(() => { ownDrag = false; }, 400); },
  };

  // ── boot ───────────────────────────────────────────────────────────────
  function startReveals() {
    // Section titles rise from behind a mask as they arrive. They are only hidden once this is running,
    // so if it ever didn't run the titles would simply stay put.
    document.querySelectorAll(".section-title").forEach(h => {
      if (h.querySelector(".rise-in")) return;
      const s = el("span", "rise-in");
      s.append(...h.childNodes);
      h.append(s);
    });
    document.documentElement.classList.add("reveals");
    const seen = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("in");
        seen.unobserve(entry.target);
      });
    }, { root: main, threshold: 0, rootMargin: "0px 0px -8% 0px" });
    document.querySelectorAll(".reveal, .section-head").forEach((n, i) => {
      if (n.closest("#get")) n.style.setProperty("--d", `${0.15 + i * 0.1}s`);
      seen.observe(n);
    });
  }
  // Jumping to a section from the rail plays its title again as you land.
  document.querySelectorAll(".rail-item").forEach(a => a.addEventListener("click", () => {
    const head = document.querySelector(`#${a.dataset.target} .section-head`);
    if (!head || REDUCED) return;
    head.classList.remove("in");
    void head.offsetWidth;
    head.classList.add("in");
  }));
  // ── Tonight: what's waiting on the DJ, on the Dashboard ─────────────────
  // With the booth link open, held requests sit at the top of the Dashboard with Play it / Not tonight - the same
  // approveRequest / rejectRequest the Downloads list uses, undo and all. Most-wanted first.
  function renderHomeWait() {
    const box = $("#home-wait");
    if (!box) return;
    const held = [...state.jobs.values()].filter(j => j.status === "held").sort((a, b) => (b.votes || 1) - (a.votes || 1));
    const open = !!(boothInfo && boothInfo.on) || !!(state.settings && state.settings.booth_mode);
    box.hidden = !open || !held.length;
    if (box.hidden) return;
    $("#home-wait-n").textContent = `${held.length} waiting`;
    $("#home-wait-list").replaceChildren(...held.slice(0, 6).map(j => {
      const row = el("div", "hw-row");
      const info = el("div", "hw-info");
      info.append(el("span", "hw-title", j.title || "A request"),
        el("span", "hw-sub", [j.subtitle, (j.votes || 1) > 1 ? `${j.votes} people want this` : "", j.have ? "in your crate" : ""].filter(Boolean).join(" · ")));
      const no = el("button", "btn-outline small", "Not tonight"), yes = el("button", "btn-pill small", "Play it");
      no.type = yes.type = "button";
      no.onclick = () => rejectRequest(j);
      yes.onclick = e => { window.YCFX?.spark(e); approveRequest(j); };
      row.append(info, no, yes);
      return row;
    }));
  }

  // ── Dashboard quick actions ─────────────────────────────────────────────
  // Each one presses the control that already does the job, so there's one way each thing happens.
  const DASH = {
    booth: () => {
      const on = $("#booth-on");
      goToSection("phone");
      if (on && !on.checked) { on.checked = true; on.dispatchEvent(new Event("change", { bubbles: true })); }
    },
    ready: b => {
      b.classList.add("busy");
      $("#preflight").classList.add("running");
      $("#pf-run").click();
      setTimeout(() => b.classList.remove("busy"), 20000);
    },
    scan: () => { goToSection("crate"); setTimeout(() => $("#crate-scan").click(), 350); },
    set: () => { goToSection("set"); setTimeout(() => { const b = $("#sb-open-build"); if (b && b.getAttribute("aria-expanded") !== "true") b.click(); }, 350); },
    backup: b => { b.classList.add("busy"); $("#backup-now").click(); setTimeout(() => b.classList.remove("busy"), 1500); },
  };
  document.querySelectorAll("#dash-actions .dash-act").forEach(b => (b.onclick = () => DASH[b.dataset.act] && DASH[b.dataset.act](b)));
  function paintDashBooth() {
    const b = document.querySelector('#dash-actions [data-act="booth"]');
    if (!b) return;
    const open = !!(boothInfo && boothInfo.on);
    b.classList.toggle("on", open);
    b.querySelector(".dash-lab").textContent = open ? "Booth link is open" : "Open the booth link";
  }

  // ── Letter roll on hover, as on the website ───────────────────────────
  // A label becomes two rows of letters; on hover the first slides up and out as its twin slides in, letter
  // by letter (.roll in the stylesheet). A button is split the first time the pointer reaches it rather than
  // all up front - a long list's worth of buttons would be thousands of letters. The letters are drawn by
  // CSS from data-c, so the button's own text, which the rest of this file reads and sets, is still exactly
  // its label; setting it again just leaves it plain until the next hover. Only plain labels roll: a button
  // with a count, a note or a swatch in it is left as it is.
  const ROLL_LABEL = ":scope > .rail-name, :scope > .sp-label";
  function rollLabel(t) {
    if (t.querySelector(":scope > .roll")) return null;
    const kids = [...t.childNodes];
    const words = kids.filter(n => n.nodeType === 3 && n.textContent.trim());
    if (words.length !== 1 || kids.some(n => n.nodeType === 1 && !(n instanceof SVGElement))) return null;
    const text = words[0].textContent.trim();
    if (text.length < 2 || text.length > 28) return null;
    const row = cls => {
      const r = el("span", cls);
      [...text].forEach((c, i) => { const ch = el("span", "ch"); ch.dataset.c = c; ch.style.setProperty("--i", String(i)); r.append(ch); });
      return r;
    };
    const wrap = el("span", "roll roll-wait");
    wrap.setAttribute("aria-hidden", "true");
    wrap.append(row("roll-a"), row("roll-b"));
    const real = el("span", "roll-real");
    words[0].replaceWith(wrap);
    real.append(words[0]);
    wrap.after(real);
    return wrap;
  }
  if (matchMedia("(hover: hover)").matches && !REDUCED) {
    document.addEventListener("pointerover", e => {
      const host = e.target.closest && e.target.closest("button, a");
      if (!host || host.disabled || host.matches(".win-btn, .tb-round") || host.closest(".roll")) return;
      // Only the main things roll (27 Oct): the side menu's names, Settings' sections and the big pill buttons.
      // Every small button and link rolling at once was too busy.
      if (!host.matches(".rail-item, .btn-pill") && !host.querySelector(":scope > .sp-label")) return;
      const wrap = rollLabel(host.querySelector(ROLL_LABEL) || host);
      if (!wrap) return;
      void wrap.offsetWidth;                                    // at rest first...
      requestAnimationFrame(() => wrap.classList.remove("roll-wait"));   // ...then it rolls from there
    }, { passive: true });
  }

  let lightEvent = null;
  document.addEventListener("pointermove", e => {
    if (lightEvent) { lightEvent = e; return; }
    lightEvent = e;
    requestAnimationFrame(() => {
      const ev = lightEvent;
      lightEvent = null;
      const target = ev.target.closest && ev.target.closest(".sxc, .job, .acct, .card-glass, .jobs, .ins-tile, .sb-panel, .set-list, .tile");   // glass.css lights them
      if (!target) return;
      const r = target.getBoundingClientRect();
      target.style.setProperty("--mx", `${ev.clientX - r.left}px`);
      target.style.setProperty("--my", `${ev.clientY - r.top}px`);
    });
  }, { passive: true });

  async function loadState() {
    const s = await call("get_state");
    state.settings = s.settings;
    state.platform = s.platform;
    state.stemSplitter = !!s.stem_splitter;
    state.version = s.version || "";
    state.space = s.space || null;          // free space on the drive the music goes to
    renderSettings();
    call("smart_crates").then(renderSmart).catch(() => {});   // the rules, and what each holds now
    refreshBackups();
    loadSets();                               // the Set page's sets: asked for here, so they arrive after signing in
    loadGenres();                             // the genre names, for rows, the Set page and the genre box
    syncJobs(s.jobs, { animate: false });
    state.requestsDir = s.requests_dir || "";
    syncCrate(s.crate);
    syncRequests(s.requests);
    showScan(s.scan);
    await refreshRemote().catch(() => {});
    await refreshRekordbox().catch(() => {});
    await refreshSerato().catch(() => {});
    await refreshBooth().catch(() => {});
    await refreshAlerts().catch(() => {});
    tickClock();
    renderHome();
    // If the background check already answered before the page finished loading, show it now; if it
    // hasn't, onUpdate will push it in when it does.
    call("update_info").then(showUpdate).catch(() => {});
    measureSections();
  }
  async function refreshAll() {
    try { await loadState(); } catch (err) { /* locked again */ }
  }


  window.addEventListener("pywebviewready", async () => {
    api = window.pywebview.api;
    document.documentElement.classList.remove("no-chrome");      // a real window after all: its buttons back
    if (window.pywebview.platform === "cocoa") document.documentElement.classList.add("platform-mac");
    else { pasteHint = "Ctrl V"; showKind(); }
    step("bridge");
    api.win_is_maximized().then(setMaximized).catch(() => {});
    boot = await api.get_boot();
    document.documentElement.classList.toggle("store", shop());
    nameRail();                                                   // the side menu's names, in this edition's words
    document.documentElement.classList.toggle("private", boot.fetch === true);   // stamped PRIVATE on the intro
    if (shop()) input.placeholder = "Search for a song - or drop your tracks anywhere";
    window.YCFX?.hints(input, shop()
      ? ["Search for a song you have", "Try: the buzz ruvii", "Drop your tracks anywhere", "Or a whole folder of them"]
      : ["Search for a song", "Paste a YouTube or Spotify link", "Try: the buzz ruvii", "Drop your tracks anywhere"]);
    applyAccent(boot.accent || "#ff4d4d");        // the theme is on before the first frame the user sees
    applyWall(boot.wallpaper);
    if (window.YCMore) YCMore.apply(boot);        // text size and Daylight: on the intro and the lock screen too
    state.dj = boot.dj;
    if (boot.version) $("#intro-version").textContent = `v${boot.version}`;
    if (boot.has_account) showIntroName(boot.dj);
    trialDays = boot.trial_days || 5;
    state.platform = boot.platform;
    $("#gate-path").textContent = boot.platform === "mac"
      ? "Mac: ~/Library/Application Support/Yoshi C DJ Master/account.json"
      : "Windows: %LOCALAPPDATA%\\Programs\\Yoshi C DJ Master\\account.json";
    step("boot", boot.has_account ? "Locked · password needed" : "First run · set up your DJ name");
  });
  // Where a job sits among the ones still waiting - 0 means it is already next, and the button
  // that would move it there is pointless.
  function queuePosition(id) {
    return [...state.jobs.values()].filter(j => j.status === "waiting").findIndex(j => j.id === id);
  }

  // ── booth view ─────────────────────────────────────────────────────────
  // The same state as everywhere else, three panels, everything bigger. It redraws from the live
  // maps on a slow tick rather than subscribing to anything: mid-set, a second late is fine, and a
  // screen that never blocks is worth more than one that is instantaneous.
  let boothOpen = false, boothTick = 0, boothSince = 0, boothFull = false, boothStarting = false;

  // Entering the view is as clear a statement as flicking the switch was: you are standing in a
  // booth and you want people to be able to ask you for things. So it opens the link itself,
  // proving it end to end the same way the switch does, which is the part that takes the seconds.
  // Deliberately never closed on the way out - see the note above closeBooth.
  async function startBoothLink() {
    if (boothStarting || (boothInfo && boothInfo.on)) return;
    boothStarting = true;
    drawBooth();                                   // say what is happening where the code will be
    try {
      state.settings = await call("set_setting", "booth_mode", true);
      await refreshBooth();
    } catch (e) { /* refreshBooth puts the reason on screen */ }
    boothStarting = false;
    if (!boothOpen) return;
    drawBooth();
    if (!(boothInfo && boothInfo.on))
      toast((boothInfo && boothInfo.error) || "Couldn't open the public link.", true);
  }

  // A request that lands while you are in booth view resolves like a deck display: random characters
  // lock into the real title left to right, and the waiting count rolls over rather than jumping. You
  // catch it from the corner of your eye without reading anything.
  const seenReq = new Set();
  const GLYPHS = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789#%&*+=/<>";
  function scramble(node, text, dur = 900) {
    if (REDUCED) { node.textContent = text; return; }
    const start = performance.now(), n = text.length;
    const lock = [...text].map((ch, i) => (i / Math.max(1, n)) * dur * 0.65 + Math.random() * dur * 0.35);
    const frame = now => {
      if (!node.isConnected) return;
      const t = now - start;
      let out = "";
      for (let i = 0; i < n; i++) out += (text[i] === " " || t >= lock[i]) ? text[i] : GLYPHS[(Math.random() * GLYPHS.length) | 0];
      node.textContent = out;
      if (t < dur) requestAnimationFrame(frame); else node.textContent = text;
    };
    requestAnimationFrame(frame);
    setTimeout(() => { node.textContent = text; }, dur + 400);      // settles even if frames stall
  }
  function rollTo(node, n) {
    const was = parseInt(node.textContent, 10);
    if (REDUCED || Number.isNaN(was)) { node.textContent = n; return; }
    const up = n > was;
    node.animate([{ transform: "none", opacity: 1 }, { transform: `translateY(${up ? -60 : 60}%)`, opacity: 0 }], { duration: 220, easing: "ease-in", fill: "forwards" });
    setTimeout(() => {
      node.textContent = n;
      node.getAnimations().forEach(x => x.cancel());
      node.animate([{ transform: `translateY(${up ? 60 : -60}%)`, opacity: 0 }, { transform: "none", opacity: 1 }], { duration: 380, easing: "cubic-bezier(0.16, 1, 0.3, 1)" });
    }, 230);
  }
  function bvRequests() {
    const held = [...state.jobs.values()].filter(j => j.status === "held");
    const wn = $("#bv-waiting-n");
    if (wn.textContent !== String(held.length)) rollTo(wn, held.length);
    $("#bv-requests-none").hidden = held.length > 0;
    // Requests appear where the code was, in the same column, at the same width. Nothing moves
    // except what is in front of you - the view never changes shape mid-set.
    $("#boothview").classList.toggle("waiting", held.length > 0);
    // With nothing waiting, the panel's job changes: show the code people scan to ask for
    // something, so you can answer "how do I request?" without leaving the view.
    const live = boothInfo && boothInfo.on && boothInfo.qr;
    $("#bv-qr").hidden = !live;
    $("#bv-quiet-why").textContent = live ? "The floor is quiet."
      : boothStarting ? "Opening your public link - it gets tested before you get the code, so give it a few seconds."
      : "Booth mode is off, so nobody can send you anything.";
    const holder = $("#bv-qr-img");
    if (live && holder.dataset.link !== boothInfo.link) {
      holder.dataset.link = boothInfo.link;
      holder.innerHTML = boothInfo.qr;
    }
    if (live) fitQR(holder);
    $("#bv-requests").replaceChildren(...held.map(job => {
      const row = el("div", "bv-req");
      row.append(keptCover("req:" + job.id, { art: job.thumbnail }, "bvart big"));
      const who = el("div", "bv-req-t");
      const name = el("b", null, job.title || "Untitled");
      if (!seenReq.has(job.id)) { seenReq.add(job.id); scramble(name, job.title || "Untitled"); }
      who.append(name);
      if (job.asked) who.append(el("small", null, `asked for “${job.asked}”`));
      else if (job.subtitle) who.append(el("small", null, job.subtitle));
      const yes = el("button", "bv-yes", "Play it");
      yes.type = "button";
      yes.onclick = (e) => { window.YCFX?.spark(e); approveRequest(job); };
      const no = el("button", "bv-no", "No");
      no.type = "button";
      no.onclick = () => rejectRequest(job);
      row.append(who, yes, no);
      return row;
    }));
  }

  function bvNow() {
    const running = [...state.jobs.values()].find(j => j.status === "running");
    $("#bv-now-none").hidden = !!running;
    // "Nothing downloading" is not news, and it cost a third of the screen to say it. The strip
    // is there while something is actually arriving and gone the rest of the time.
    $("#boothview").classList.toggle("arriving", !!running);
    if (!running) { $("#bv-now").replaceChildren(); return; }
    // Made once per download and updated in place. Rebuilt on every tick, the light round it restarted
    // every two seconds and never finished a lap, and the bar jumped instead of sliding.
    let box = $("#bv-now").firstElementChild;
    if (!box || box.dataset.job !== running.id) {
      box = el("div", "bv-running");
      box.dataset.job = running.id;
      box.insertAdjacentHTML("beforeend", '<svg class="runlight" aria-hidden="true"><rect pathLength="100"></rect></svg>');
      const bar = el("div", "bv-bar");
      bar.append(el("i"));
      box.append(el("b"), el("small"), bar, el("span", "bv-pct"));
      $("#bv-now").replaceChildren(box);
    }
    const pct = Math.max(0, Math.min(100, (running.progress || 0) * 100));
    box.querySelector("b").textContent = running.title || "Untitled";
    box.querySelector("small").textContent = running.stage || "Working";
    box.querySelector(".bv-bar i").style.transform = `translateX(${pct - 100}%)`;
    box.querySelector(".bv-pct").textContent = `${Math.round(pct)}%`;
  }

  function bvCrate() {
    const q = $("#bv-search").value.trim().toLowerCase();
    const all = [...state.crate.values()].filter(t => !t.missing);
    // Newest first when nothing is typed: what you added for tonight is what you are reaching for.
    const hits = (q ? all.filter(t => (`${t.title} ${t.artist}`).toLowerCase().includes(q))
                    : [...all].sort((a, b) => (b.added || 0) - (a.added || 0)))
      .slice(0, 40);
    $("#bv-crate-n").textContent = all.length ? `${all.length}` : "";
    $("#bv-tracks-none").hidden = all.length > 0;
    if (q && all.length && !hits.length) {
      $("#bv-tracks-none").hidden = false;
      $("#bv-tracks-none").replaceChildren(el("b", null, `Nothing matching “${$("#bv-search").value.trim()}”.`));
    } else if (all.length) {
      $("#bv-tracks-none").hidden = true;
    }
    $("#bv-tracks").replaceChildren(...hits.map(t => {
      const row = el("div", "bv-track");
      const who = el("div", "bv-req-t");
      who.append(el("b", null, t.title || t.name), el("small", null, t.artist || ""));
      const meta = el("span", "bv-meta",
        [t.bpm ? `${Math.round(t.bpm)}` : "", t.camelot || ""].filter(Boolean).join("  ·  "));
      row.append(keptCover("bv:" + t.id, t, "bvart"), who, meta);
      return row;
    }));
  }

  // What has actually left the building tonight. Dragging a track into rekordbox or Serato is
  // the nearest thing this app has to "I played that" - it has no player and does not pretend to -
  // and a finished booth request is the other. Kept for this run of the app, newest first.
  const outTonight = [];
  function noteOut(track) {
    if (!track) return;
    const name = track.title || track.name || "";
    if (!name || outTonight[0] === name) return;
    outTonight.unshift(name);
    outTonight.splice(8);
    if (boothOpen) bvOut();
  }

  function bvOut() {
    const box = $("#bv-out");
    box.hidden = !outTonight.length;
    if (!outTonight.length) return;
    $("#bv-out-list").replaceChildren(...outTonight.map((name, i) => {
      const row = el("div", "bv-out-row" + (i ? "" : " latest"));
      row.append(el("span", null, name));
      return row;
    }));
  }

  function drawBooth() {
    if (!boothOpen) return;
    bvRequests();
    bvNow();
    bvCrate();
    bvOut();
  }

  // Into the booth and back is the same move as signing in: where you are going comes up from behind,
  // and what you leave passes the camera. Going in, the app rushes past as the booth rises; coming out,
  // the booth rushes past and the app rises with the sign-in's own entrance. Nothing waits on it -
  // every button works from the first frame - and a quick in-and-out cancels whatever was pending.
  let boothSwap = 0, boothHide = 0;
  function openBooth() {
    const root = document.documentElement;
    if (boothOpen || root.classList.contains("locked")) return;
    boothOpen = true;
    // What was already waiting when you walked in just shows; only new arrivals resolve.
    [...state.jobs.values()].filter(j => j.status === "held").forEach(j => seenReq.add(j.id));
    clearTimeout(boothHide);
    clearTimeout(boothSwap);
    const bv = $("#boothview");
    bv.classList.remove("leaving");
    bv.hidden = false;
    if (REDUCED) root.classList.add("in-booth");
    else {
      root.classList.add("to-booth");
      boothSwap = setTimeout(() => { root.classList.remove("to-booth"); if (boothOpen) root.classList.add("in-booth"); }, 540);
    }
    drawBooth();
    // Actually full screen, not just maximised: the taskbar across the bottom of a booth view is
    // exactly the thing this view exists to get rid of. Refused politely if the browser says no -
    // and we have to know which, because it decides whether Escape reaches us at all.
    boothFull = false;
    try {
      const full = document.documentElement.requestFullscreen?.({ navigationUI: "hide" });
      if (full && full.catch) full.catch(() => {});   // refused is fine; Escape reaches us instead
    } catch (e) {}
    if (!(boothInfo && boothInfo.on)) startBoothLink();
    boothSince = Date.now();
    const clock = () => {
      $("#bv-clock").textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      const mins = Math.floor((Date.now() - boothSince) / 60000);
      $("#bv-since").textContent = mins < 1 ? "just started"
        : mins < 60 ? `${mins} min in`
        : `${Math.floor(mins / 60)}h ${String(mins % 60).padStart(2, "0")} in`;
    };
    clock();
    boothTick = setInterval(() => { clock(); drawBooth(); }, 2000);
    requestAnimationFrame(() => $("#boothview").classList.add("show"));
  }

  // Leaving the view does not close the public link. Someone is holding a phone with that code
  // on it; dropping it because the DJ wanted to look at a setting is a worse surprise than a link
  // that stays until it is closed. The banner across the main screen says while it is open.
  function closeBooth() {
    if (!boothOpen) return;
    boothOpen = false;
    boothFull = false;
    clearInterval(boothTick);
    if (document.fullscreenElement) { try { document.exitFullscreen(); } catch (e) {} }
    const root = document.documentElement, bv = $("#boothview");
    clearTimeout(boothSwap);
    root.classList.remove("to-booth", "in-booth");
    bv.classList.remove("show");
    if (!REDUCED) {
      bv.classList.add("leaving");
      clearTimeout(enterTimer);
      root.classList.remove("entering", "from-booth");
      void root.offsetWidth;
      root.classList.add("entering", "from-booth");
      enterTimer = setTimeout(() => root.classList.remove("entering", "from-booth"), 1450);
    }
    boothHide = setTimeout(() => { bv.hidden = true; bv.classList.remove("leaving"); }, REDUCED ? 0 : 480);
  }

  // In full screen the browser keeps Escape for itself - it leaves full screen and tells the page
  // nothing, which is why the keydown handler below looked broken from inside the booth. Leaving
  // full screen is the signal, however it was done: Escape, F11, or the window manager.
  addEventListener("fullscreenchange", () => {
    if (!boothOpen) return;
    if (document.fullscreenElement) { boothFull = true; return; }   // we are in, and now we know it
    if (boothFull) closeBooth();
  });

  $("#bv-leave").onclick = closeBooth;
  $("#bv-search").addEventListener("input", bvCrate);

  // ── one bar for everything ──────────────────────────────────────────────────────────────
  // Nine things worth reaching without looking, in one list you filter by typing. The "what" line
  // on each is filled in from the app's own state, so the bar tells you what it is about to do to
  // something real - "approve the 3 waiting requests", not "approve requests".
  function commands() {
    const waiting = [...state.jobs.values()].filter(j => j.status === "held").length;
    const chosen = state.active ? (state.crate.get(state.active) || {}) : null;
    const booth = boothInfo && boothInfo.on;
    return [
      { name: "Search for a song, or paste a link", what: "Home",
        run: () => { goToSection("get"); const b = $("#link-input"); b.focus(); b.select(); } },
      { name: "Go to your crate", what: `${state.crate.size} track${state.crate.size === 1 ? "" : "s"}`,
        run: () => { goToSection("crate"); setTimeout(() => $("#crate-search").focus(), REDUCED ? 0 : 260); } },
      { name: "Go to your set", what: currentSet() ? `${currentSet().name} · ${currentSet().tracks.length} tracks` : "Plan a night",
        run: () => goToSection("set") },
      { name: "See your gigs", what: "The client's must-plays and do-not-plays", run: () => goToSection("gigs") },
      { name: "See your crate's insights", what: "Keys, tempos and the gaps", run: () => goToSection("insights") },
      { name: "See what changed", what: "Every change, with Undo", run: () => openSettings("changes") },
      { name: "Check I'm ready for tonight", what: "Runs all ten checks",
        run: () => { goToSection("get"); setTimeout(() => $("#pf-run").click(), REDUCED ? 0 : 300); } },
      { name: booth ? "Turn booth mode off" : "Turn booth mode on",
        what: booth ? "Closes the public link" : "Opens a public link, checked before you get it",
        run: () => { goToSection("phone"); setTimeout(() => $("#booth-on").click(), REDUCED ? 0 : 300); } },
      waiting ? { name: `Approve the ${waiting} waiting request${waiting === 1 ? "" : "s"}`,
                  what: "From the booth link",
                  run: async () => {
                    // The backend has had requests_approve_all since booth mode; nothing ever called
                    // it. Every held row is flipped here first and reconciled by the push, so a
                    // queue of ten does not redraw ten times over the wire.
                    const held = [...state.jobs.values()].filter(j => j.status === "held");
                    held.forEach(j => renderJob({ ...j, status: "waiting", stage: "Waiting" }));
                    const r = await call("requests_approve_all");
                    refreshBooth().catch(() => {});
                    toast(`${r.approved} request${r.approved === 1 ? "" : "s"} approved - downloading now.`);
                  } } : null,
      chosen ? { name: `Star “${chosen.title || "the selected track"}”`,
                 what: `Currently ${chosen.rating || 0} of 5`,
                 run: async () => { const next = ((chosen.rating || 0) % 5) + 1;
                                    const r = await call("set_marks", chosen.id, next, null);
                                    syncCrate(r.crate); renderSmart(r.smart);
                                    toast(`“${chosen.title}” — ${next} star${next === 1 ? "" : "s"}`); } } : null,
      { name: "Write the rekordbox library now", what: "Instead of waiting for the next change",
        run: async () => {
          goToSection("djsoft");
          if (!state.settings.rekordbox_enabled) return toast("The rekordbox link is off. Turn it on in section 05 first.", true);
          rbInfo = await call("rekordbox_write");
          renderRekordbox();
          toast("rekordbox library written.");
        } },
      { name: "Open the save folder", what: state.settings.output_dir || "",
        run: () => call("open_folder") },
      { name: boothOpen ? "Leave booth view" : "Open booth view",
        what: "Three things, at arm's length", run: () => (boothOpen ? closeBooth() : openBooth()) },
      { name: "Open settings", what: "Save folder, theme, library, shortcuts, backups, key, account",
        run: () => openSettings() },
      { name: "Change the app's colour", what: "Settings - Theme", run: () => openSettings("theme") },
      { name: "Lock the app", what: "Back to the password", run: () => api.lock().then(() => location.reload()) },
    ].filter(Boolean);
  }

  let palOpen = false, palPick = 0, palHits = [];

  function drawPalette() {
    const q = $("#palette-input").value.trim().toLowerCase();
    // Every word has to appear somewhere, in any order - so "booth on" and "on booth" both find it.
    const words = q.split(/\s+/).filter(Boolean);
    palHits = [...commands(), ...(window.YCMore ? YCMore.settingsCommands() : [])].filter(c => {
      const hay = (c.name + " " + c.what).toLowerCase();
      return words.every(w => hay.includes(w));
    });
    palPick = Math.max(0, Math.min(palPick, palHits.length - 1));
    const list = $("#palette-list");
    if (!palHits.length) {
      const none = el("div", "palette-none", "Nothing matches that.");
      list.replaceChildren(none);
      return;
    }
    list.replaceChildren(...palHits.map((c, i) => {
      const row = el("button", "palette-cmd");
      row.type = "button";
      row.setAttribute("role", "option");
      row.setAttribute("aria-selected", i === palPick ? "true" : "false");
      row.append(el("span", null, c.name), el("span", "palette-what", c.what));
      row.onmouseenter = () => { palPick = i; markPick(); };
      row.onclick = () => firePalette(i);
      return row;
    }));
    markPick();
  }

  function markPick() {
    const rows = [...$("#palette-list").children];
    rows.forEach((row, i) => row.setAttribute("aria-selected", i === palPick ? "true" : "false"));
    const on = rows[palPick];
    if (on && on.scrollIntoView) on.scrollIntoView({ block: "nearest" });
  }

  function firePalette(i) {
    const cmd = palHits[i];
    closePalette();
    if (cmd) Promise.resolve().then(cmd.run).catch(() => toast("That didn't work.", true));
  }

  function openPalette() {
    if (palOpen || document.documentElement.classList.contains("locked")) return;
    palOpen = true;
    palPick = 0;
    $("#palette-input").value = "";
    $("#palette").hidden = false;
    drawPalette();
    requestAnimationFrame(() => {
      $("#palette").classList.add("show");
      $("#palette-input").focus();
    });
  }

  function closePalette() {
    if (!palOpen) return;
    palOpen = false;
    $("#palette").classList.remove("show");
    setTimeout(() => { $("#palette").hidden = true; }, REDUCED ? 0 : 160);
  }

  $("#palette").onclick = (e) => { if (e.target === $("#palette")) closePalette(); };
  $("#palette-input").addEventListener("input", () => { palPick = 0; drawPalette(); });
  $("#palette-input").addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); palPick = Math.min(palPick + 1, palHits.length - 1); markPick(); }
    else if (e.key === "ArrowUp") { e.preventDefault(); palPick = Math.max(palPick - 1, 0); markPick(); }
    else if (e.key === "Enter") { e.preventDefault(); firePalette(palPick); }
    else if (e.key === "Escape") { e.preventDefault(); closePalette(); }
  });

  // ── keys ──────────────────────────────────────────────────────────────────────────────────
  // A booth is dark, the laptop is on something wobbly, and a trackpad is the worst input device
  // ever devised for a hurry. Which keys, though, is the DJ's business: Ctrl+K is "delete to end of
  // line" on a Mac and / needs a shift on some layouts. So the bindings live in settings and this
  // reads them, which also means the settings card below and the keys themselves cannot disagree.
  // The rail scrolls a section into view and nothing else; there is no go(), which an earlier
  // version of this assumed and would have thrown on every press.
  // "settings:<group>" opens the Settings page on that group instead.
  const goToSection = (id) => {
    if (id.startsWith("settings")) return openSettings(id.split(":")[1]);
    closeSettings();
    window.YCS.to(id);
  };
  const KEY_ACTIONS = [
    ["search", "Open the command bar", openPalette],
    ["crate", "Jump to your crate", () => { goToSection("crate"); setTimeout(() => $("#crate-search").focus(), REDUCED ? 0 : 260); }],
    ["booth", "Open booth view", () => (boothOpen ? closeBooth() : openBooth())],
    ["close", "Clear the box, or close what's open", null],   // handled below: it has to see the target
  ];
  const DEFAULT_KEYS = { search: "Ctrl+K", crate: "/", booth: "Ctrl+B", close: "Escape" };
  const keyBindings = () => ({ ...DEFAULT_KEYS, ...((state.settings || {}).shortcuts || {}) });

  // "Ctrl+Shift+K", "/", "Escape", "F5" - written the way it will be shown, so the comparison and
  // the label are the same string and there is nothing to keep in step.
  function comboOf(e) {
    const key = e.key;
    if (!key || ["Control", "Meta", "Shift", "Alt"].includes(key)) return "";
    const parts = [];
    if (e.ctrlKey || e.metaKey) parts.push("Ctrl");
    if (e.altKey) parts.push("Alt");
    // Shift counts for letters, whose case this throws away a line below, and for named keys like
    // Tab. It must NOT count for symbols: shift and / is "?", and the key already says so - adding
    // Shift as well would make "Shift+?" and lose the plain "?" binding entirely.
    if (e.shiftKey && (key.length > 1 || /^[a-z]$/i.test(key))) parts.push("Shift");
    parts.push(key.length === 1 ? key.toUpperCase() : key);
    return parts.join("+");
  }

  let capturing = null;                       // the action currently waiting for a keystroke

  addEventListener("keydown", e => {
    if (capturing) return;                    // the settings card is listening instead
    if (!introDone || document.documentElement.classList.contains("locked")) return;
    // Holding a key is one press, not forty - except up and down, where holding is how you move
    // through a long list.
    if (e.repeat && e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    const combo = comboOf(e);
    if (!combo) return;
    const bound = keyBindings();
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target || {}).tagName || "");

    // Close is special: it needs to know what is focused, and it is the one binding that still
    // does something useful while you are typing.
    // Up and down move through the crate when it is what you are looking at, so a mix can be
    // found without touching the trackpad. Only when nothing is focused and no bar is open.
    const mod = e.ctrlKey || e.metaKey || e.altKey || e.shiftKey;
    if ((e.key === "ArrowDown" || e.key === "ArrowUp") && !typing && !palOpen && !mod && !settingsOpen) {
      const ids = visibleIds();
      if (ids.length) {
        const at = ids.indexOf(state.active);
        const next = e.key === "ArrowDown"
          ? ids[Math.min(at + 1, ids.length - 1)] ?? ids[0]
          : ids[Math.max(at - 1, 0)] ?? ids[0];
        if (next) {
          e.preventDefault();
          closeOpen();
          selectTrack(next, "list");
          return;
        }
      }
    }
    if (combo === bound.close) {
      if (palOpen) { e.preventDefault(); closePalette(); return; }
      if (boothOpen) { e.preventDefault(); closeBooth(); return; }
      if (!previewBox.hidden && previewBox.classList.contains("show")) { e.preventDefault(); closePreview(); return; }
      if (settingsOpen && !typing && $("#trial").hidden) { e.preventDefault(); closeSettings(); return; }
      if (typing && e.target.value) { e.preventDefault(); e.target.value = ""; e.target.dispatchEvent(new Event("input")); return; }
      if (typing) { e.target.blur(); return; }
      return;
    }
    for (const [action, , run] of KEY_ACTIONS) {
      if (!run || combo !== bound[action]) continue;
      // A bare letter or symbol must not hijack typing; a combination may.
      if (typing && !/\+/.test(combo)) return;
      e.preventDefault();
      run();
      return;
    }
  });

  // ── choosing them ──────────────────────────────────────────────────────
  function renderShortcuts() {
    const box = $("#shortcut-rows");
    if (!box) return;
    const bound = keyBindings();
    box.replaceChildren(...KEY_ACTIONS.map(([action, label]) => {
      const row = el("div", "sc-row");
      row.append(el("span", "sc-what", label));
      const btn = el("button", "sc-key", bound[action] || "off");
      btn.type = "button";
      btn.title = "Click, then press the keys you want";
      btn.onclick = () => {
        if (capturing) return;
        capturing = action;
        btn.classList.add("listening");
        btn.textContent = "press keys…";
        const done = async (e) => {
          e.preventDefault();
          e.stopPropagation();
          const combo = e.key === "Backspace" ? "" : comboOf(e);
          if (!combo && e.key !== "Backspace") return;       // a lone modifier: keep waiting
          removeEventListener("keydown", done, true);
          capturing = null;
          const next = { ...keyBindings(), [action]: combo };
          // Two actions on one key would make the second unreachable, so the older one gives way.
          for (const other of Object.keys(next)) {
            if (other !== action && combo && next[other] === combo) next[other] = "";
          }
          state.settings = await call("set_setting", "shortcuts", next);
          renderShortcuts();
        };
        addEventListener("keydown", done, true);
      };
      row.append(btn);
      return row;
    }));
  }

  $("#shortcut-reset").onclick = async () => {
    state.settings = await call("set_setting", "shortcuts", DEFAULT_KEYS);
    renderShortcuts();
    toast("Shortcuts back to how they started.");
  };

  const skipIntro = () => { if (boot && !introDone) { finishIntro(); removeEventListener("keydown", skipIntro); } };
  addEventListener("keydown", skipIntro);
  setTimeout(() => { if (boot) finishIntro(); }, 12000);
  // Opened in a plain browser (design preview): no backend, so show the setup screen.
  setTimeout(() => {
    // Inside the app the web view says so from the first moment (WebView2: window.chrome.webview; macOS: WebKit's
    // message handlers), even when Python's bridge is slow - a cold start right after an update took longer than this
    // wait, and the page took itself for a browser preview: a made-up start-up and no window buttons.
    if (window.pywebview || window.chrome?.webview || window.webkit?.messageHandlers) return;
    document.documentElement.classList.add("no-chrome");
    const returning = location.hash.includes("returning");
    boot = { has_account: returning, dj: returning ? "Yoshi C" : "", unlocked: false, platform: "windows" };
    if (returning) showIntroName(boot.dj);
    step("bridge"); step("boot", "Preview · no backend");
  }, 1200);
  showKind();

  // What more.js (the same file in both apps) needs from this one: the bridge, the settings, and the steps of
  // Get set up - each ticks itself off from what the app can already see.
  window.YCA = {
    api: () => api, settings: () => state.settings, saved: s => { if (s && typeof s === "object") state.settings = s; },
    toast, openSettings, closeSettings,
    setup: () => {
      const st = state.settings || {};
      return { steps: [
        { id: "music", title: "Bring in your music", hint: "Drop tracks or a whole folder on the window - or point DJ Master at your music folder",
          done: state.crate.size > 0, goLabel: "Add a folder", go: () => openSettings("library") },
        { id: "mixes", title: "See what mixes with a track", hint: "Click any track in your crate", done: !!state.active,
          go: () => goToSection("crate") },
        { id: "djsoft", title: "Put your crate in your DJ software", hint: "Two minutes, once",
          done: !!(st.rekordbox_enabled || st.serato_enabled || st.virtualdj_enabled || st.traktor_enabled), go: () => goToSection("djsoft") },
        { id: "phone", title: "Take a request from your phone", hint: "Scan a code, ask for a song", done: !!st.remote_enabled, go: () => goToSection("phone") },
        { id: "ready", title: "Run the checks before a gig", hint: "Ten checks, about twenty seconds", done: false,
          goLabel: "Check I'm ready", go: () => { goToSection("get"); setTimeout(() => $("#pf-run").click(), 400); } },
      ] };
    },
  };
  if (window.YCMore) YCMore.ready();
})();
