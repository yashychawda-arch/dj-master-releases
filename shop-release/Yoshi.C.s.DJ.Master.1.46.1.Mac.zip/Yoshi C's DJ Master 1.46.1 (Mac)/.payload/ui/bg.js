/* Background: liquid marble smoke.

   A slowly folding field (domain-warped fractal noise) split into bright
   silver masses and deep black pools. The masses are combed with fine
   contour striations - the agate / wood-grain lines - and the pools fall off
   into soft glow. Signal red lives only on the brightest crests and as a
   faint rim where light meets black.

   Readability: the CSS scrim darkens the content column, so text never sits
   on bright texture. Cost: rendered below native resolution at 30 fps (the
   scale steps down automatically on slow GPUs), paused while the window is
   hidden, drawn once for reduced-motion users, and skipped entirely without
   WebGL (the CSS glows stay as a fallback). */
(() => {
  const canvas = document.getElementById("bg");
  const gl = canvas && canvas.getContext("webgl", { antialias: false, alpha: false, powerPreference: "low-power" });
  if (!gl) return;
  document.documentElement.classList.add("has-webgl");

  const vert = `
    attribute vec2 p;
    void main() { gl_Position = vec4(p, 0.0, 1.0); }`;

  const frag = `
    precision highp float;
    uniform vec2 res;
    uniform float t;          // flow phase, integrated on the CPU (see draw) - not wall-clock time
    uniform vec2 pointer;
    uniform float activity;
    uniform vec3 accent;        // the theme colour, set from the page (Settings > Theme)

    float hash(vec2 p) {
      vec3 p3 = fract(vec3(p.xyx) * 0.1031);
      p3 += dot(p3, p3.yzx + 33.33);
      return fract((p3.x + p3.y) * p3.z);
    }
    float noise(vec2 p) {
      vec2 i = floor(p), f = fract(p);
      vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);   // quintic: smooth derivatives, clean contours
      return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x),
                 mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
    }
    // Few octaves on purpose: smooth, large forms so the contour lines run long and even.
    float fbm(vec2 p) {
      float v = 0.0, a = 0.5;
      mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
      for (int i = 0; i < 3; i++) { v += a * noise(p); p = m * p; a *= 0.5; }
      return v / 0.875;
    }

    void main() {
      vec2 p = (gl_FragCoord.xy - 0.5 * res) / res.y;
      vec2 uv = gl_FragCoord.xy / res;
      float s = t;

      // Large-scale structure: two or three big masses across the window, folding slowly.
      vec2 base = p * 0.62;
      vec2 q = vec2(fbm(base + vec2(0.0, s)), fbm(base + vec2(5.2, 1.3) - s * 0.8));
      vec2 r = vec2(fbm(base * 1.3 + 2.4 * q + vec2(1.7, 9.2) + s * 0.4),
                    fbm(base * 1.3 + 2.4 * q + vec2(8.3, 2.8) - s * 0.35));
      vec2 toPointer = p - pointer;
      r += 0.08 * exp(-dot(toPointer, toPointer) * 5.0) * vec2(-toPointer.y, toPointer.x);
      float f = fbm(base * 1.6 + 2.2 * r);

      // Silver masses vs black pools, with a long soft glowing falloff between them.
      float d = smoothstep(0.42, 0.80, f);
      float mass = pow(d, 1.6) + 0.18 * smoothstep(0.75, 1.0, d);

      // Striations: thin dark hairlines, densely packed and slightly irregular in spacing.
      // A little detail noise in the phase makes the hairlines wander like smoke, not a contour map.
      float wobble = noise(p * 9.0 + r * 3.0 + s * 2.0) * 2.2;
      float lines = 0.5 - 0.5 * cos(f * 240.0 + r.y * 5.0 + wobble);
      float hair = pow(lines, 5.0);
      float grain = 1.0 - 0.24 * hair;
      // A slower set of bands gives the agate layering between the hairlines.
      float layers = 0.5 + 0.5 * cos(f * 34.0 + r.x * 3.0);
      grain *= mix(0.86, 1.0, layers);
      float lines2 = 1.0 - lines;   // bright side of the grain, used for red crests

      float lum = mass * grain * 0.72;

      // Keep a darker heart behind the content column; the margins carry the texture.
      vec2 c = (uv - 0.5) * vec2(res.x / res.y, 1.0);
      float edge = mix(0.38, 1.0, smoothstep(0.12, 0.85, length(c * vec2(0.9, 1.1))));
      lum *= edge;

      vec3 silver = vec3(0.76, 0.72, 0.72);
      vec3 signal = accent;                  // the app's accent colour
      vec3 col = silver * lum;

      // Lime on the brightest crests of the grain...
      // A slow drifting patch decides where red shows up, so it's a hint in places, not a tint everywhere.
      float zone = smoothstep(0.42, 0.72, fbm(p * 0.9 - s * 0.6 + vec2(3.1, 7.7)));
      float crest = smoothstep(0.30, 0.70, lum) * smoothstep(0.45, 1.0, lines2) * zone;
      col = mix(col, signal * (lum + 0.16), crest * (0.55 + 0.25 * activity));
      // ...a glowing red rim where the silver drops into black...
      float rim = smoothstep(0.02, 0.28, d) * (1.0 - smoothstep(0.28, 0.66, d));
      col += signal * rim * edge * (0.10 + 0.08 * activity) * (0.35 + 0.65 * zone);
      // ...and the odd hairline that catches the light outright.
      float spark = pow(lines2, 24.0) * smoothstep(0.35, 0.8, d) * smoothstep(0.6, 0.9, zone);
      col += signal * spark * edge * 0.28;

      col += vec3(0.039, 0.031, 0.031) * (1.0 - lum);   // pools settle on #0a0808, not pure black
      gl_FragColor = vec4(col, 1.0);
    }`;

  function compile(type, src) {
    const sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh));
    return sh;
  }
  let prog;
  try {
    prog = gl.createProgram();
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, vert));
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, frag));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  } catch (e) {
    console.warn("background shader disabled:", e);
    document.documentElement.classList.remove("has-webgl");
    return;
  }
  gl.useProgram(prog);

  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, "p");
  gl.enableVertexAttribArray(loc);
  gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

  const uRes = gl.getUniformLocation(prog, "res");
  const uT = gl.getUniformLocation(prog, "t");
  const uPointer = gl.getUniformLocation(prog, "pointer");
  const uActivity = gl.getUniformLocation(prog, "activity");
  const uAccent = gl.getUniformLocation(prog, "accent");
  let accent = [1.0, 0.30, 0.30];
  window.bgAccent = (r, g, b) => { accent = [r, g, b]; if (reduced && active()) draw(performance.now()); };

  // Fine striations need resolution; start at 0.75 and step down if frames run long.
  let scale = 0.75;
  function resize() {
    const w = Math.max(1, Math.round(innerWidth * scale));
    const h = Math.max(1, Math.round(innerHeight * scale));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
      gl.viewport(0, 0, w, h);
    }
  }
  addEventListener("resize", () => { resize(); if (reduced && active()) draw(performance.now()); });
  resize();

  const pointer = { x: 0.6, y: 0.2, tx: 0.6, ty: 0.2 };
  addEventListener("pointermove", e => {
    pointer.tx = (e.clientX - innerWidth / 2) / innerHeight;
    pointer.ty = -(e.clientY - innerHeight / 2) / innerHeight;
  });
  let activity = 0, activityTarget = 0, splitting = false;
  window.bgActivity = v => { activityTarget = Math.max(0, Math.min(1, v)); splitting = v > 0; };

  // The smoke only changes pace while a song is splitting: it draws at 20 fps then, handing the rest
  // of the GPU to the split. At every other time it runs at a steady 30 fps - 1.2.0 also paused it
  // while scrolling and when the window lost focus, and at 15 fps during a split; Yoshi found the
  // stopping distracting and 15 fps shaky, so both went.

  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  let last = 0, slow = 0;

  // Flow phase. This used to be computed in the shader as elapsed * (0.03 + 0.025 * activity), which
  // rescaled the WHOLE elapsed time whenever activity changed - so every time a song started or
  // finished, the smoke fast-forwarded through everything since launch (ten minutes open = a
  // ~150x-speed lurch lasting a few seconds, worse the longer the window had been open). Integrating
  // speed per frame means a change in speed only ever affects the motion from that moment on.
  let phase = (20 + Math.random() * 40) * 0.03;   // random start so the field differs each launch
  let lastDraw = 0;

  function draw(now) {
    // Clamped so a hidden tab (frames paused) or a stalled frame resumes smoothly instead of jumping.
    const dt = lastDraw ? Math.min(0.1, (now - lastDraw) / 1000) : 0;
    lastDraw = now;
    // Same easing as the old per-frame 0.03 / 0.02 steps at 30 fps, written against time instead of frames.
    const kPointer = 1 - Math.exp(-dt * 0.914), kActivity = 1 - Math.exp(-dt * 0.606);
    pointer.x += (pointer.tx - pointer.x) * kPointer;
    pointer.y += (pointer.ty - pointer.y) * kPointer;
    activity += (activityTarget - activity) * kActivity;
    phase += dt * (0.03 + 0.025 * activity);
    gl.uniform2f(uRes, canvas.width, canvas.height);
    gl.uniform1f(uT, phase);
    gl.uniform2f(uPointer, pointer.x, pointer.y);
    gl.uniform1f(uActivity, activity);
    gl.uniform3f(uAccent, accent[0], accent[1], accent[2]);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  // Frame budget. The frame rate is 30 fps, or 20 fps while splitting, and nothing else changes it.
  // If frames still run long for a couple of seconds (a slow GPU), resolution steps down instead -
  // never below 0.6, where the fine hairlines hold together (at 0.4 they aliased into shimmering
  // dots). The phase is integrated per frame in draw(), so moving between 30 and 20 fps is seamless.
  // A minimised or fully hidden window draws nothing: there's nothing to see.
  const active = () => !document.hidden && !document.documentElement.classList.contains("wall-off");
  let raf = 0;
  function frame(now) {
    raf = 0;
    if (!active()) { last = 0; lastDraw = 0; return; }
    const interval = splitting ? 50 : 33;
    if (now - last >= interval) {
      if (last && now - last > interval * 1.8) slow++; else slow = Math.max(0, slow - 1);
      if (slow > 60 && scale > 0.6) { slow = 0; scale = Math.max(0.6, scale - 0.075); resize(); }
      last = now;
      draw(now);
    }
    raf = requestAnimationFrame(frame);
  }
  function syncAnimation() {
    if (!active()) {
      if (raf) cancelAnimationFrame(raf);
      raf = 0; last = 0; lastDraw = 0;
    } else if (reduced) draw(performance.now());
    else if (!raf) raf = requestAnimationFrame(frame);
  }
  document.addEventListener("visibilitychange", syncAnimation);
  let wallpaperOff = document.documentElement.classList.contains("wall-off");
  new MutationObserver(() => {
    const off = document.documentElement.classList.contains("wall-off");
    if (off !== wallpaperOff) { wallpaperOff = off; syncAnimation(); }
  }).observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
  syncAnimation();
  requestAnimationFrame(() => canvas.classList.add("in"));
})();
