// The effects picked from the catalogue for the apps (artifact "Yoshi C Effects", round two, 5 Oct: A1-A10), shared
// by both editions. app.js calls in where each one belongs; styles are in fx.css. Timings follow the transitions.dev
// motion scale: 150 ms for small answers, 250 ms for opens, closes quicker than opens, nothing on a loop unless it
// shows work being done.
//   A1 rail      the rail's names lean out near the pointer          A6 (fx.css) a light runs round the busy job
//   A2 wheel     the key filter as a wheel you spin                  A7 sweep    a band of light down the crate while it's read
//   A3 roll      the readout's digits roll to the new figure         A8 hints    the empty search types out things to try
//   A4 folder    crates as folders that open, tracks on slips        A9 glint    a glint across a cover you point at
//   A5 spark     a ring of sparks when you approve a request         A10 steps   first-run setup, one step at a time
(() => {
  const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const smooth = (t) => t * t * (3 - 2 * t);
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const signal = () => getComputedStyle(document.documentElement).getPropertyValue("--signal").trim() || "#ff4d4d";
  const FX = (window.YCFX = {});

  // ── A1 ─────────────────────────────────────────────────────────────────────────────────────────────────
  // Names within 70 px (up or down) of the pointer show, on a smooth curve, their mark growing; the section you're
  // on always shows its name. A keyboard focus shows that one name.
  FX.rail = (rail) => {
    if (!rail) return;
    const items = [...rail.querySelectorAll(".rail-item")];
    const set = (it, k) => it.style.setProperty("--k", k.toFixed(3));
    rail.addEventListener("pointermove", (e) => items.forEach((it) => {
      const r = it.getBoundingClientRect(), d = Math.abs(e.clientY - (r.top + r.height / 2));
      set(it, smooth(clamp(1 - d / 70, 0, 1)));
    }));
    rail.addEventListener("pointerleave", () => items.forEach((it) => set(it, 0)));
    items.forEach((it) => { it.addEventListener("focus", () => set(it, 1)); it.addEventListener("blur", () => set(it, 0)); });
    rail.classList.add("fx-rail");
  };

  // ── A2 ─────────────────────────────────────────────────────────────────────────────────────────────────
  // A <select> gets a wheel: press it with a pointer and the options sit on a drum (22 degrees a step) under it,
  // curling away and blurring above and below the pick. Scroll, drag or use the arrow keys; Enter, a click on the
  // middle or a click outside keeps it, Escape leaves it as it was. The select stays the real control - the keyboard
  // still works on it as always, and the choice is set on it with a change event.
  FX.wheel = (select) => {
    if (!select || select._wheel) return;
    select._wheel = true;
    let pop = null;
    const close = (keep) => {
      if (!pop) return;
      const { node, pick, onDoc, onKey } = pop;
      document.removeEventListener("pointerdown", onDoc, true); document.removeEventListener("keydown", onKey, true);
      node.classList.add("out"); setTimeout(() => node.remove(), REDUCED ? 0 : 150);
      if (keep && select.selectedIndex !== pick()) { select.selectedIndex = pick(); select.dispatchEvent(new Event("change", { bubbles: true })); }
      pop = null;
      select.focus({ preventScroll: true });
    };
    const open = () => {
      const opts = [...select.options].map((o) => o.text), n = opts.length;
      const node = mk("div", "fx-wheel"), drum = mk("div", "fx-drum");
      node.setAttribute("role", "listbox"); node.setAttribute("aria-label", select.getAttribute("aria-label") || "Choose");
      const nodes = opts.map((t) => { const s = mk("span", "fx-it", t); s.setAttribute("role", "option"); drum.append(s); return s; });
      node.append(drum, mk("i", "fx-pin"));
      document.body.append(node);
      const r = select.getBoundingClientRect(), w = Math.max(180, r.width + 40);
      node.style.left = `${clamp(r.left - 10, 8, innerWidth - w - 8)}px`; node.style.width = `${w}px`;
      node.style.top = `${clamp(r.top + r.height / 2 - 110, 8, innerHeight - 228)}px`;
      const STEP = 22, R = 30 / Math.sin((STEP * Math.PI) / 180);
      let pos = select.selectedIndex, target = pos, raf = 0, idle = 0, drag = null, moved = 0;
      const render = () => nodes.forEach((s, i) => {
        const o = i - pos, a = Math.abs(o);
        if (a > 3.6) { s.style.visibility = "hidden"; return; }
        const rad = (o * STEP * Math.PI) / 180;
        s.style.visibility = "";
        s.style.transform = `translate3d(${(a * a * 2).toFixed(1)}px, ${(Math.sin(rad) * R).toFixed(1)}px, ${((Math.cos(rad) - 1) * R).toFixed(1)}px) rotateX(${(-o * STEP).toFixed(1)}deg)`;
        s.style.opacity = String(clamp(1 - a * 0.27, 0, 1));
        s.style.filter = a < 0.05 ? "" : `blur(${(Math.min(a, 3) * 0.6).toFixed(2)}px)`;
        s.classList.toggle("cur", Math.round(pos) === i);
        s.setAttribute("aria-selected", String(Math.round(pos) === i));
      });
      const loop = () => { raf = 0; if (!drag) pos += (target - pos) * (REDUCED ? 1 : 0.2); if (Math.abs(target - pos) < 0.002) pos = target; render(); if (drag || pos !== target) raf = requestAnimationFrame(loop); };
      const go = () => { if (!raf) raf = requestAnimationFrame(loop); };
      const settle = () => { target = clamp(Math.round(target), 0, n - 1); go(); };
      node.addEventListener("wheel", (e) => { e.preventDefault(); target = clamp(target + e.deltaY / 80, -0.4, n - 0.6); clearTimeout(idle); idle = setTimeout(settle, 110); go(); }, { passive: false });
      node.addEventListener("pointerdown", (e) => { node.setPointerCapture(e.pointerId); drag = { y: e.clientY, p: pos, v: 0, t: performance.now(), ly: e.clientY }; moved = 0; go(); });
      node.addEventListener("pointermove", (e) => {
        if (!drag) return;
        const now = performance.now(); drag.v = (drag.ly - e.clientY) / Math.max(1, now - drag.t); drag.t = now; drag.ly = e.clientY;
        moved = Math.max(moved, Math.abs(e.clientY - drag.y));
        let p = drag.p + (drag.y - e.clientY) / 30; if (p < 0) p *= 0.35; if (p > n - 1) p = n - 1 + (p - (n - 1)) * 0.35;
        pos = target = p;
      });
      const up = (e) => {
        if (!drag) return;
        const wasTap = moved < 4, v = drag.v; drag = null;
        if (wasTap) {
          // A tap on an option picks it; a tap on the middle one keeps it.
          const hit = e && document.elementFromPoint(e.clientX, e.clientY)?.closest?.(".fx-it");
          const i = hit ? nodes.indexOf(hit) : -1;
          if (i === Math.round(pos)) { close(true); return; }
          if (i >= 0) target = i;
        } else target = pos + v * 6;
        settle();
      };
      node.addEventListener("pointerup", up); node.addEventListener("pointercancel", () => { drag = null; settle(); });
      const onKey = (e) => {
        const d = { ArrowDown: 1, ArrowUp: -1, PageDown: 5, PageUp: -5 }[e.key];
        if (d) { e.preventDefault(); e.stopPropagation(); target = clamp(Math.round(target) + d, 0, n - 1); go(); }
        else if (e.key === "Home" || e.key === "End") { e.preventDefault(); e.stopPropagation(); target = e.key === "Home" ? 0 : n - 1; go(); }
        else if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); close(true); }
        else if (e.key === "Escape" || e.key === "Tab") { e.preventDefault(); e.stopPropagation(); close(false); }
      };
      const onDoc = (e) => { if (!node.contains(e.target)) { e.preventDefault(); e.stopPropagation(); close(true); } };
      document.addEventListener("pointerdown", onDoc, true); document.addEventListener("keydown", onKey, true);
      pop = { node, pick: () => clamp(Math.round(pos), 0, n - 1), onDoc, onKey };
      render();
      requestAnimationFrame(() => node.classList.add("in"));
    };
    // A pointer opens the wheel instead of the system list; the keyboard keeps the select as it is.
    select.addEventListener("mousedown", (e) => { if (e.button !== 0) return; e.preventDefault(); select.focus({ preventScroll: true }); pop ? close(true) : open(); });
    select.classList.add("fx-wheel-select");
  };

  // The same wheel in place of a row of choice buttons (Stem Splitter's quality): the buttons stay in the page,
  // hidden, and stay the real control - settling on a choice presses its button, and whatever the app marks on
  // (.on) the wheel turns to. Arrow keys, scroll, drag, or a click on a choice.
  FX.wheelInline = (seg, notes) => {
    if (!seg || seg._wheel) return;
    seg._wheel = true;
    const buttons = [...seg.querySelectorAll("button")], n = buttons.length;
    const node = mk("div", "fx-wheel fx-wheel-inline in"), drum = mk("div", "fx-drum");
    node.tabIndex = 0;
    node.setAttribute("role", "listbox");
    node.setAttribute("aria-label", seg.getAttribute("aria-label") || seg.closest("[class]")?.querySelector(".label")?.textContent || "Choose");
    const nodes = buttons.map((b) => { const s = mk("span", "fx-it", b.textContent); s.setAttribute("role", "option"); drum.append(s); return s; });
    node.append(drum, mk("i", "fx-pin"));
    seg.after(node);
    seg.classList.add("fx-hidden");
    const on = () => Math.max(0, buttons.findIndex((b) => b.classList.contains("on")));
    const STEP = 26, R = 26 / Math.sin((STEP * Math.PI) / 180);
    let pos = on(), target = pos, raf = 0, idle = 0, drag = null, moved = 0, chosen = pos;
    const render = () => nodes.forEach((s, i) => {
      const o = i - pos, a = Math.abs(o), rad = (o * STEP * Math.PI) / 180;
      s.style.transform = `translate3d(${(a * a * 2).toFixed(1)}px, ${(Math.sin(rad) * R).toFixed(1)}px, ${((Math.cos(rad) - 1) * R).toFixed(1)}px) rotateX(${(-o * STEP).toFixed(1)}deg)`;
      s.style.opacity = String(clamp(1 - a * 0.32, 0, 1));
      s.style.filter = a < 0.05 ? "" : `blur(${(Math.min(a, 2) * 0.7).toFixed(2)}px)`;
      s.classList.toggle("cur", Math.round(pos) === i);
      s.setAttribute("aria-selected", String(Math.round(pos) === i));
    });
    const commit = () => { const i = clamp(Math.round(target), 0, n - 1); if (i !== chosen) { chosen = i; buttons[i].click(); } };
    const loop = () => { raf = 0; if (!drag) pos += (target - pos) * (REDUCED ? 1 : 0.2); if (Math.abs(target - pos) < 0.002) pos = target; render(); if (drag || pos !== target) raf = requestAnimationFrame(loop); };
    const go = () => { if (!raf) raf = requestAnimationFrame(loop); };
    const settle = () => { target = clamp(Math.round(target), 0, n - 1); commit(); go(); };
    node.addEventListener("wheel", (e) => { e.preventDefault(); target = clamp(target + e.deltaY / 80, -0.4, n - 0.6); clearTimeout(idle); idle = setTimeout(settle, 140); go(); }, { passive: false });
    node.addEventListener("pointerdown", (e) => { node.setPointerCapture(e.pointerId); drag = { y: e.clientY, p: pos, v: 0, t: performance.now(), ly: e.clientY }; moved = 0; go(); });
    node.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const now = performance.now(); drag.v = (drag.ly - e.clientY) / Math.max(1, now - drag.t); drag.t = now; drag.ly = e.clientY;
      moved = Math.max(moved, Math.abs(e.clientY - drag.y));
      let p = drag.p + (drag.y - e.clientY) / 30; if (p < 0) p *= 0.35; if (p > n - 1) p = n - 1 + (p - (n - 1)) * 0.35;
      pos = target = p;
    });
    const up = (e) => {
      if (!drag) return;
      const wasTap = moved < 4, v = drag.v; drag = null;
      if (wasTap) { const hit = document.elementFromPoint(e.clientX, e.clientY)?.closest?.(".fx-it"); const i = hit ? nodes.indexOf(hit) : -1; if (i >= 0) target = i; }
      else target = pos + v * 6;
      settle();
    };
    node.addEventListener("pointerup", up); node.addEventListener("pointercancel", () => { drag = null; settle(); });
    node.addEventListener("keydown", (e) => {
      const d = { ArrowDown: 1, ArrowUp: -1, ArrowRight: 1, ArrowLeft: -1 }[e.key];
      if (d) { e.preventDefault(); target = clamp(Math.round(target) + d, 0, n - 1); settle(); }
      else if (e.key === "Home" || e.key === "End") { e.preventDefault(); target = e.key === "Home" ? 0 : n - 1; settle(); }
    });
    // The app may set the choice itself (settings loading, another window): the wheel follows.
    new MutationObserver(() => { const i = on(); if (i !== chosen) { chosen = i; target = i; go(); } }).observe(seg, { subtree: true, attributes: true, attributeFilter: ["class"] });
    render();
  };

  // ── A3 ─────────────────────────────────────────────────────────────────────────────────────────────────
  // A number in the readout rolls to its new figure: each digit a clipped strip of 0-9 that slides into place,
  // the next one 90 ms after it (transitions.dev's spinning counter), through a vertical-only blur that clears as
  // it lands. A figure of a new length, or no motion wanted, simply shows.
  let reelId = 0;
  FX.roll = (node, from, to) => {
    const text = String(to);
    if (REDUCED || from == null || String(from).length !== text.length || !/^\d+$/.test(text)) { node.textContent = text; node._reel = null; return; }
    if (!node._reel || node._reel.len !== text.length) {
      node.textContent = "";
      const NS = "http://www.w3.org/2000/svg", defs = document.createElementNS(NS, "svg");
      defs.setAttribute("class", "fx-reel-defs"); defs.setAttribute("aria-hidden", "true");
      const sr = mk("span", "fx-sr"), cols = [];
      for (let i = 0; i < text.length; i++) {
        const id = `fx-reel-${++reelId}`, f = document.createElementNS(NS, "filter"), b = document.createElementNS(NS, "feGaussianBlur");
        f.id = id; f.setAttribute("x", "-10%"); f.setAttribute("y", "-50%"); f.setAttribute("width", "120%"); f.setAttribute("height", "200%");
        b.setAttribute("stdDeviation", "0 0"); f.append(b); defs.append(f);
        const col = mk("span", "fx-reel-col"), strip = mk("span", "fx-reel-strip");
        for (let k = 0; k < 10; k++) strip.append(mk("span", null, String(k)));
        strip.setAttribute("aria-hidden", "true");
        col.append(strip); cols.push({ strip, blur: b, id, d: Number(String(from)[i]) });
        strip.style.transform = `translateY(calc(var(--fx-cell, 1em) * ${-Number(String(from)[i])}))`;
        node.append(col);
      }
      node.append(sr, defs);
      node._reel = { len: text.length, cols, sr, raf: 0 };
    }
    const reel = node._reel;
    reel.sr.textContent = text;
    const moving = [];
    [...text].map(Number).forEach((d, i) => {
      const c = reel.cols[i];
      c.strip.style.transition = `transform 600ms cubic-bezier(.16, 1, .3, 1) ${i * 90}ms`;
      c.strip.style.transform = `translateY(calc(var(--fx-cell, 1em) * ${-d}))`;
      if (c.d !== d) moving.push({ c, delay: i * 90 });
      c.d = d;
    });
    cancelAnimationFrame(reel.raf);
    if (!moving.length) return;
    const t0 = performance.now();
    moving.forEach(({ c }) => (c.strip.style.filter = `url(#${c.id})`));
    const tick = (now) => {
      let live = false;
      for (const { c, delay } of moving) {
        const p = clamp((now - t0 - delay) / 600, 0, 1), y = now - t0 < delay ? 0 : 3 * (1 - p) * (1 - p);
        c.blur.setAttribute("stdDeviation", `0 ${y.toFixed(2)}`);
        if (p < 1) live = true; else c.strip.style.filter = "";
      }
      reel.raf = live && node.isConnected ? requestAnimationFrame(tick) : 0;
    };
    reel.raf = requestAnimationFrame(tick);
  };

  // ── A4 ─────────────────────────────────────────────────────────────────────────────────────────────────
  // A crate chip's folder: point at the chip (or tab to it) and the flap tips open, the slips inside - three of the
  // crate's tracks - fanning up out of it, 40 ms apart. Closing is quicker and all at once.
  FX.folder = (titles) => {
    const box = mk("span", "fx-folder");
    box.setAttribute("aria-hidden", "true");
    box.append(mk("span", "fx-back"));
    (titles || []).slice(0, 3).forEach((t, i) => { const p = mk("span", "fx-slip", t); p.style.setProperty("--i", i); box.append(p); });
    box.append(mk("span", "fx-front"));
    return box;
  };

  // ── A5 ─────────────────────────────────────────────────────────────────────────────────────────────────
  // Eight lines fly 34 px out from where the button was pressed (its middle, from the keyboard) and fade over
  // 420 ms, in the app's colour. One canvas over the window, there only while sparks are in the air.
  let sparks = [], sraf = 0, canvas = null;
  FX.spark = (e, colour) => {
    if (REDUCED || !e) return;
    const b = e.currentTarget instanceof Element ? e.currentTarget : e.target;
    const r = b.getBoundingClientRect(), dpr = devicePixelRatio || 1, keyboard = e.detail === 0;
    const x = (keyboard ? r.left + r.width / 2 : e.clientX) * dpr, y = (keyboard ? r.top + r.height / 2 : e.clientY) * dpr;
    if (!canvas) { canvas = mk("canvas", "fx-sparks"); canvas.setAttribute("aria-hidden", "true"); document.body.append(canvas); }
    canvas.width = innerWidth * dpr; canvas.height = innerHeight * dpr;
    const c = colour || signal(), t = performance.now();
    for (let k = 0; k < 8; k++) sparks.push({ x, y, a: (Math.PI * 2 * k) / 8 - Math.PI / 8, t, c });
    const draw = (now) => {
      const ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      sparks = sparks.filter((s) => now - s.t < 420);
      for (const s of sparks) {
        const p = (now - s.t) / 420, ez = p * (2 - p), d = (8 + ez * 34) * dpr, len = 12 * (1 - ez) * dpr;
        ctx.strokeStyle = s.c; ctx.lineWidth = 2 * dpr; ctx.lineCap = "round"; ctx.globalAlpha = 1 - p;
        ctx.beginPath(); ctx.moveTo(s.x + d * Math.cos(s.a), s.y + d * Math.sin(s.a)); ctx.lineTo(s.x + (d + len) * Math.cos(s.a), s.y + (d + len) * Math.sin(s.a)); ctx.stroke();
      }
      ctx.globalAlpha = 1;
      if (sparks.length) sraf = requestAnimationFrame(draw); else { sraf = 0; canvas.remove(); canvas = null; }
    };
    if (!sraf) sraf = requestAnimationFrame(draw);
  };

  // ── A7 ─────────────────────────────────────────────────────────────────────────────────────────────────
  // While a scan reads tracks in, a slow band of light sweeps down the crate (2.4 s a pass), and the rows fill in
  // as each track's tempo and key land. on(false) lets the band finish its pass and stop.
  FX.sweep = (list, on) => { if (list) list.classList.toggle("fx-sweeping", !!on && !REDUCED); };

  // ── A8 ─────────────────────────────────────────────────────────────────────────────────────────────────
  // While the search box is empty, its placeholder types out a hint (about 70 ms a letter), waits, deletes it
  // (30 ms a letter) and types the next. Typing stops it and puts the plain placeholder back; clearing the box
  // starts it again. It rests while the window is hidden.
  FX.hints = (input, hints) => {
    if (!input || REDUCED || !hints.length) return;
    const plain = input.placeholder;
    let run = 0;
    const wait = (ms) => new Promise((r) => setTimeout(r, ms));
    const live = (me) => me === run && !input.value && input.isConnected;
    const start = async () => {
      const me = ++run;
      await wait(1200);
      for (let i = 0; live(me); i++) {
        const h = hints[i % hints.length];
        for (let k = 1; k <= h.length; k++) { while (document.hidden && live(me)) await wait(500); if (!live(me)) break; input.placeholder = h.slice(0, k); await wait(50 + Math.random() * 40); }
        if (!live(me)) break;
        await wait(1800);
        for (let k = h.length; k >= 0 && live(me); k--) { input.placeholder = h.slice(0, k); await wait(30); }
        await wait(300);
      }
      if (me === run || input.value) input.placeholder = plain;
    };
    input.addEventListener("input", () => { if (input.value) { run++; input.placeholder = plain; } else start(); });
    start();
  };

  // ── A9 ─────────────────────────────────────────────────────────────────────────────────────────────────
  // Point at a cover and a glint crosses it once (500 ms). Only the cover itself, so running the pointer down the
  // crate doesn't set off a column of flashes; leave and it's gone at once. Drawn in a layer over the cover, so the
  // rows themselves don't change.
  FX.glint = (selector) => {
    if (REDUCED || !matchMedia("(hover: hover)").matches) return;
    document.addEventListener("pointerover", (e) => {
      const img = e.target.closest?.(selector);
      if (!img || img._glint || img.classList.contains("blank")) return;
      const r = img.getBoundingClientRect();
      if (r.width < 16) return;
      const g = mk("span", "fx-glint");
      Object.assign(g.style, { left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px`, borderRadius: getComputedStyle(img).borderRadius });
      document.body.append(g);
      img._glint = g;
      requestAnimationFrame(() => g.classList.add("go"));
      const end = () => { g.remove(); img._glint = null; img.removeEventListener("pointerleave", end); };
      img.addEventListener("pointerleave", end);
      setTimeout(end, 650);
    });
  };

  // ── A10 ────────────────────────────────────────────────────────────────────────────────────────────────
  // A setup form in steps: each group of fields is a page that slides in from the side it comes from (8 px, through
  // a 3 px blur, 250 ms - transitions.dev's page side-by-side), with numbered dots and a line that fills between
  // them as you go. Next checks the fields in view first; the form's own button sends it on the last step.
  // check(i) may return a message to stop on step i.
  FX.steps = (form, groups, opts = {}) => {
    if (!form || form._steps) return;
    form._steps = true;
    const submit = form.querySelector('[type="submit"]'), error = opts.error && form.querySelector(opts.error);
    const pages = groups.map((g) => g.filter(Boolean));
    if (pages.some((p) => !p.length)) return;
    const view = mk("div", "fx-steps"), dots = mk("ol", "fx-dots"), nav = mk("div", "fx-step-nav");
    dots.setAttribute("aria-hidden", "true");
    const back = mk("button", "fx-back-btn btn-text", "Back"), next = mk("button", "btn-pill fx-next", "Next");
    back.type = "button"; next.type = "button";
    pages[0][0].before(dots, view);
    const wraps = pages.map((nodes, i) => {
      const w = mk("div", "fx-step"); w.append(...nodes); view.append(w);
      if (i) { const dl = mk("li", "fx-ln"); dl.append(mk("i")); dots.append(dl); }
      dots.append(mk("li", "fx-d", String(i + 1)));
      return w;
    });
    submit.before(nav); nav.append(back, next, submit);
    const status = mk("p", "fx-sr"); status.setAttribute("aria-live", "polite"); nav.after(status);
    let at = 0;
    const show = (focus) => {
      wraps.forEach((w, i) => { w.classList.toggle("is-before", i < at); w.classList.toggle("is-after", i > at); w.classList.toggle("is-current", i === at); w.inert = i !== at; });
      [...dots.querySelectorAll(".fx-d")].forEach((d, i) => { d.classList.toggle("done", i < at); d.classList.toggle("now", i === at); d.innerHTML = i < at ? '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7"/></svg>' : String(i + 1); });
      [...dots.querySelectorAll(".fx-ln")].forEach((l, i) => l.classList.toggle("done", i < at));
      back.hidden = at === 0;
      const last = at === wraps.length - 1;
      next.hidden = last; submit.hidden = !last;
      view.style.height = `${wraps[at].scrollHeight}px`;
      status.textContent = `Step ${at + 1} of ${wraps.length}`;
      if (focus) (wraps[at].querySelector("input, textarea, select, button") || (last ? submit : next)).focus({ preventScroll: true });
    };
    next.addEventListener("click", () => {
      if (error) error.hidden = true;
      for (const f of wraps[at].querySelectorAll("input, textarea, select")) if (!f.reportValidity()) return;
      const why = opts.check && opts.check(at);
      if (why) { if (error) { error.textContent = why; error.hidden = false; } return; }
      at++; show(true);
    });
    back.addEventListener("click", () => { if (error) error.hidden = true; at = Math.max(0, at - 1); show(true); });
    // Enter in a field moves on rather than sending the form early.
    form.addEventListener("keydown", (e) => { if (e.key === "Enter" && at < wraps.length - 1 && e.target.matches("input")) { e.preventDefault(); next.click(); } });
    new ResizeObserver(() => { view.style.height = `${wraps[at].scrollHeight}px`; }).observe(view);
    FX.stepsReset = () => { at = 0; show(false); };
    show(false);
    return { go: (i) => { at = clamp(i, 0, wraps.length - 1); show(true); } };
  };
})();
