// Shared by both apps, like u.css, scroll.js and moments.js - this file is the same in DJ Master and the Stem
// Splitter. Three things neither app had (11 Oct 2026):
//
//   1. Reading it     Text size (the whole window scales, 90-150% - the app sets the web view's own zoom, so every
//                     layout rule sees the room it really has) and Daylight (high contrast, the smoke off) -
//                     for a laptop at arm's length in a dark booth, a day party in full sun, or eyes that need it.
//                     Settings > Theme. Applied from the boot answer too, so the lock screen wears it.
//   2. Get set up     A short list on the home screen for someone new: it ticks itself off as each thing is done,
//                     and leaves when it's finished or dismissed.
//   3. Find anything  Every setting, by name, in the command box (Ctrl+K) - and the command box itself in the app
//                     that had none.
//
// Each app hands over what is its own through window.YCA, set at the end of its app.js:
//   api()             the Python bridge
//   settings()        the settings as they are now
//   saved(settings)   take in the settings a set_setting call answered with
//   toast(text, bad)
//   openSettings(group)   closeSettings()
//   setup()           { steps: [{ id, title, hint, done, go, goLabel }] } - the checklist's steps for this app
//   commands()        (only the app without its own command box) [{ name, what, run }]
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const A = () => window.YCA || {};
  const root = document.documentElement;

  // ── 1. Reading it ──
  function apply(s) {
    s = s || {};
    const size = Math.max(90, Math.min(150, Math.round(Number(s.text_size) || 100)));
    root.classList.toggle("daylight", !!s.daylight);
    const r = $("#read-size"), o = $("#read-size-val"), d = $("#read-daylight");
    if (r && document.activeElement !== r) r.value = String(size);
    if (o) o.textContent = `${size}%`;
    if (d) d.checked = !!s.daylight;
    if (window.YCS && window.YCS.refresh) window.YCS.refresh();
  }
  function mountReading() {
    // Beside the Wallpaper card, whatever this app calls the box they sit in.
    const wall = $("#sp-theme .wallpaper"), grid = wall ? wall.parentElement : $("#sp-theme .sxg");
    if (!grid || $("#read-size")) return;
    const card = el("div", "sxc wide reading");
    card.innerHTML = `<span class="label">Reading it</span>
      <p class="desc">Make everything bigger - text, buttons, the lot - for a laptop at arm's length. <b>Daylight</b> turns the contrast right up and the smoke off, for a bright room or a day party in full sun.</p>
      <div class="wall-row read-row"><input type="range" id="read-size" min="90" max="150" step="5" value="100" aria-label="Text size"><output id="read-size-val" for="read-size">100%</output></div>
      <label class="toggle" for="read-daylight"><input type="checkbox" id="read-daylight"><span class="toggle-track"></span><span>Daylight - high contrast</span></label>`;
    grid.append(card);
    const save = async (key, value) => { const a = A(); if (!a.api) return; const s = await a.api().set_setting(key, value); if (s && a.saved) a.saved(s); apply(s || a.settings()); };
    $("#read-size").addEventListener("input", e => { $("#read-size-val").textContent = `${e.target.value}%`; });
    $("#read-size").addEventListener("change", e => save("text_size", Number(e.target.value)));
    $("#read-daylight").addEventListener("change", e => save("daylight", e.target.checked));
    apply(A().settings ? A().settings() : {});
  }

  // ── 2. Get set up ──
  function refresh() {
    const mount = $("#setup-mount"), a = A();
    if (!mount || !a.setup || !a.settings) return;
    const st = a.settings() || {};
    const marked = new Set(st.setup_done || []);
    const steps = (a.setup().steps || []).map(x => Object.assign({}, x, { done: !!x.done || marked.has(x.id) }));
    const left = steps.filter(x => !x.done);
    if (st.setup_hidden || !steps.length || !left.length) {
      // All done for the first time: one line of thanks, then gone for good.
      if (!st.setup_hidden && steps.length && !left.length && mount.firstChild && a.api) {
        a.api().set_setting("setup_hidden", true).then(s => a.saved && a.saved(s));
        if (a.toast) a.toast("That's everything set up. This list won't show again.");
      }
      mount.replaceChildren();
      return;
    }
    const card = el("div", "setup");
    const head = el("div", "setup-head");
    const hide = el("button", "btn-text setup-hide", "Hide this");
    hide.type = "button";
    hide.title = "It won't come back";
    hide.onclick = async () => { const s = await a.api().set_setting("setup_hidden", true); if (a.saved) a.saved(s); mount.replaceChildren(); };
    head.append(el("h3", "setup-title", "Get set up"), el("span", "setup-count", `${steps.length - left.length} of ${steps.length}`), hide);
    const list = el("ol", "setup-list");
    const next = left[0];
    steps.forEach((x, i) => {
      const li = el("li", "setup-step" + (x.done ? " done" : x === next ? " next" : ""));
      li.append(el("span", "setup-mark", x.done ? "Done" : x === next ? "Next" : String(i + 1)));
      const words = el("div", "setup-words");
      words.append(el("b", null, x.title));
      if (x.hint && !x.done) words.append(el("small", null, x.hint));
      li.append(words);
      if (x === next && x.go) {
        const go = el("button", "btn-pill small", x.goLabel || "Show me");
        go.type = "button";
        go.onclick = () => x.go();
        li.append(go);
      }
      list.append(li);
    });
    card.append(head, list);
    mount.replaceChildren(card);
  }
  // A step the app can't see for itself (opening the mixer, say) is marked when it happens.
  async function mark(id) {
    const a = A();
    if (!a.api || !a.settings) return;
    const st = a.settings() || {};
    if (st.setup_hidden || (st.setup_done || []).includes(id)) return;
    const s = await a.api().set_setting("setup_done", [...(st.setup_done || []), id]);
    if (a.saved) a.saved(s);
    refresh();
  }

  // ── 3. Find anything ──
  // Every card and switch on the Settings page, as a command: "Wallpaper", "Tell me when a new version is out".
  // This edition's only: what [data-fetch] or [data-shop] hides (html.store says which) is not a command, and its
  // words are left out of a name.
  function settingsCommands() {
    const a = A(), out = [], seen = new Set();
    const hidden = root.classList.contains("store") ? "[data-fetch]" : "[data-shop]";
    const words = node => {
      if (node.closest(hidden)) return "";
      const copy = node.cloneNode(true);
      copy.querySelectorAll(hidden).forEach(n => n.remove());
      return copy.textContent;
    };
    document.querySelectorAll(".sp-group").forEach(group => {
      const g = group.dataset.group, where = (group.querySelector(".sp-gtitle") || {}).textContent || "Settings";
      const add = (name, node) => {
        name = (name || "").replace(/\s+/g, " ").trim();
        if (!name || name.length > 70 || seen.has(g + name)) return;
        seen.add(g + name);
        out.push({ name, what: `Settings › ${where}`, run: () => {
          if (a.openSettings) a.openSettings(g);
          setTimeout(() => { node.scrollIntoView({ block: "center" }); node.classList.add("found"); setTimeout(() => node.classList.remove("found"), 1600); }, 420);
        } });
      };
      group.querySelectorAll(".sxc, .stc").forEach(card => {
        const label = card.querySelector(":scope > .label");
        if (label) add(words(label), card);
        card.querySelectorAll("label.toggle").forEach(t => add(words(t), t));
        card.querySelectorAll("h3").forEach(h => add(words(h), h));
      });
    });
    return out;
  }

  // The command box, for the app that had none. Same keys as DJ Master's: Ctrl+K (Cmd+K on a Mac) opens it, the
  // arrows move, Return does it, Esc closes. No animation: it is opened from the keyboard, and often.
  let pal = null, hits = [], pick = 0;
  function closePalette() { if (pal) { pal.remove(); pal = null; } }
  function openPalette() {
    if ($("#palette")) return;                       // this app has its own
    if (pal || root.classList.contains("locked")) return;
    const a = A();
    pal = el("div", "ycm-palette");
    pal.setAttribute("role", "dialog");
    pal.setAttribute("aria-label", "Commands");
    const box = el("div", "ycm-pal-box"), input = el("input", "ycm-pal-in"), list = el("div", "ycm-pal-list");
    input.type = "text"; input.spellcheck = false; input.placeholder = "Type a command, or the name of a setting…";
    input.setAttribute("aria-label", "Type a command");
    const foot = el("div", "ycm-pal-foot");
    foot.innerHTML = "<span><kbd>↑</kbd><kbd>↓</kbd> move</span><span><kbd>↵</kbd> do it</span><span><kbd>esc</kbd> close</span>";
    box.append(input, list, foot);
    pal.append(box);
    document.body.append(pal);
    const all = [...((a.commands && a.commands()) || []), ...settingsCommands()];
    const draw = () => {
      const q = input.value.trim().toLowerCase();
      const words = q.split(/\s+/).filter(Boolean);
      hits = all.filter(c => words.every(w => `${c.name} ${c.what || ""}`.toLowerCase().includes(w))).slice(0, 9);
      pick = Math.min(pick, Math.max(0, hits.length - 1));
      list.replaceChildren(...(hits.length ? hits.map((c, i) => {
        const row = el("button", "ycm-pal-row" + (i === pick ? " on" : ""));
        row.type = "button";
        row.append(el("b", null, c.name), el("small", null, c.what || ""));
        row.onclick = () => fire(i);
        return row;
      }) : [el("p", "ycm-pal-none", "Nothing by that name.")]));
    };
    const fire = i => { const c = hits[i]; closePalette(); if (c) Promise.resolve().then(c.run).catch(() => a.toast && a.toast("That didn't work.", true)); };
    input.addEventListener("input", () => { pick = 0; draw(); });
    input.addEventListener("keydown", e => {
      if (e.key === "ArrowDown") { pick = Math.min(hits.length - 1, pick + 1); draw(); e.preventDefault(); }
      else if (e.key === "ArrowUp") { pick = Math.max(0, pick - 1); draw(); e.preventDefault(); }
      else if (e.key === "Enter") { fire(pick); e.preventDefault(); }
      else if (e.key === "Escape") { closePalette(); e.preventDefault(); }
      e.stopPropagation();
    });
    pal.addEventListener("pointerdown", e => { if (e.target === pal) closePalette(); });
    draw();
    input.focus();
  }
  addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === "k" && !$("#palette")) { e.preventDefault(); pal ? closePalette() : openPalette(); }
  });

  function ready() { mountReading(); refresh(); }
  window.YCMore = { apply, refresh, mark, settingsCommands, openPalette, ready };
})();
