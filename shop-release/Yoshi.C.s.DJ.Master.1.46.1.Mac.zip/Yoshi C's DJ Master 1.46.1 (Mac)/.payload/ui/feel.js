/* The feel's other half (feel.css says what it is). The same in DJ Master and Stem Splitter, shop and private.
   It needs nothing from app.js and app.js needs nothing from it: it watches the page and follows along.
     - option rows (.segmented): one highlight slides to whichever button is .on
     - press feedback: anything you can press shrinks a touch the moment it's pressed and springs back on release.
       Done with the Web Animations API on `scale`, so it never fights a button's own transitions; buttons that
       already answer a press (their own :active) are left alone. */
(() => {
  const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const spring = () => getComputedStyle(document.documentElement).getPropertyValue("--spring").trim() || "ease-out";

  // ── Option rows ──
  function place(row, instant) {
    let lit = row.querySelector(":scope > .f-seg");
    if (!lit) {
      lit = document.createElement("span"); lit.className = "f-seg"; lit.setAttribute("aria-hidden", "true");
      row.prepend(lit); row.classList.add("f-slides");
    }
    const on = row.querySelector(":scope > button.on");
    if (!on || !on.offsetWidth) { lit.style.opacity = "0"; return; }
    const first = lit.style.opacity !== "1";
    if (instant || first || REDUCED) lit.style.transition = "none";
    lit.style.width = on.offsetWidth + "px"; lit.style.height = on.offsetHeight + "px";
    lit.style.transform = "translate(" + on.offsetLeft + "px, " + on.offsetTop + "px)";
    lit.style.opacity = "1";
    if (instant || first || REDUCED) { lit.offsetWidth; lit.style.transition = ""; }
  }
  let queued = 0, instantNext = false;
  function all(instant) {
    instantNext = instantNext || !!instant;
    if (queued) return;
    queued = requestAnimationFrame(() => {
      queued = 0;
      document.querySelectorAll(".segmented").forEach((row) => { if (row.querySelector(":scope > button")) place(row, instantNext); });
      instantNext = false;
    });
  }
  // Rows are drawn and redrawn by app.js at any time, and their .on moves on a click: follow the page.
  const watch = new MutationObserver((list) => {
    for (const m of list) {
      const t = m.target;
      if (m.type === "attributes" ? t.parentElement?.classList.contains("segmented") : (t.classList?.contains("segmented") || t.querySelector?.(".segmented"))) { all(); return; }
    }
  });
  function start() {
    watch.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["class"] });
    all(true);
    addEventListener("resize", () => all(true));
    document.fonts?.ready.then(() => all(true));
  }

  // ── Press feedback ──
  const PRESSABLE = "button, .rail-item, .toggle, [role=button], .chip, a.btn-text";
  const OWN = ".btn-pill, .btn-outline, .toast-action, .cplay, .pl-play, .gf-opt, .gf-act, .set-idea, .set-hit, .ins-key, .win-btn, .win-close";
  let held = null;
  function press(e) {
    if (REDUCED || e.button > 0) return;
    const el = e.target.closest?.(PRESSABLE);
    if (!el || el.matches(OWN) || el.disabled || el.closest("[disabled]")) return;
    held = el;
    el.animate([{ scale: "1" }, { scale: el.offsetWidth > 240 ? "0.99" : "0.96" }], { duration: 100, easing: "ease-out", fill: "forwards" });
  }
  function release() {
    if (!held) return;
    const el = held; held = null;
    el.getAnimations().forEach((a) => { if (a.effect?.getKeyframes?.().some((k) => "scale" in k)) a.cancel(); });
    el.animate([{ scale: el.offsetWidth > 240 ? "0.99" : "0.96" }, { scale: "1" }], { duration: 520, easing: spring() });
  }
  addEventListener("pointerdown", press, true);
  addEventListener("pointerup", release, true);
  addEventListener("pointercancel", release, true);
  addEventListener("blur", release);

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
