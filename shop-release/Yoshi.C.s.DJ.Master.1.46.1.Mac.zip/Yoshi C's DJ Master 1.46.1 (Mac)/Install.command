#!/bin/bash
# Yoshi C's DJ Master - Mac installer.
#
# Written for a blank Mac: no Homebrew, Python, Xcode tools or ffmpeg assumed. It only uses what every
# Mac ships with (bash, curl, tar, unzip, ditto) and never runs /usr/bin/python3 or git - on a fresh Mac
# those pop up the "install developer tools" dialog. Everything else is downloaded into one folder:
#   ~/Library/Application Support/Yoshi C DJ Master
# and the app itself goes in ~/Applications. No admin password needed. Safe to re-run.
#
# Env switches:  NONINTERACTIVE=1  never wait for Return
#                DJM_UPDATE=1      started by the app's Install update: open it again at the end, even
#                                  after a failure, so nobody is left without it mid-week
#                DJM_WAIT_PID=n    wait for that process (the app, closing itself) before copying anything

set -u

APP_NAME="Yoshi C's DJ Master"
OLD_BUNDLE="$HOME/Applications/Yoshi C DJ Master.app"   # the 1.0 name
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$PKG_DIR/.payload"
DEST="$HOME/Library/Application Support/Yoshi C DJ Master"
APPS="$HOME/Applications"
BUNDLE="$APPS/$APP_NAME.app"
TOTAL=7

ACC=$'\033[38;5;203m'; DIM=$'\033[38;5;245m'; GRN=$'\033[32m'; RED=$'\033[31m'; YEL=$'\033[33m'; BOLD=$'\033[1m'; RST=$'\033[0m'

# Apple Silicon Mac running this Terminal under Rosetta: re-launch natively, or we'd install Intel builds.
if [ "$(uname -m)" = "x86_64" ] && [ "$(sysctl -n sysctl.proc_translated 2>/dev/null)" = "1" ]; then
    exec arch -arm64 /bin/bash "$0" "$@"
fi

mkdir -p "$DEST"
LOG="$DEST/install-log.txt"
exec > >(tee -a "$LOG") 2>&1
echo "===== $(date) ====="

step() { printf "\n  ${ACC}[%s/%s]${RST} ${BOLD}%s${RST}\n" "$1" "$TOTAL" "$2"; }
info() { printf "        ${DIM}%s${RST}\n" "$1"; }
ok()   { printf "        ${GRN}OK${RST}  %s\n" "$1"; }
warn() { printf "        ${YEL}!${RST}   %s\n" "$1"; }
fail() {
    printf "\n  ${RED}Setup couldn't finish:${RST} %s\n" "$1"
    printf "  ${DIM}A log was saved to %s - send it to Yoshi if you need help.${RST}\n\n" "$LOG"
    if [ "${NONINTERACTIVE:-0}" != "1" ]; then read -r -p "  Press Return to close " _; fi
    if [ "${DJM_UPDATE:-0}" = "1" ] && [ -d "$BUNDLE" ]; then open "$BUNDLE"; fi
    exit 1
}

TMP="$(mktemp -d -t yoshic-djm)"
trap 'rm -rf "$TMP"' EXIT

clear 2>/dev/null
printf "\n   ${ACC}(O)${RST}   ${BOLD}Y O S H I   C${RST}\n"
printf "         ${DIM}DJ MASTER  -  MAC SETUP${RST}\n\n"
printf "   ${DIM}This downloads about 300 MB (Python and the app's libraries).${RST}\n"
printf "   ${DIM}It usually takes 3-8 minutes. Leave this window open.${RST}\n"

# The licence has to be accepted before anything is copied (LICENCE.txt sits next to this script).
printf "\n   ${BOLD}Licence${RST}\n"
printf "   ${DIM}Yoshi C's DJ Master is for your own personal use only. Don't pass it on, copy it\n"
printf "   or change it. What you download and where you play it is your responsibility -\n"
printf "   the Copyright Act 1968 (Cth) applies, and public play needs APRA AMCOS / PPCA\n"
printf "   licences. Yoshi C is not liable for it and gives no warranty; nothing here takes\n"
printf "   away your Australian Consumer Law rights. Victorian law. Full terms: LICENCE.txt${RST}\n\n"
if [ "${NONINTERACTIVE:-0}" != "1" ]; then
    read -r -p "   Do you accept? [y/N] " LICENCE_OK
    case "$LICENCE_OK" in
        [yY]*) ;;
        *) printf "\n   Nothing was installed.\n\n"; exit 1 ;;
    esac
fi

# An update from inside the app: it has closed itself for this. Nothing is copied over it until it's gone.
if [ -n "${DJM_WAIT_PID:-}" ]; then
    for _ in $(seq 1 60); do kill -0 "$DJM_WAIT_PID" 2>/dev/null || break; sleep 1; done
fi

# ── 1. Check this Mac ───────────────────────────────────────────────────────
step 1 "Checking this Mac"
ARCH="$(uname -m)"
MACOS="$(sw_vers -productVersion)"
MAJOR="${MACOS%%.*}"
if [ "$MAJOR" -lt 12 ]; then
    fail "macOS $MACOS is too old. This app needs macOS 12 Monterey or newer."
fi
FREE_KB="$(df -Pk "$HOME" | awk 'NR==2 {print $4}')"
if [ "${FREE_KB:-0}" -lt 2097152 ]; then
    fail "Not enough free space. About 2 GB is needed; this Mac has $((FREE_KB / 1048576)) GB free."
fi
if ! curl -fsSI --max-time 20 https://pypi.org/simple/ >/dev/null; then
    fail "Couldn't reach the internet. Connect and run the installer again."
fi
if [ "$ARCH" = "arm64" ]; then ok "Apple Silicon, macOS $MACOS"; else ok "Intel, macOS $MACOS"; fi

# ── 2. App files ────────────────────────────────────────────────────────────
step 2 "Copying the app"
[ -d "$PAYLOAD" ] || fail "The installer files are missing. Unzip the whole download and run Install.command from inside that folder."
ditto "$PAYLOAD" "$DEST" || fail "Couldn't copy the app into $DEST."
mkdir -p "$DEST/bin"
ok "$DEST"

# ── 3. Python 3.11 (private copy via uv) ────────────────────────────────────
step 3 "Python 3.11"
export UV_PYTHON_INSTALL_DIR="$DEST/python"
export UV_CACHE_DIR="$DEST/.uv-cache"
export UV_LINK_MODE=copy
UV="$DEST/bin/uv"
if [ ! -x "$UV" ]; then
    if [ "$ARCH" = "arm64" ]; then UV_TARGET="aarch64-apple-darwin"; else UV_TARGET="x86_64-apple-darwin"; fi
    info "Downloading uv (Python installer)..."
    curl -fL --retry 3 --progress-bar -o "$TMP/uv.tar.gz" \
        "https://github.com/astral-sh/uv/releases/latest/download/uv-$UV_TARGET.tar.gz" || fail "Couldn't download uv."
    mkdir -p "$TMP/uv" && tar -xzf "$TMP/uv.tar.gz" -C "$TMP/uv" || fail "Couldn't unpack uv."
    UV_BIN="$(find "$TMP/uv" -type f -name uv | head -n 1)"
    [ -n "$UV_BIN" ] || fail "uv wasn't in the download."
    cp "$UV_BIN" "$UV" && chmod +x "$UV"
fi
VPY="$DEST/.venv/bin/python"
if ! "$VPY" -c "import sys; assert sys.version_info[:2] == (3, 11)" >/dev/null 2>&1; then
    rm -rf "$DEST/.venv"
    "$UV" python install 3.11 || fail "Couldn't download Python 3.11."
    "$UV" venv --python 3.11 --python-preference only-managed "$DEST/.venv" || fail "Couldn't create the app environment."
fi
ok "$("$VPY" --version 2>&1)"

# ── 4. The app's libraries ─────────────────────────────────────────────────
step 4 "Download, audio and window libraries"
# uv splits requirement/constraint file paths at spaces, and the app lives in
# "Application Support" - so hand it copies from the temp folder (no spaces).
REQ="$TMP/req"
mkdir -p "$REQ"
cp "$DEST/installer/mac/requirements-mac.txt" "$REQ/requirements.txt"
cp "$DEST/installer/security-constraints.txt" "$REQ/security-constraints.txt"
# Only the private edition downloads from links: it ships downloader.pyc and a list of what that adds.
FETCHES=""
if [ -f "$DEST/downloader.pyc" ] && [ -f "$DEST/installer/mac/requirements-mac-private.txt" ]; then
    FETCHES=1
    grep -v "^#" "$DEST/installer/mac/requirements-mac-private.txt" >> "$REQ/requirements.txt"
fi
OVERRIDE_ARGS=()
if [ "$ARCH" != "arm64" ]; then
    cp "$DEST/installer/mac/overrides-intel.txt" "$REQ/overrides.txt"
    OVERRIDE_ARGS=(--override "$REQ/overrides.txt")
fi
"$UV" pip install --python "$VPY" -r "$REQ/requirements.txt" -c "$REQ/security-constraints.txt" ${OVERRIDE_ARGS[@]+"${OVERRIDE_ARGS[@]}"} \
    || fail "The app's libraries didn't install."
    # (the +"..." form: macOS's bash 3.2 treats an empty array as unbound under set -u)
LIBS="webview, librosa, soundfile, segno, imageio_ffmpeg, Cryptodome, certifi"
[ -n "$FETCHES" ] && LIBS="$LIBS, yt_dlp"
CHECK="$("$VPY" -c "import $LIBS; print('ok')" 2>&1)" \
    || fail "The libraries installed but won't load: $(echo "$CHECK" | tail -n 3)"
ok "all libraries load"

# ── 5. ffmpeg + Deno ────────────────────────────────────────────────────────
step 5 "ffmpeg${FETCHES:+, Deno} and cloudflared"
FF="$("$VPY" -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())" 2>/dev/null)"
if [ -n "$FF" ] && [ -f "$FF" ]; then
    chmod +x "$FF"
    ln -sf "$FF" "$DEST/bin/ffmpeg"
fi
"$DEST/bin/ffmpeg" -version >/dev/null 2>&1 || fail "ffmpeg won't run on this Mac."
ok "ffmpeg ready"
if [ -n "$FETCHES" ] && [ ! -x "$DEST/bin/deno" ]; then
    if [ "$ARCH" = "arm64" ]; then DENO_TARGET="aarch64-apple-darwin"; else DENO_TARGET="x86_64-apple-darwin"; fi
    if curl -fsL --retry 3 -o "$TMP/deno.zip" "https://github.com/denoland/deno/releases/latest/download/deno-$DENO_TARGET.zip" \
        && unzip -o -q "$TMP/deno.zip" -d "$DEST/bin"; then
        chmod +x "$DEST/bin/deno"
    fi
fi
if [ -z "$FETCHES" ]; then
    :                                             # the shop edition fetches nothing: no Deno
elif "$DEST/bin/deno" --version >/dev/null 2>&1; then
    ok "Deno ready (YouTube link support)"
else
    warn "Deno couldn't be installed - YouTube links may be less reliable, everything else works."
fi

# cloudflared is what booth mode's public link is made of. It goes in the app's own bin/, which
# tunnel.find_cloudflared looks in first, so nothing has to be on PATH. Missing it costs only booth
# mode - the app says so when the switch is turned on - so a failure here is a warning, not a stop.
if [ ! -x "$DEST/bin/cloudflared" ]; then
    if [ "$ARCH" = "arm64" ]; then CF_TARGET="arm64"; else CF_TARGET="amd64"; fi
    if curl -fsL --retry 3 -o "$TMP/cloudflared.tgz"         "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-$CF_TARGET.tgz"         && tar -xzf "$TMP/cloudflared.tgz" -C "$TMP"; then
        CF_BIN="$(find "$TMP" -maxdepth 2 -name cloudflared -type f | head -n 1)"
        [ -n "$CF_BIN" ] && mv "$CF_BIN" "$DEST/bin/cloudflared" && chmod +x "$DEST/bin/cloudflared"
    fi
fi
if "$DEST/bin/cloudflared" --version >/dev/null 2>&1; then
    ok "cloudflared ready (booth mode's public link)"
else
    warn "cloudflared couldn't be installed - booth mode's public link won't work, everything else does."
fi

# ── 6. Add to Applications ─────────────────────────────────────────────────
step 6 "Adding the app to Applications"
rm -rf "$DEST/.uv-cache"
[ -d "$OLD_BUNDLE" ] && rm -rf "$OLD_BUNDLE"
mkdir -p "$BUNDLE/Contents/MacOS" "$BUNDLE/Contents/Resources"
cat > "$BUNDLE/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>DJ Master</string>
    <key>CFBundleDisplayName</key><string>Yoshi C's DJ Master</string>
    <key>CFBundleIdentifier</key><string>com.yoshic.djmaster</string>
    <key>CFBundleVersion</key><string>1.46.1</string>
    <key>CFBundleShortVersionString</key><string>1.46.1</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>CFBundleExecutable</key><string>launch</string>
    <key>CFBundleIconFile</key><string>AppIcon</string>
    <key>LSMinimumSystemVersion</key><string>12.0</string>
    <key>NSHighResolutionCapable</key><true/>
    <key>LSApplicationCategoryType</key><string>public.app-category.music</string>
</dict>
</plist>
PLIST
cat > "$BUNDLE/Contents/MacOS/launch" <<'LAUNCH'
#!/bin/bash
APP_DIR="$HOME/Library/Application Support/Yoshi C DJ Master"
cd "$APP_DIR" || exit 1
exec "$APP_DIR/.venv/bin/python" "$APP_DIR/app.pyc" >> "$APP_DIR/log.txt" 2>&1
LAUNCH
chmod +x "$BUNDLE/Contents/MacOS/launch"
cp "$DEST/AppIcon.icns" "$BUNDLE/Contents/Resources/AppIcon.icns" 2>/dev/null
cp "$PKG_DIR/Uninstall.command" "$DEST/Uninstall.command" 2>/dev/null && chmod +x "$DEST/Uninstall.command"
touch "$BUNDLE"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$BUNDLE" >/dev/null 2>&1
ok "$BUNDLE"

# ── Files an older version left behind ────────────────────────────────────
# ditto merges this version's files in but never takes anything out, so a module or a page that
# was dropped from the app stayed in the folder for good - and Python imports a stale .pyc quite
# happily. The manifest written by the build says what belongs here; prune.py removes the rest,
# touching only the app's own folders and never settings, the crate, the models or .venv.
step 7 "Clearing out old files"
"$VPY" "$DEST/installer/prune.py" "$DEST" || warn "couldn't check for old files - nothing was removed."
# ── The installation ID ──────────────────────────────────────────────
# Printed when this copy has a use for it: a first install, or a key that was issued for another
# machine - the one case where something that worked stops working, and the one where this number
# is hardest to get at. Silent on an ordinary update. licence.install_id() makes that call, so the
# rule lives with the licence code rather than being guessed at separately in four installers.
INSTALL_ID="$(cd "$DEST" && "$VPY" -c "import licence,sys; sys.stdout.write(licence.install_id('licence.json'))" 2>/dev/null)"
if [ -n "$INSTALL_ID" ]; then
    RULE="------------------------------------------------------"
    printf "\n  ${DIM}%s${RST}\n" "$RULE"
    printf "  ${DIM} This computer's installation ID${RST}\n\n"
    printf "       ${BOLD}${ACC}%s${RST}\n\n" "$INSTALL_ID"
    printf "  ${DIM} It starts with a 5-day free trial - no key needed yet.${RST}\n"
    printf "  ${DIM} To keep it after that, send Yoshi this line for a key.${RST}\n"
    printf "  ${DIM} It's in the app's Settings too, so nothing to write down.${RST}\n"
    printf "  ${DIM}%s${RST}\n" "$RULE"
fi

printf "\n  ${GRN}${BOLD}Setup complete.${RST}\n"
printf "  ${DIM}Open '%s' from Launchpad, Spotlight, or your Applications folder.${RST}\n" "$APP_NAME"
printf "  ${DIM}The first time it opens, set your DJ name and password.${RST}\n\n"
if [ "${DJM_UPDATE:-0}" = "1" ]; then
    open "$BUNDLE"
elif [ "${NONINTERACTIVE:-0}" != "1" ]; then
    read -r -p "  Open it now? [Y/n] " answer
    case "$answer" in
        [nN]*) ;;
        *) open "$BUNDLE" ;;
    esac
fi
exit 0
